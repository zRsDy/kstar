CREATE VIEW V_PRODUCT_MODE AS select m.lov_code as code,m.lov_name as name,m.no as no from sys_t_lov_member m where m.group_code = 'PRODUCTMODE'
/
