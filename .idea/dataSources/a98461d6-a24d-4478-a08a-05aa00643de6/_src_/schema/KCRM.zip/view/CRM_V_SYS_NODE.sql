CREATE VIEW CRM_V_SYS_NODE AS select
  ORG_CODE as code,
  ORG_NAME as name,
  ORG_SEQ  as branch_seq
from CRM_T_SYS_ORG t
where t.org_level <> '1' and t.org_code!='000905' order by t.org_seq

/
