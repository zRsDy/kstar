CREATE VIEW KSTAT_BIZOPP_REPORT_SCALE_V AS select
        b.c_opportunity_name,
        b.c_biz_opp_address_name,
        b.c_client_name,
        b.created_by_id,
        b.created_org_id,
        b.created_at,
        b.c_status,
        b.c_conflict_status,
        b.c_sale_stage,
        b.Success_Date,
        b.end_Date,
        t.c_status as bidstatus,
        b.c_pid,
        b.created_pos_id
    from
        crm_t_business_opportunity b,CRM_T_BID t
    where 1=1
        and b.c_pid = t.c_business_opp_id(+)
        and (b.c_status = '20'
             or  b.c_status = '120'
             or  b.c_status = '100'
             or  b.c_status = '110')
/
