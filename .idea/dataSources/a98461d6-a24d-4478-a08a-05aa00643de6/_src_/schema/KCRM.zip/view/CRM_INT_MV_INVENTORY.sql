CREATE VIEW CRM_INT_MV_INVENTORY AS SELECT msi.segment1
      ,ood.organization_code
      ,oqd.subinventory_code
      ,SUM(oqd.primary_transaction_quantity) qty
      ,SUM((SELECT SUM(mra.primary_reservation_quantity) FROM APPS.mtl_reservations_all_v@crm_erp mra
        WHERE mra.inventory_item_id = oqd.inventory_item_id
          AND mra.organization_id = oqd.organization_id
          AND mra.subinventory_code = oqd.subinventory_code))rese_qty
FROM INV.mtl_onhand_quantities_detail@crm_erp oqd
    ,INV.mtl_system_items_b@crm_erp msi
    ,INV.mtl_secondary_inventories@crm_erp sii
    ,APPS.org_organization_definitions@crm_erp ood
WHERE oqd.inventory_item_id = msi.inventory_item_id
  AND oqd.organization_id = msi.organization_id
  AND oqd.subinventory_code = sii.secondary_inventory_name
  AND oqd.organization_id = sii.organization_id
  AND oqd.organization_id = ood.organization_id
GROUP BY ood.organization_code,msi.segment1,oqd.subinventory_code
/
