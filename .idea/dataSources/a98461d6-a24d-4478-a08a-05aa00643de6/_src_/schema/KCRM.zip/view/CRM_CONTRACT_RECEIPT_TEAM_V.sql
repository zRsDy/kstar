CREATE VIEW CRM_CONTRACT_RECEIPT_TEAM_V AS select t.business_id as business_id,
       t.row_id as row_id,
       emp.name      as c_salesman_name,
       emp.no        as c_salesman_code,
       emp.row_id    as c_salesman_id,
       posi.row_id   as c_salesman_post
  from CRM_T_TEAM t, SYS_T_PERMISSION_EMPLOYEE emp, sys_t_lov_member posi
 where t.business_type = 'CONTRACT_RECEIPT_DETAIL'
   and emp.row_id = t.MASTER_EMPLOYEE_ID
   and posi.row_id = t.position_id
   and posi.group_id = 'POSITION'
   and posi.opt_txt3 = 'XS'
/
