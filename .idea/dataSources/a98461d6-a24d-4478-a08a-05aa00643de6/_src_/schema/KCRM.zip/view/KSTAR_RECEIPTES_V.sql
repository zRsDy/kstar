CREATE VIEW KSTAR_RECEIPTES_V AS select rownum as id,
       crd.c_cust_code,
       crd.c_cust_name as customer,
       crd.c_contract_code,
       crd.c_delivery_code,
       crd.c_receipts_plan,
       lm1.lov_name,
       crd.c_receipts_stage,
       lm2.lov_name as stage,
       get_convert_cur_amount(crd.n_plan_amount,  crd.c_receipts_type ,
         (select dt_print_time
            from crm_t_delivery_lines dl
           where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
             and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
             and rownum <= 1),'CNY') as n_plan_amount,
       get_convert_cur_amount(crd.n_veri_amount,  crd.c_receipts_type ,
         (select dt_print_time
            from crm_t_delivery_lines dl
           where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
             and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
             and rownum <= 1),'CNY') as n_veri_amount,
       --crd.n_plan_amount,
       --crd.n_veri_amount,
       crd.C_BIZ_DEPT as C_SALESMAN_ORG_ID,
       get_convert_cur_amount(crd.n_plan_amount,  crd.c_receipts_type ,
         (select dt_print_time
            from crm_t_delivery_lines dl
           where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
             and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
             and rownum <= 1),'USD') as n_usd_plan_amount,
       get_convert_cur_amount(crd.n_veri_amount,  crd.c_receipts_type ,
         (select dt_print_time
            from crm_t_delivery_lines dl
           where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
             and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
             and rownum <= 1),'USD') as n_usd_veri_amount,
       crd.c_pid as ct_id,

       lm3.lov_name as c_salesman_post_name,
       lm3.group_id as group_id,
       lm4.lov_name as C_BIZ_DEPT_NAME,
       lm4.lov_path as C_BIZ_DEPT_PATH,
       (crd.n_plan_amount-crd.n_veri_amount) as BALANCE,
       get_convert_cur_amount((crd.n_plan_amount-crd.n_veri_amount),  crd.c_receipts_type ,
         (select dt_print_time
            from crm_t_delivery_lines dl
           where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
             and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
             and rownum <= 1),'USD') as BALANCE_USD,

       crd.c_receipts_type as Currency,
       crd.dt_payment_date,
       (select dt_print_time
          from crm_t_delivery_lines dl
         where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
           and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
           and rownum <= 1) dt_print_time,
       crd.c_salesman_id,
       crd.c_salesman_code,
       crd.c_salesman_name,
       (select c_order_code
          from crm_t_delivery_lines dl
         where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
           and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
           and rownum <= 1) c_order_code,
       (select (ols.n_billing_quantity*ols.n_price)
          from crm_t_delivery_lines dl,CRM_T_ORDER_LINES ols
         where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
           and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
           and dl.c_order_id = ols.c_pid
           and rownum <= 1) n_billing_quantity,
        (select (ols.n_delivery_quantity*ols.n_price)
          from crm_t_delivery_lines dl,CRM_T_ORDER_LINES ols
         where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
           and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
           and dl.c_order_id = ols.c_pid
           and rownum <= 1) n_delivery_quantity,
       (select oh.C_SALESMAN_POSITION
          from crm_t_delivery_lines dl, crm_t_order_header oh
         where dl.C_DELIVERY_CODE = crd.C_DELIVERY_CODE
           and dl.C_SOURCE_CODE = crd.C_CONTRACT_CODE
           and dl.C_ORDER_CODE = oh.C_ORDER_CODE
           and rownum <= 1) C_SALESMAN_POSITION
  from crm_t_contract_receipt_detail crd,
       sys_t_lov_member              lm1,
       sys_t_lov_member              lm2,
       sys_t_lov_member              lm3,
       sys_t_lov_member              lm4
 where 1 = 1
   and crd.c_salesman_post = lm3.lov_code(+)
   and crd.c_biz_dept = lm4.lov_code(+)
   and lm1.row_id(+) = crd.c_receipts_plan
   and lm2.row_id(+) = crd.c_receipts_stage
/
