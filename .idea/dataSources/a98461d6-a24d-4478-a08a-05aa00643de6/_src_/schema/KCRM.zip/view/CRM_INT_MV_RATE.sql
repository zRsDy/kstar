CREATE VIEW CRM_INT_MV_RATE AS SELECT primary.conversion_type,
    primary.from_currency,
    primary.to_currency,
    primary.conversion_date,
    primary.conversion_rate
FROM APPS.gl_daily_rates@crm_erp primary
/
