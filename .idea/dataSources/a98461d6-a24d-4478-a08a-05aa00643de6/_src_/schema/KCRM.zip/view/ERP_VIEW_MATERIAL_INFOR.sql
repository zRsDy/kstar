CREATE VIEW ERP_VIEW_MATERIAL_INFOR AS select msi.attribute12 as PROD_NAME,
       msi.description as PROD_DESC,
       msi.segment1 as SEGMENT,
       msi.attribute14 as PRE_DEFINE_SEGMENT,
       msi.attribute13 as PROD_MODEL,
       msi.attribute15 as PARENT_PROD,
       decode(upper(msi.attribute1), 'ROHS', 'Y', 'N') as IS_RoHS,
       ood.ORGANIZATION_CODE as INV_ORG,
       msi.primary_uom_code as PRIMARY_UOM_CODE,
       msi.attribute11 as BRAND,
       (select substr(DESCRIPTION, 1, instr(DESCRIPTION, '.', 1, 1) - 1)
          from inv.mtl_item_categories@crm_erp mic,
               apps.MTL_CATEGORIES_V@crm_erp   mcv
         where mic.CATEGORY_ID = mcv.category_id
           and organization_id = 101
           and inventory_item_id = msi.inventory_item_id
           and CATEGORY_set_id = 1100000041
           and rownum <= 1) as PROD_CATEGORY,

       (select substr(DESCRIPTION,
                      instr(DESCRIPTION, '.', 1, 1) + 1,
                      instr(DESCRIPTION, '.', 1, 2) -
                      instr(DESCRIPTION, '.', 1, 1) - 1)
          from inv.mtl_item_categories@crm_erp mic,
               apps.MTL_CATEGORIES_V@crm_erp   mcv
         where mic.CATEGORY_ID = mcv.category_id
           and organization_id = 101
           and inventory_item_id = msi.inventory_item_id
           and CATEGORY_set_id = 1100000041
           and rownum <= 1) as PROD_TYPE,

       (select substr(DESCRIPTION,
                      instr(DESCRIPTION, '.', 1, 2) + 1,
                      instr(DESCRIPTION, '.', 1, 3) -
                      instr(DESCRIPTION, '.', 1, 2) - 1)
          from inv.mtl_item_categories@crm_erp mic,
               apps.MTL_CATEGORIES_V@crm_erp   mcv
         where mic.CATEGORY_ID = mcv.category_id
           and organization_id = 101
           and inventory_item_id = msi.inventory_item_id
           and CATEGORY_set_id = 1100000041
           and rownum <= 1) as PROD_SERIES,

       (select substr(DESCRIPTION, instr(DESCRIPTION, '.', 1, 3) + 1)
          from inv.mtl_item_categories@crm_erp mic,
               apps.MTL_CATEGORIES_V@crm_erp   mcv
         where mic.CATEGORY_ID = mcv.category_id
           and organization_id = 101
           and inventory_item_id = msi.inventory_item_id
           and CATEGORY_set_id = 1100000041
           and rownum <= 1) as POWER_CAP,

       (select qrv.CHARACTER5
          from APPS.QA_RESULTS_V@crm_erp       qrv,
               APPS.mtl_categories_v@crm_erp   mcv,
               inv.mtl_item_categories@crm_erp micc
         where mcv.CATEGORY_ID = micc.category_id
           and micc.inventory_item_id = msi.inventory_item_id
           and micc.organization_id = msi.organization_id
           and micc.category_set_id = 1100000041
           and qrv.NAME = 'MFG_PRODUCTSERIES_DEPARTMENT'
           and qrv.CHARACTER1 =
               mcv.SEGMENT1 || mcv.SEGMENT2 || mcv.SEGMENT3 || mcv.SEGMENT4
           and rownum <= 1)  as PROD_MRG_DEPT,

       (select qrv.CHARACTER2
          from APPS.QA_RESULTS_V@crm_erp       qrv,
               APPS.mtl_categories_v@crm_erp   mcv,
               inv.mtl_item_categories@crm_erp micc
         where mcv.CATEGORY_ID = micc.category_id
           and micc.inventory_item_id = msi.inventory_item_id
           and micc.organization_id = msi.organization_id
           and micc.category_set_id = 1100000041
           and qrv.NAME = 'MFG_PRODUCTSERIES_DEPARTMENT'
           and qrv.CHARACTER1 =
               mcv.SEGMENT1 || mcv.SEGMENT2 || mcv.SEGMENT3 || mcv.SEGMENT4
           and rownum <= 1) as PROD_GROUP,

       (select qrv.CHARACTER3
          from APPS.QA_RESULTS_V@crm_erp       qrv,
               APPS.mtl_categories_v@crm_erp   mcv,
               inv.mtl_item_categories@crm_erp micc
         where mcv.CATEGORY_ID = micc.category_id
           and micc.inventory_item_id = msi.inventory_item_id
           and micc.organization_id = msi.organization_id
           and micc.category_set_id = 1100000041
           and qrv.NAME = 'MFG_PRODUCTSERIES_DEPARTMENT'
           and qrv.CHARACTER1 =
               mcv.SEGMENT1 || mcv.SEGMENT2 || mcv.SEGMENT3 || mcv.SEGMENT4
           and rownum <= 1) as PROD_LINE,

       '0001' as CRM_PROD_CATEGORY,
       /*greatest(msi.last_update_date,nvl((select max(mic.last_update_date) last_update_date
          from inv.mtl_item_categories@crm_erp mic,
               apps.MTL_CATEGORIES_V@crm_erp   mcv
         where mic.CATEGORY_ID = mcv.category_id
           and organization_id = 101
           and inventory_item_id = msi.inventory_item_id
           and CATEGORY_set_id = 1100000041
           and rownum <= 1),msi.last_update_date)) last_update_date,*/
       msi.last_update_date,
       (select SEGMENT1
          from inv.mtl_item_categories@crm_erp mic,
               apps.MTL_CATEGORIES_V@crm_erp   mcv
         where mic.CATEGORY_ID = mcv.category_id
           and mic.organization_id = 101
           and mic.inventory_item_id = msi.inventory_item_id
           and CATEGORY_set_id = 1
           and rownum <= 1) as ERP_PROD_CATEGORY,

       '' as VENDOR,
       msi.unit_weight *
       decode(msi.weight_uom_code, 'G', 0.001, 'KG', 1, '?', 1000) as UNIT_WEIGHT,
       msi.attribute7 as WEIGHT,
       msi.unit_length *
       decode(msi.dimension_uom_code, 'M', 1000, 'CM', 10) as PROD_LENGTH,
       msi.unit_width * decode(msi.dimension_uom_code, 'M', 1000, 'CM', 10) as PROD_WIDTH,
       msi.unit_height *
       decode(msi.dimension_uom_code, 'M', 1000, 'CM', 10) as PROD_HEIGHT,
       '' as PACK_LENGTH,
       '' as PACK_WIDTH,
       '' as PACK_HEIGH,
       '' as CAB_QTY1,
       '' as CAB_QTY2,
       '' as CAB_QTY3,
       '' as CAB_QTY4,
       msi.customer_order_flag as CUST_ORDER_FLAG,
       msi.returnable_flag as RETURN_ABLE_FLAG,
       msi.inventory_item_flag as INVENTORY_ITEM_FLAG,
       (case when  msi.CUSTOMER_ORDER_FLAG = 'Y' and msi.CUSTOMER_ORDER_ENABLED_FLAG = 'Y' and msi.INVENTORY_ITEM_STATUS_CODE<>'Inactive'
        and msi.INVENTORY_ITEM_STATUS_CODE<>'LogOut'
        then 'Y' else 'N' end) sales_flag,
       msi.inventory_item_status_code,
       msi.attribute29 as attribute29
  from inv.mtl_system_items_b@crm_erp            msi,
       apps.ORG_ORGANIZATION_DEFINITIONS@crm_erp ood
 where msi.organization_id = ood.organization_id
   and msi.organization_id = 101
   --and msi.inventory_item_status_code <>'Inactive'
   --and msi.CUSTOMER_ORDER_FLAG = 'Y'
   --and msi.CUSTOMER_ORDER_ENABLED_FLAG = 'Y'
   and ((msi.item_type = 'KSTFG' AND exists
        (select 1
            from INV.MTL_ITEM_CATEGORIES@crm_erp mic
           where mic.inventory_item_id = msi.inventory_item_id
             and mic.organization_id = msi.organization_id
             and mic.CATEGORY_SET_ID = 1100000041)) OR
       msi.item_type <> 'KSTFG')
/
