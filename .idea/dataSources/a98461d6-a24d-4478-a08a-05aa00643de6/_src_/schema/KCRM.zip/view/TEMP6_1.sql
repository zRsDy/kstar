CREATE VIEW TEMP6_1 AS select b.c_source_id,
        b.c_source_code,
        a.c_materiel_code,
        sum(a.n_product_quantity) as n_product_quantity
   from crm_t_order_lines a, crm_t_order_header b
  where 1 = 1
    and a.c_order_code = b.c_order_code
    and a.c_erp_status <>'CANCELLED'
    and b.c_source_type = '10'
  group by b.c_source_id,
           b.c_source_code,
           a.c_materiel_code
  order by b.c_source_id
/
