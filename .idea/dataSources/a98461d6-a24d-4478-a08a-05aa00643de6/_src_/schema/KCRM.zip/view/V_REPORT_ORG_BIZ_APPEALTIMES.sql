CREATE VIEW V_REPORT_ORG_BIZ_APPEALTIMES AS SELECT
    b.CREATED_ORG_ID as org_id,
    org.LOV_PATH as org_path,
    count(b.C_PID) AS times
  FROM
    crm_t_business_opportunity b, SYS_T_LOV_MEMBER org
  WHERE b.CREATED_ORG_ID = org.ROW_ID
        AND b.CONFLICT_APPEAL = 'Y'
  GROUP BY b.CREATED_ORG_ID,org.LOV_PATH
/
