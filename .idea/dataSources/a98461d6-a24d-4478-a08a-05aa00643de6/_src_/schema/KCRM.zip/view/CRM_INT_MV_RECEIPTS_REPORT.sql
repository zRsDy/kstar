CREATE VIEW CRM_INT_MV_RECEIPTS_REPORT AS select rownum as id,
       tr.n_amount,
       tr.n_veri_amount,
       decode(tr.n_amount-tr.n_veri_amount,0,0,1) as sum_amount_count,
       decode(tr.n_amount-tr.n_veri_amount,0,0,tr.n_amount-tr.n_veri_amount) as notVeriAmount_rmb,
       get_convert_cur_amount(decode(tr.n_amount-tr.n_veri_amount,0,0,tr.n_amount-tr.n_veri_amount),tr.c_currency ,tr.dt_receipts_date,'USD') as notVeriAmount_usd,
       tr.dt_receipts_date,
       tr.c_biz_dept,
       tr.c_salesman_id,
       tr.C_SALESMAN_POST,
       org.lov_path as c_biz_dept_path
from crm_t_receipts tr,
     sys_t_lov_member org
where 1=1
  and org.row_id = tr.c_biz_dept
/
