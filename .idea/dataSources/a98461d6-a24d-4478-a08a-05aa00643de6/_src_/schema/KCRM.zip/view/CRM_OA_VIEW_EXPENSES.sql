CREATE VIEW CRM_OA_VIEW_EXPENSES AS select  t.account_name,
           g.group_name,
           a.lov_code,
           t.INVOICE_LINE_AMOUNT ,--as rmb_INVOICE_LINE_AMOUNT,
        /* get_convert_cur_amount(t.INVOICE_LINE_AMOUNT,  'CNY' ,t.Invoice_Date,'USD')
           as usd_INVOICE_LINE_AMOUNT,*/
           t.employee_no,
           t.crm_position_id,
           t.crm_position_name,
           t.crm_org_id,
           t.crm_org_name,
           T.crm_org_path,
           t.Invoice_Date,
           t.CLAIM_PERSON_NAME,
           T.ACCOUNT_DEPT,
           to_char(t.Invoice_Date,'yyyy') as year,
           to_char(t.Invoice_Date,'mm') as month
     from cux_oa_expenses_claim_data t,
           SYS_T_LOV_GROUP            g,
           sys_t_lov_member           a
     where t.account_name = a.lov_name
       and g.row_id = a.group_id
/
