CREATE VIEW KSTAR_PERFORMANCE_TRANSFER_V AS select rownum as id,
       isa.c_apply_code,
       isa.c_apply_type,
       lm4.lov_name,
       isa.c_import_unit,
       orgin.lov_name as c_import_unit_name, --引入部门名称
       orgin.code_path as c_import_unit_path, --引入部门路径
       isa.c_import_positionid,
       posin.lov_name as c_import_positionid_name, --引入岗位名称
       isa.c_import_employeeid,
       pein.no as c_import_employeeid_no,  --引入员工编号
       pein.name as c_import_employeeid_name,  -- 引入员工名称
       isa.c_export_unit,
       orgout.lov_name as c_export_unit_name, --转出部门名称
       orgout.code_path as c_export_unit_path, --转出部门路径
       isa.c_export_positionid,
       posout.lov_name as c_export_positionid_name, --转出岗位名称
       isa.c_export_employeeid,
       peout.no as c_export_employeeid_no,  -- 转出员工编号
       peout.name as c_export_employeeid_name,  -- 转出员工名称
       isa.c_export_ratio,
       isa.c_status,
       isa.c_currency,
       currency.lov_code,  --币种
       isad.c_materiel_code,
       pl.C_PRO_CATEGORY as pro_category, --产品类别
       pl.c_pro_series as pro_series, --产品系列
       isad.c_import_quantity,
       get_convert_cur_amount(isad.c_import_amount
       , currency.lov_code ,isad.c_import_date,'CNY') as c_import_rmb_amount,
       get_convert_cur_amount(isad.c_import_amount
       , currency.lov_code ,isad.c_import_date,'USD') as c_import_usd_amount,
       to_char(isad.c_import_date,'yyyy') as year,--??
       to_char(isad.c_import_date,'mm') as month,--??
       oh.c_customer_erp_code,  --customer_code
       oh.c_customer_name,  -- customer_name
       customClass.Lov_Name as custom_class, --客户类别
       customType.lov_name as custom_type, --客户行业大类
       customTypeSub.lov_name as custom_type_sub, --客户行业小类

       ci.c_custom_area_sub1 as province_id, --省份id
       lm1.lov_name          as province_name, --省份名称
       ci.c_custom_area_sub2 as city_id, --城市id
       lm2.lov_name          as city_name, --城市名称
       ci.c_custom_area_sub3 as county_id, --区县id
       lm3.lov_name          as county_name --区县名称

  from crm_t_import_sale_apply_detail isad,
       crm_t_import_sale_apply        isa,
       crm_t_order_header             oh,
       crm_t_custom_info              ci,
       crm_t_product_line             pl,
       crm_t_product_basic            pb,
       sys_t_permission_employee      pein, --引入员工
       sys_t_permission_employee      peout, -- 转出员工
       sys_t_lov_member               posin, --引入岗位
       sys_t_lov_member               posout, --转出岗位
       sys_t_lov_member               orgin, --引入部门
       sys_t_lov_member               orgout, --转出部门
       sys_t_lov_member               currency, --币种
       sys_t_lov_member               lm1, --省份
       sys_t_lov_member               lm2, --城市
       sys_t_lov_member               lm3, --区县
       sys_t_lov_member               lm4, --引入类型
       sys_t_lov_member               customClass, --客户类别
       sys_t_lov_member               customType, --客户行业大类
       sys_t_lov_member               customTypeSub --客户行业小类
 where 1 = 1
   and isa.c_pid = isad.c_apply_id
   and isa.c_apply_type = lm4.row_id(+)
   and oh.c_order_code(+) = isad.c_order_code
   and oh.c_customer_erp_code = ci.c_custom_erp_code(+)
   and pb.c_pro_code = isad.c_materiel_code
   and pb.C_PRO_LINE_ID = pl.c_pid(+)
   and pein.row_id(+) = isa.c_import_employeeid
   and peout.row_id(+) = isa.c_export_employeeid
   and posin.row_id(+) = isa.c_export_positionid
   and posout.row_id(+) =  isa.c_export_positionid
   and orgin.row_id(+) =  isa.c_import_unit
   and orgout.row_id(+) =  isa.c_export_unit
   and currency.row_id(+) = isa.c_currency
   and ci.c_custom_area_sub1 = lm1.row_id(+)
   and ci.c_custom_area_sub2 = lm2.row_id(+)
   and ci.c_custom_area_sub3 = lm3.row_id(+)
   and ci.c_custom_class = customClass.Row_Id(+)
   and ci.c_custom_category = customType.Row_Id(+)
   and ci.c_custom_category_sub = customTypeSub.Row_Id(+)
   --and isa.c_status = '30'
/
