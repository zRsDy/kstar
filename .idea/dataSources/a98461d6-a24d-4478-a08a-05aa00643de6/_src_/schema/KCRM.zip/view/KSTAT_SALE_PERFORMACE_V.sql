CREATE VIEW KSTAT_SALE_PERFORMACE_V AS select rownum as id,
oh.c_salesman_code     as salesman_no, --??,
       oh.c_salesman_id       as salesman_id, --??ID,    create table kstat_sale_performace_v_1 as select * from kstat_sale_performace_v;

       oh.c_salesman_name     as salesman_name, --???,
       oh.c_customer_erp_code as customer_code, --ERP????,
       oh.c_customer_name     as customer_name,--????,
      -- ci.c_custom_category       as custom_type, --????,
      -- ci.c_custom_category_sub       as custom_type_sub, --????,
       customClass.Lov_Name   as custom_class,
       customType.lov_name    as custom_type,
       customTypeSub.lov_name as custom_type_sub,
       oh.c_salesman_position as salesman_position_id, --????,
       lm4.lov_name           as salesman_position_name,--????,
       org.parent_id          as parent_org_id,
       org.row_id             as salesman_org_id, --??ID,
       org.lov_name           as salesman_org_name, --????,
       org.lov_path           as salesman_org_path, --????,

       to_char(dl.dt_print_time,'yyyy') as year,--??
       to_char(dl.dt_print_time,'mm') as month,--??

       case
         when lm1.lov_name is null then  '??'
       else
       '??'
       end  as country,--???

       (dl.n_price*(n_delivery_quantity-dl.n_invoice_quantity)) as n_billing_quantity,
       (dl.n_invoice_quantity*dl.n_price) as n_delivery_quantity,
       --(select sum(ol.n_product_quantity) from crm_t_order_lines ol where ol.c_return_reference = dl.c_order_code||'/'||dl.c_order_line_no) as n_return_quantity,
       --(select sum(ol.n_amount) from crm_t_order_lines ol where ol.c_return_reference = dl.c_order_code||'/'||dl.c_order_line_no) as n_return_amount,

       ci.c_custom_area_sub1  as province_id,--??1,
       lm1.lov_name           as province_name,--??,
       ci.c_custom_area_sub2  as city_id,--??2,
       lm2.lov_name           as city_name,--??,
       ci.c_custom_area_sub3  as county_id,--??3,
       lm3.lov_name           as county_name,--??,
       oh.c_currency          as currency,--??,

       dl.c_materiel_code     as materiel_code,--????,
      -- dl.c_materiel_name     as materiel_name,--??,
       pl.C_PRO_CATEGORY      as pro_category, --????,
       pl.c_pro_series        as pro_series,--????
       --dl.c_unit              as ??,
       --dl.n_delivery_quantity as ????,
       --dl.n_price             as ??,

       get_convert_cur_amount((nvl(dl.n_delivery_amount,0)+nvl((select sum(ol.n_amount) from crm_t_order_lines ol where ol.c_return_reference = dl.c_order_code||'/'||dl.c_order_line_no),0))
       ,  oh.c_currency ,dl.dt_print_time,'CNY') as rmb_amount,
       get_convert_cur_amount((nvl(dl.n_delivery_amount,0)+nvl((select sum(ol.n_amount) from crm_t_order_lines ol where ol.c_return_reference = dl.c_order_code||'/'||dl.c_order_line_no),0))
       ,  oh.c_currency ,dl.dt_print_time,'USD') as usd_amount，
      -- dl.n_delivery_amount   as rmb_amount,--RMB??
       --dl.n_delivery_amount   as usd_amount--RMB??
       dl.n_invoice_quantity as invoice_quantity,
       dl.n_price,
       dl.n_delivery_quantity as delivery_quantity ,
       dl.dt_print_time,  --打印日期
       dl.c_erp_order_code,  --ERP订单号
       dl.c_external_no,-- ERP外部出货单号
       dl.c_order_code, -- CRM订单号
       dl.c_delivery_code -- CRM出货申请单号

  from crm_t_delivery_lines  dl,
       crm_t_delivery_header dh,
       crm_t_order_header    oh,
       crm_t_custom_info   ci,
       crm_t_product_line  pl,
       crm_t_product_basic pb,
       sys_t_lov_member    lm1,
       sys_t_lov_member    lm2,
       sys_t_lov_member    lm3,
       sys_t_lov_member    lm4,
       sys_t_lov_member    posinorg,
       sys_t_lov_member    org,
       sys_t_lov_member    pos,
       sys_t_lov_member    customClass,
       sys_t_lov_member    customType,
       sys_t_lov_member    customTypeSub
 where 1 = 1
   and dl.c_order_code = oh.c_order_code
   and oh.c_salesman_position = lm4.lov_code(+)
   and dl.c_delivery_code = dh.c_delivery_code
   and dl.c_delete_flag = '0'
   and dh.c_status = '30'
   and pb.c_pro_code = dl.c_materiel_code
   and pb.C_PRO_LINE_ID = pl.c_pid(+)
   and oh.C_CUSTOMER_CODE = ci.c_custom_code
   and ci.c_custom_area_sub1 = lm1.row_id(+)
   and ci.c_custom_area_sub2 = lm2.row_id(+)
   and ci.c_custom_area_sub3 = lm3.row_id(+)
   and oh.c_salesman_position = pos.row_id(+)
   and pos.opt_txt1 = posinorg.row_id(+)
   and posinorg.parent_id = org.row_id(+)
   and ci.c_custom_class = customClass.Row_Id(+)
   and ci.c_custom_category = customType.Row_Id(+)
   and ci.c_custom_category_sub = customTypeSub.Row_Id(+)
   and  dl.dt_print_time is not null
   and lm4.group_code ='POSITION'
/
