CREATE VIEW CRM_INT_CONTRACT_VIEW AS SELECT T.C_BUSS_ENITY, -- ????
       T.C_CUST_CODE, -- ????
       T.C_CUST_NAME, -- ????
       T.C_ERP_ORDER_CUST_ID, -- ERP????ID
       T.C_ERP_ORDER_CUST_NAME, -- ERP????
       T.C_CONTR_NAME, -- ????
       T.C_CONTR_STAT, -- ????
       T.C_CONTR_NO, -- ??????
       T.C_CREATOR, -- ????
			 EMP.NO C_CREATOR_NO, -- ??????
       T.N_TOTAL_AMT, -- ???
       T.UPDATED_AT,
			 T.C_CONTR_VER,
			 T.C_IS_VALID
  FROM CRM_T_CONTR_BASIC T, SYS_T_LOV_MEMBER LV,SYS_T_PERMISSION_EMPLOYEE EMP
 WHERE LV.GROUP_CODE = 'CONTRACTSTATUS'
   AND T.C_CONTR_STAT = LV.ROW_ID
	 AND T.C_IS_VALID = '1' -- ????
   AND LV.LOV_CODE IN ('08', '07', '13', '12', '10')
	 AND T.C_CREATOR = EMP.ROW_ID(+)
union
select '', -- ????
       '', -- ????
       '', -- ????
       '', -- ERP????ID
       '', -- ERP????
       '', -- ????
       '', -- ????
       'KSTAR-KF-0001' C_CONTR_NO, -- ??????
       '', -- ????
			 '', -- ??????
       0, -- ???
       sysdate,
			 '',
			 ''
			 from dual
/
