CREATE VIEW KSTAT_ORDER_REPORT_V AS select  rownum as id,
            a.c_pid,
            a.c_order_code,
            a.c_salesman_id,
            a.c_customer_name,
            a.c_erp_order_code,
            b.c_line_no,
            b.c_materiel_code,
            b.c_pro_desc,
            b.c_pro_model,
            b.c_ship_org,
            b.dt_request_date,
            b.n_product_quantity,
            b.c_unit,
            b.n_erp_settlement_price,
            b.n_amount,
            b.dt_promise_date,
            b.c_confirm_delivery_date,
            b.c_is_pending,
            b.c_is_advance_billing,
            b.n_delivery_quantity,
            b.n_billing_quantity,
            b.c_status,
            b.c_erp_plan_status,
            b.c_is_erp_delivery
      from crm_t_order_header a,
           CRM_T_ORDER_LINES b
     where 1 = 1
       and a.c_pid = b.c_order_id
        and sysdate > b.dt_promise_date
        and b.c_is_erp_delivery = 'No'
        and b.c_status != 'CANCELLED'
        and b.c_status != 'ENTERED'
/
