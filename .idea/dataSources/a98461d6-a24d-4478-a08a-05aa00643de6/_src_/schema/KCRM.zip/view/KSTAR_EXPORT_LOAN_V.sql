CREATE VIEW KSTAR_EXPORT_LOAN_V AS select rownum as id,l.c_line_num,
         l.C_PRD_TYP,
         l.N_AMOUNT,
         l.N_VERIED_NUM,
         l.N_NOT_VERI_NUM,
         l.N_PRD_PRC,
         l.c_qid,
         l.c_contract_code
         from (
select
       m.c_line_num,
         m.C_PRD_TYP,
         m.N_AMOUNT,
         m.N_VERIED_NUM,
         m.N_NOT_VERI_NUM,
         m.N_PRD_PRC,
         m.c_qid, listagg(m.c_contract_code, ',') within GROUP(order by m.c_contract_code) as c_contract_code
  from (select  rownum as id,a.c_line_num,
         a.C_PRD_TYP,
         a.N_AMOUNT,
         a.N_VERIED_NUM,
         a.N_NOT_VERI_NUM,
         a.n_Prd_Prc,
         a.c_qid,
         b.c_contract_code
    from CRM_T_PRJ_LST a, crm_t_contr_veri_detail b
   where a.C_PID = b.c_loan_prjlst_id(+)) m
 group by  m.c_line_num,
          m.C_PRD_TYP,
          m.N_AMOUNT,
          m.N_VERIED_NUM,
          m.N_NOT_VERI_NUM,
          m.N_PRD_PRC,
          m.c_qid
   order by m.c_qid,m.c_line_num,c_contract_code) l
/
