CREATE VIEW KSTAT_SALE_PERFORMACE_V_0801 AS select


oh.c_salesman_code     as salesman_no, --??,
       oh.c_salesman_id       as salesman_id, --??ID,
       oh.c_salesman_name     as salesman_name, --???,
       oh.c_customer_erp_code as customer_code, --ERP????,
       oh.c_customer_name     as customer_name,--????,
      -- ci.c_custom_category       as custom_type, --????,
      -- ci.c_custom_category_sub       as custom_type_sub, --????,
       customType.lov_name    as custom_type,
       customTypeSub.lov_name as custom_type_sub,
       oh.c_salesman_position as salesman_position_id, --????,
       lm4.lov_name           as salesman_position_name,--????,
       org.parent_id          as parent_org_id,
       org.row_id             as salesman_org_id, --??ID,
       org.lov_name           as salesman_org_name, --????,
       org.lov_path           as salesman_org_path, --????,

       to_char(dl.dt_print_time,'yyyy') as year,--??
       to_char(dl.dt_print_time,'mm') as month,--??

       case
         when lm1.lov_name is null then  '??'
       else
       '??'
       end  as country,--???

       ci.c_custom_area_sub1  as province_id,--??1,
       lm1.lov_name           as province_name,--??,
       ci.c_custom_area_sub2  as city_id,--??2,
       lm2.lov_name           as city_name,--??,
       ci.c_custom_area_sub3  as county_id,--??3,
       lm3.lov_name           as county_name,--??,
       oh.c_currency          as currency,--??,

       dl.c_materiel_code     as materiel_code,--????,
      -- dl.c_materiel_name     as materiel_name,--??,
       pl.c_pro_category      as pro_category, --????,
       pl.c_pro_series        as pro_series,--????
       --dl.c_unit              as ??,
       --dl.n_delivery_quantity as ????,
       --dl.n_price             as ??,
       dl.n_delivery_amount   as rmb_amount,--RMB??
       dl.n_delivery_amount   as usd_amount--RMB??

  from crm_t_delivery_lines  dl,
       crm_t_delivery_header dh,
       crm_t_order_header    oh,
       crm_t_custom_info   ci,
       crm_t_product_line  pl,
       crm_t_product_basic pb,
       sys_t_lov_member    lm1,
       sys_t_lov_member    lm2,
       sys_t_lov_member    lm3,
       sys_t_lov_member    lm4,
       sys_t_lov_member    posinorg,
       sys_t_lov_member    org,
       sys_t_lov_member    pos,
       sys_t_lov_member    customType,
       sys_t_lov_member    customTypeSub
 where 1 = 1
   and dl.c_order_code = oh.c_order_code
   and oh.c_salesman_position = lm4.lov_code(+)
   and dl.c_delivery_code = dh.c_delivery_code
   and dl.c_delete_flag = '0'
   and dh.c_status = '30'
   and pb.c_pro_code = dl.c_materiel_code
   and pb.C_PRO_LINE_ID = pl.c_pid(+)
   and oh.C_CUSTOMER_CODE = ci.c_custom_code
   and ci.c_custom_area_sub1 = lm1.row_id(+)
   and ci.c_custom_area_sub2 = lm2.row_id(+)
   and ci.c_custom_area_sub3 = lm3.row_id(+)
   and oh.c_salesman_position = pos.row_id(+)
   and pos.opt_txt1 = posinorg.row_id(+)
   and posinorg.parent_id = org.row_id(+)
   and ci.c_custom_category = customType.Row_Id(+)
   and ci.c_custom_category_sub = customTypeSub.Row_Id(+)
   and  dl.dt_print_time is not null
/
