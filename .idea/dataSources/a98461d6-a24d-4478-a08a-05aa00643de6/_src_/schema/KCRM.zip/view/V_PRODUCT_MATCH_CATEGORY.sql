CREATE VIEW V_PRODUCT_MATCH_CATEGORY AS SELECT
    pb.c_pid          AS productId,
    pcm.c_pid         AS matchId,
    pcm.DT_START_TIME AS startTime,
    pcm.DT_END_TIME   AS endTime,
    pb.c_pro_name     AS productName,
    pb.C_PRO_DESC     AS productDesc,
    c.ROW_ID          AS CATEGORYID
  FROM CRM_T_PRODUCT_CATALOG_MATCH pcm,
    CRM_T_PRODUCT_BASIC pb LEFT JOIN CRM_T_PRODUCT_LINE pl ON pl.c_pid = pb.c_pro_line_id ,
    CRM_T_PRODUCT_DEMAND pd INNER JOIN CRM_T_PRODUCT_DEMAND_REL pdr ON pd.C_PID=pdr.C_DEMAND_ID,
    SYS_T_LOV_MEMBER c
  WHERE pcm.C_DIRECT_ID=c.ROW_ID
        and pb.C_PID=pdr.C_PRODUCT_ID
        AND pcm.c_effective = 'Y'
        AND pcm.dt_start_time <= sysdate
        AND nvl(pcm.dt_end_time, sysdate + 1) >= sysdate
        and pcm.C_CRM_CATEGORY = pb.C_PRO_CRM_CATEGORY
        AND (pcm.c_pro_category IS NULL OR pcm.c_pro_category = pl.C_PRO_CATEGORY)
        AND (pcm.C_PRO_MODEL IS NULL OR pcm.c_pro_model = pb.c_pro_model)
        AND (pcm.C_DEPARTMENT IS NULL OR exists(SELECT 1
                                                FROM SYS_T_LOV_MEMBER org
                                                WHERE org.ROW_ID = pd.C_CREATED_ORG_ID
                                                      AND instr(org.LOV_PATH, pcm.C_DEPARTMENT) > 0))
/
