CREATE VIEW TEMP4 AS select a.c_businees_code    as 合同编码,
       a.c_pid              as 工程清单ID,
       a.n_prd_prc          as 单价_合同,
       b.n_price            as 单价_订单,
       a.n_amount           as 数量_合同,
       b.n_product_quantity as 数量_订单,
       a.n_ttl_unt          as 单品总金额,
       b.n_amount           as 总金额,
       b.c_order_code       as 订单编码,
       b.c_pro_model        as 产品型号,
       b.c_materiel_code    as 物料号,
       b.c_item_description
  from CRM_T_PRJ_LST a, crm_t_order_lines b
 where 1 = 1
   and a.c_businees_code = b.c_source_code
   and a.c_pid = b.c_pro_brand
 order by a.c_businees_code, a.c_pid
/
