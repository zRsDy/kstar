CREATE VIEW KSTAT_SALE_PERFORMACE_V_NEW AS select rownum as id,
       oh.c_salesman_code     as salesman_no, --??,
       dh.c_delivery_code     as delivery_code,
       oh.c_salesman_id       as salesman_id, --??ID,
       oh.c_salesman_name     as salesman_name, --???,
       oh.c_customer_erp_code as customer_code, --ERP????,
       oh.c_customer_name     as customer_name,--????,
      -- ci.c_custom_category       as custom_type, --????,
      -- ci.c_custom_category_sub       as custom_type_sub, --????,
     --  customClass.Lov_Name   as custom_class,
     --  customType.lov_name    as custom_type,
      -- customTypeSub.lov_name as custom_type_sub,
       oh.c_salesman_position as salesman_position_id, --????,
       lm4.lov_name           as salesman_position_name,--????,
       org.parent_id          as parent_org_id,
       org.row_id             as salesman_org_id, --??ID,
       org.lov_name           as salesman_org_name, --????,
       org.lov_path           as salesman_org_path, --????,

       to_char(dl.dt_print_time,'yyyy') as year,--??
       to_char(dl.dt_print_time,'mm') as month,--??

     /*  case
         when lm1.lov_name is null then  '??'
       else
       '??'
       end  as country,--???*/

       (dl.n_price*(n_delivery_quantity-dl.n_invoice_quantity)) as n_billing_quantity_rmb,
       (dl.n_invoice_quantity*dl.n_price) as n_delivery_quantity_rmb,

       get_convert_cur_amount((dl.n_price*(n_delivery_quantity-dl.n_invoice_quantity)),  oh.c_currency ,dl.dt_print_time,'USD') as n_billing_quantity_usd,
       get_convert_cur_amount((dl.n_invoice_quantity*dl.n_price),  oh.c_currency ,dl.dt_print_time,'USD') as n_delivery_quantity_usd,
     --  ci.c_custom_area_sub1  as province_id,--??1,
     --  lm1.lov_name           as province_name,--??,
     --  ci.c_custom_area_sub2  as city_id,--??2,
     --  lm2.lov_name           as city_name,--??,
     --  ci.c_custom_area_sub3  as county_id,--??3,
      -- lm3.lov_name           as county_name,--??,
       oh.c_currency          as currency,--??,

       dl.c_materiel_code     as materiel_code,--????,
      -- dl.c_materiel_name     as materiel_name,--??,
     -- pl.C_PRO_CATEGORY      as pro_category, --????,
      -- pl.c_pro_series        as pro_series,--????
       --dl.c_unit              as ??,
       --dl.n_delivery_quantity as ????,
       --dl.n_price             as ??,

       get_convert_cur_amount(dl.n_delivery_amount,  oh.c_currency ,dl.dt_print_time,'CNY') as rmb_amount,
       get_convert_cur_amount(dl.n_delivery_amount,  oh.c_currency ,dl.dt_print_time,'USD') as usd_amount
      -- dl.n_delivery_amount   as rmb_amount,--RMB??
       --dl.n_delivery_amount   as usd_amount--RMB??

  from crm_t_delivery_lines  dl,
       crm_t_delivery_header dh,
       crm_t_order_header    oh,

       sys_t_lov_member    lm4,
       sys_t_lov_member    posinorg,
       sys_t_lov_member    org,
       sys_t_lov_member    pos
 where 1 = 1
   and dl.c_order_code = oh.c_order_code
   and oh.c_salesman_position = lm4.lov_code(+)
   and dl.c_delivery_code = dh.c_delivery_code
   and dl.c_delete_flag = '0'
   and dh.c_status = '30'

   and oh.c_salesman_position = pos.row_id(+)
   and pos.opt_txt1 = posinorg.row_id(+)
   and posinorg.parent_id = org.row_id(+)

   and  dl.dt_print_time is not null
/
