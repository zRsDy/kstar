CREATE VIEW CRM_INT_MV_INVOICE AS SELECT
      ide.ROWID AS DRROWID,
      dl.ROWID AS DLROWID,
      ol.ROWID AS OLROWID,
      idh.ROWID AS IDHROWID,
      ide.C_ORDER_CODE,
      DL.C_DELIVERY_CODE,
      ide.C_INVOICE_CODE ,
      DECODE(ide.C_INVOICE_TYPE,'02',dl.C_ORDER_LINE_NO,'01',ol.C_LINE_NO) as C_LINE_NUM,
      ide.N_INVOICE_QTY,
      ide.N_BILLED_QTY,
      ide.C_ERP_IMPORT_FLAG,
      idh.C_GOLDEN_TAX_NO,
      greatest(ide.dt_updated_at,idh.DT_UPDATED_AT) as LAST_UPDATE_DATE,
      ide.C_ERROR_MESSAGE,
      ide.C_INVOICE_TYPE
FROM KCRM.CRM_T_INVOICE_DETAIL ide,
     KCRM.CRM_T_INVOICE_MASTER idh,--add by zhucheng add approved condition
     KCRM.CRM_T_DELIVERY_LINES dl,
     KCRM.CRM_T_ORDER_LINES ol
WHERE 1=1 AND ide.C_DELIVERY_LINE_ID = dl.C_PID(+)
    AND idh.C_PID=ide.C_INVOICE_ID and idh.C_STATUS='30'
    and ide.C_ORDER_LINE_ID = ol.C_PID(+)
    and DECODE(ide.C_INVOICE_TYPE,'02',dl.C_ORDER_LINE_NO,'01',ol.C_LINE_NO) is not null
/
