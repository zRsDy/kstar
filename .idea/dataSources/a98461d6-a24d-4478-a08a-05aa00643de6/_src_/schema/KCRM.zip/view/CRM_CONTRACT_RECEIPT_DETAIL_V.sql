CREATE VIEW CRM_CONTRACT_RECEIPT_DETAIL_V AS select de.c_pid,
       de.c_cust_id,
       --de.c_cust_code,
       cust.c_custom_erp_code as c_cust_code,
       de.c_cust_name,
       de.c_contract_id,
       de.c_contract_code,
       de.c_contrpay_id,
       de.c_receipts_plan,
       de.c_receipts_stage,
       de.c_delivery_id,
       de.c_delivery_code,
       de.n_plan_amount,
       de.n_veri_amount,
       de.c_receipts_type,
       de.c_business_entity,
       de.c_biz_dept,
       de.dt_payment_date,
       de.c_remarks,
       de.c_explain,
       de.c_status,
       de.C_SALES_SORT,
       de.dt_updated_at,
       de.c_updated_by_id,
       de.c_created_org_id,
       de.c_created_pos_id,
       de.C_SALES_CENTER,
       de.dt_created_at,
       de.c_created_by_id,
       t1.business_id,
       t1.c_salesman_name,
       t1.c_salesman_code,
       t1.c_salesman_id,
       t1.c_salesman_post
  from
       crm_t_custom_info cust,
       crm_t_contract_receipt_detail de
       LEFT JOIN
       (select * from
       crm_contract_receipt_team_v tt  where
       tt.row_id in (
           select t2.row_id from crm_contract_receipt_team_v t2 where t2.business_id = tt.business_id and rownum=1
           )
       ) t1
       on de.c_pid=t1.business_id
  where cust.c_custom_code = de.c_cust_code
/
