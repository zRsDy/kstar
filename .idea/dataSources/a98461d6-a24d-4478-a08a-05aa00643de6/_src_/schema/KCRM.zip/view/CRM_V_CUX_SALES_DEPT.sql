CREATE VIEW CRM_V_CUX_SALES_DEPT AS select  a.所属部门 org_name,a.部门代码 org_code from apps.cux_sales_dept_v@crm_erp a
/
