CREATE VIEW CRM_INT_MV_DELIVERY AS SELECT dh.rowid               AS dhrowid,
       dl.rowid               AS dlrowid,
       dr.rowid               AS drrowid,
       dh.c_delivery_code,
       dl.c_order_line_no     AS c_line_num,
       dl.c_order_code,
       dl.n_delivery_quantity AS deliv_sum_qty,
       dr.c_receipt_code,
       --dh.C_DELIVERY_ADDRESS,
       dr.c_receiving_address c_delivery_address,
       nvl(dr.c_consignee, dh.c_consignee) c_consignee,
       nvl(dr.c_consignee_tel, dh.c_consignee_tel) c_consignee_tel,
       dr.n_delivery_quantity AS send_sum_qty,
       dh.c_remarks,
       dl.c_external_no,
       dh.c_delete_flag AS c_delete_flag_h,
       dl.c_delete_flag AS c_delete_flag_l,
       dr.c_delete_flag AS c_delete_flag_r,
       dr.c_logistics_company AS c_logistics_company,
       greatest(dh.dt_updated_at, dl.dt_updated_at, dr.dt_updated_at) AS last_update_date,
       dr.dt_updated_at AS created_date,
       dh.c_business_manager_code,
       dl.c_erp_import_flag dl_erp_imp_flag,
       dr.c_erp_import_flag dr_erp_imp_flag
  FROM kcrm.crm_t_delivery_header  dh,
       kcrm.crm_t_delivery_lines   dl,
       kcrm.crm_t_delivery_receipt dr
 WHERE dh.c_pid = dl.c_delivery_id
   AND dl.c_delivery_code = dr.c_delivery_code
   AND dl.c_order_code = dr.c_order_code
   AND dl.c_order_line_no = dr.c_order_line_no
   AND dl.c_line_num = dr.c_delivery_lines_num
   AND dh.c_status = '30'
/
