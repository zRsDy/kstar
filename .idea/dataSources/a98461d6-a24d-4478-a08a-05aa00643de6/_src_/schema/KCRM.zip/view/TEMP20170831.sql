CREATE VIEW TEMP20170831 AS select a.c_qid,
       a.c_businees_code,
       a.c_mater_code,
       --a.n_prd_prc,
       (sum(a.n_amount) - sum(a.n_veried_num)) as n_amount,
       d.c_materiel_code,
        sum(d.n_product_quantity) as n_product_quantity
  from CRM_T_PRJ_LST a, crm_t_contr_basic b,crm_t_order_header c,crm_t_order_lines d
 where 1 = 1
   and a.c_qid = b.c_id
   and b.c_is_valid = '1'
   and c.c_source_type = '10'
   and d.c_erp_status <>'CLOSED'
   and c.c_source_id = b.c_id
   and d.c_order_id = c.c_pid
   and d.c_materiel_code = a.c_mater_code
 group by a.c_businees_code, a.c_mater_code, a.c_qid, d.c_materiel_code
 order by a.c_qid, a.c_mater_code
/
