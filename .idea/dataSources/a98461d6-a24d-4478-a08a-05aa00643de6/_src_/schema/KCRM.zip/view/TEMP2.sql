CREATE VIEW TEMP2 AS select distinct a.title,
       b.process_instance_id,
       b.activity_type,
       b.start_time,
       b.end_time,
       b.activity_id,
       b.activity_name,
       b.to_activity_id,
       b.to_activity_name,
       b.to_transition_id,
       b.to_transition_name,
       b.status,
       b.ccomment,
       b.order_no,
       c.business_key,
       c.process_definition_id,c.process_definition_name,
       c.application,
       e.name,
       e.no || '`' as userNo,
       e.row_id as userId,
      substr(o.name_path,12,instr(o.name_path,'/',12)-12) as name_path
  from XFLOW_HISTORY             b,
       XFLOW_TASK                a,
       XFLOW_PROCESS_INSTANCE    c,
       sys_t_permission_employee e,
       sys_t_permission_user_rel up,
       sys_t_lov_member p,
       sys_t_lov_member o
 where 1 = 1
   and a.process_instance_id = b.process_instance_id
   --and a.process_instance_id = '351DE88731AA47A7A55F0208D28700B0'
   and b.process_instance_id = c.row_id
   and b.operator_id = e.row_id(+)
   and e.row_id = up.user_id(+)
   and (up.type is null or up.type = 'P')
    and up.member_id = p.row_id(+)
   and p.opt_txt1 = o.row_id(+)
 order by b.process_instance_id, b.start_time, b.order_no
/
