CREATE VIEW TEMP5 AS select a.c_qid,
       a.c_businees_code,
       a.c_mater_code,
       a.n_prd_prc,
       sum(a.n_amount) as n_amount
  from CRM_T_PRJ_LST a,crm_t_contr_basic b where 1=1 and a.c_qid = b.c_id and  b.c_is_valid = '1'
 group by a.c_businees_code, a.n_prd_prc, a.c_mater_code, a.c_qid
 order by a.c_qid
/
