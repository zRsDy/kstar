CREATE VIEW CRM_INT_MV_RECEIPTS AS select /*tr.ROWID AS TRROWID,
       cst.ROWID AS CSTROWID,
       cec.ROWID AS CECROWID,*/
       tr.C_PID,
       rectp.LOV_NAME receipt_type,
       tr.c_receipts_code,
       tr.dt_receipts_date,
       cst.lov_name as c_status,
       tr.c_business_name,
       tr.c_payment_customer_name,
       cec.lov_name as c_erp_cust,
       tr.c_correct_cust_name,
       tr.c_receipts_bank,
       tr.c_bank_account,
       tr.c_currency,
       tr.n_arrival_amount,
       tr.n_poundage,
       tr.n_freight,
       tr.n_amount,
       tr.c_remarks,
       tr.C_ERP_IMP,
       tr.C_ERROR_MESSAGE,
       tr.dt_updated_at as LAST_UPDATE_DATE
from crm_t_receipts tr,
     kcrm.sys_t_lov_member cst,
     kcrm.sys_t_lov_member cec,
     kcrm.sys_t_lov_member rectp
where (tr.c_status =cst.lov_code(+) and cst.group_code='RECEIPT_STATUS')
      and (decode(tr.c_erp_cust,'No','0','Yes','1','No') =cec.lov_code(+) and cec.group_code='NY')
      and rectp.group_code = 'RECEIPTSTYPE' and tr.C_RECEIPTS_TYPE=rectp.LOV_CODE
      --and cst.lov_name='???'
/
