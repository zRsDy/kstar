CREATE VIEW CRM_INT_CUSTOMER_INFOR AS SELECT c.C_CUSTOM_FULL_NAME,
       c.C_CUSTOM_ALIAS_NAME,
       c.C_CUSTOM_CODE,
       t_cca.b_lov_code      as C_CUSTOM_CATEGORY_B,
       t_cca.s_lov_code      as C_CUSTOM_CATEGORY_S,
       t_cpi.sales_team_b,
       t_cpi.sales_team_s,
       t_ccl.lov_code        as C_CUSTOM_CLASS,
       -- t_ca.NAME_PATH  as C_CUSTOM_AREA,
       case
         when t_cal.lov_code = 'CN' then
          (select m.lov_code
             from crm_t_territory_info f, sys_t_lov_member m
            where f.c_code = m.row_id
              and nvl(f.c_lev1, 'NONE') = nvl(c.c_custom_area, 'NONE')
              and nvl(f.c_lev2, 'NONE') = nvl(c.c_custom_area_sub1, 'NONE')
              and nvl(f.c_lev3, 'NONE') = nvl(c.c_custom_area_sub2, 'NONE')
                 --  and nvl(f.c_lev4, 'NONE') = nvl(c.c_custom_area_sub3, 'NONE')
              and rownum = 1)
         else
          (select m.lov_code
             from crm_t_territory_info f, sys_t_lov_member m
            where f.c_code = m.row_id
              and nvl(f.c_lev1, 'NONE') = nvl(c.c_custom_area, 'NONE')
                 --  and nvl(f.c_lev4, 'NONE') = nvl(c.c_custom_area_sub3, 'NONE')
              and rownum = 1)
       end as C_CUSTOM_AREA,
       t_cal.LOV_CODE as C_CUSTOM_CNTRY,
       a.C_CUSTOM_ADDRESS,
       t_ceu.LOV_CODE as C_CORP_ERP_UNIT,
       t_ctd.LOV_CODE as C_CORP_TERM_DEFAULT,
       t_mei.no as C_MARK_NAME,
       C.C_CUSTOM_ERP_CODE,
       greatest(c.dt_updated_at, a.dt_updated_at,nvl(i.DT_UPDATED_AT,a.dt_updated_at)) as LAST_UPDATE_DATE
  FROM KCRM.CRM_T_CUSTOM_INFO c,
       KCRM.CRM_T_CUSTOM_ADDRESS_INFO a,
       KCRM.CRM_T_TEAM stt,
       KCRM.SYS_T_LOV_MEMBER t_ccl,
       KCRM.SYS_T_LOV_MEMBER t_ca,
       KCRM.SYS_T_LOV_MEMBER t_cal,
       KCRM.SYS_T_LOV_MEMBER t_ceu,
       KCRM.SYS_T_LOV_MEMBER t_ctd,
       KCRM.CRM_T_CUSTOM_ERP_INFO i,
       KCRM.SYS_T_PERMISSION_EMPLOYEE t_mei,
       (select m.ROWID,
               m.row_id,
               m_b.lov_code as b_lov_code,
               m_b.lov_name as b_lov_name,
               m_s.lov_code as s_lov_code,
               m_s.lov_name as s_lov_name
          from sys_t_lov_member m,
               sys_t_lov_member m_b,
               sys_t_lov_member m_s
         where substr(m.lov_path,
                      instr(m.lov_path, '/', 1, 1) + 1,
                      instr(m.lov_path, '/', 1, 2) - 2) = m_b.row_id
           and substr(m.lov_path, instr(m.lov_path, '/', 1, 2) + 1, 32) =
               m_s.row_id(+)) t_cca,
       (SELECT POS.row_id,
               (select s.OPT_TXT5 as code
                  from sys_t_lov_member s
                 where s.group_code = 'ORG'
                   and s.opt_txt3 = 'A'
                 start with s.row_id = org.row_id
                connect by prior s.parent_id = s.row_id
                       and rownum = 1) as sales_team_b,
               ORG.OPT_TXT5 AS sales_team_s
          FROM SYS_T_LOV_MEMBER POS,
               SYS_T_LOV_MEMBER POS_SNAP,
               SYS_T_LOV_MEMBER ORG
         WHERE 1 = 1
           AND POS.OPT_TXT1 = POS_SNAP.ROW_ID
           AND POS.group_id = 'POSITION'
           AND POS_SNAP.PARENT_ID = ORG.ROW_ID
           AND ORG.group_code = 'ORG') t_cpi
 WHERE c.C_PID = stt.BUSINESS_ID
   AND stt.BUSINESS_TYPE(+) = 'CUSTOM_REPORT_PROC'
   AND c.C_PID = a.C_CUSTOM_PID(+)
   AND c.C_PID = i.C_CUSTOM_PID(+)
   AND c.C_CUSTOM_CATEGORY = t_cca.ROW_ID(+)
   AND c.C_CUSTOM_CLASS = t_ccl.ROW_ID(+)
   AND c.C_CUSTOM_AREA = t_ca.ROW_ID(+)
   AND a.C_AREA_LOV1 = t_cal.ROW_ID(+)
   AND i.C_CORP_ERP_UNIT = t_ceu.ROW_ID(+)
   AND c.C_CORP_TERM_DEFAULT = t_ctd.ROW_ID(+)
   AND C.C_CREATED_POS_ID = t_cpi.row_id(+)
   AND stt.MASTER_EMPLOYEE_ID = t_mei.ROW_ID(+)
   AND c.c_custom_erp_status = 'CUSTOM_NORMAL_STATUS_40'
/
