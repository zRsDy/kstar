CREATE VIEW CRM_V_DELIVERY_LINES AS SELECT
    dl.c_pid,
    dl.c_delivery_id,                    /** 发货申请单头ID*/
    dl.c_delivery_code,                  /** 发货申请单头编号 */
    dl.c_order_id,                       /** 订单行行ID */
    dl.c_order_code,                     /** 订单编号 */
    dl.c_order_type,                     /** 订单类型 */
    dl.c_single_cust_id,                 /** 下单客户ID */
    dl.c_single_cust_code,               /** 下单客户编号 */
    dl.c_single_cust_name,               /** 下单客户编号名称 */
    dl.c_single_cust_po,                 /** 下单客户PO */
    dl.c_product_model,                  /** 产品型号 */
    dl.c_materiel_code,                  /** 物料编码 */
    dl.c_materiel_name,                  /** 物料名称/产品名称 */
    dl.c_pro_desc,                       /** 产品说明 */
    dl.n_price,                          /** 单价 */
    dl.n_delivery_quantity,              /** 出货单数量 */
    dl.n_receipt_quantity,               /** 签收数量 */
    dl.n_residual_quantity,              /** 剩余数量 */
    dl.c_unit,                            /** 单位 */
    dl.n_delivery_amount,                 /** 发货产品金额 */
    dl.n_invoice_quantity,                /**开票数量 */
    dl.dt_order_date,                     /** 下单日期 */
    dl.dt_arrival_date,                   /** 客户要货日期 */
    ol.DT_PROMISE_DATE as dt_promise_date,/** 工厂承诺日期 */
    ol.C_ERP_PLAN_STATUS as c_plan_status,/** 计划状态 */
    dl.c_line_num,                        /** 行号 */
    dl.c_order_line_no,                   /** 订单行号 */
    dl.c_external_no,                     /** 出货单编号(外部) */
    dl.dt_print_time,                     /** 出货单打印日期（外部） */
    dl.c_erp_order_code,                  /** ERP订单编号 */
    dl.c_source_code,                     /** 来源编号,当来源为合同时为合同编号，当来源是渠道是为商机编号 */
    dl.c_remarks,                         /** 备注 */
    ol.BE_READY_FLAG as c_erp_status,     /** 发货单行ERP状态 */
    dl.c_create_time,                     /** 创建日期 */
    dl.c_creator,                         /** 创建人 */
    dl.c_delivery_date,                   /** 发货日期*/
    dl.C_UPDATED_BY_ID,                   /** 更新者 */
    dl.dt_updated_at,                     /** 更新时间 */
    dl.c_delete_flag,                     /** 删除标志  1已删除 0 未删除 */
    dl.c_erp_import_flag,                  /** ERP导入标志 */
    dl.c_is_post_account,                   /** 是否已过账 */
    ol.C_SHIP_ORG                          /** 发运组织*/
  FROM CRM_V_ORDER_LINES ol,CRM_T_DELIVERY_LINES dl
  where dl.c_order_line_no = ol.C_LINE_NO
        and dl.c_order_id = ol.C_PID
        and dl.c_materiel_code = ol.C_MATERIEL_CODE
/
