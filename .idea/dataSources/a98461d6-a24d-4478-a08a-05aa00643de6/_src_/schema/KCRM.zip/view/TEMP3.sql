CREATE VIEW TEMP3 AS select distinct c.process_instance_id,
                b.creator_id,
                b.creator_name,
                e1.no as creator_no,
                a.string_value        as position_id,
                p.lov_name as position_name,
                substr(o.name_path,12,instr(o.name_path,'/',12)-12) as org_name,
                b.start_time          as process_start_time,
                b.end_time            as process_end_time,
                b.process_definition_name,
                b.status,
                b.module,
                b.application,
                c.activity_id,
                c.activity_name,
                c.activity_type,
                c.ccomment,
                c.assignee_name,
                c.assignee_type,
                c.assignee_id,
                c.operator_id,
                c.operator_name,
                c.start_time,
                c.end_time,
                c.order_no,
                c.business_key
  from XFLOW_HISTORY_PROCESS_INSTANCE b,
       XFLOW_HISTORY                  c,
       xflow_history_variable         a,
       sys_t_permission_employee e1,
       sys_t_lov_member p,
       sys_t_lov_member o
 where 1 = 1
   and b.row_id = a.process_instance_id(+)
   and a.variable_key = '__positionId'
   and c.process_instance_id = b.row_id
   and b.creator_id = e1.row_id(+)
   and a.string_value = p.row_id(+)
 and p.opt_txt1 = o.row_id(+)
 order by c.process_instance_id, c.start_time, c.order_no
/
