CREATE VIEW KSTART_RECEIPT_VERI AS select rownum as id,
       t.c_business_name,                  --业务实体
       t.c_receipts_code,                  --收款单号
       t.dt_receipts_date,                 --收款日期
       get_convert_cur_amount(t.n_veri_amount,  t.c_currency ,
          t.dt_receipts_date,'CNY')
        as rmb_receipt_amount,             --收款金额(RMB)
       get_convert_cur_amount(t.n_veri_amount,  t.c_currency ,
          t.dt_receipts_date,'USD')
        as usd_receipt_amount,             --收款金额(USD)
       t.c_payment_customer_name,          --付款客户
       t.c_erp_cust,                       --是否erp客户
       t.c_correct_cust_name,              --更正客户名
       (select c.lov_name from SYS_T_LOV_MEMBER c
               where c.group_code='ORG' and c.leaf_flag = 'N'
                and c.opt_txt3 = 'A'
                and c.opt_txt5 is not null
                and c.lov_code = t.c_sales_center) as sales_center, --营销中心
       a.c_contract_code,                  --合同编号
       a.c_receipts_plan,                  --合同收款计划行
       a.c_receipts_stage,                 --收款阶段
       a.c_delivery_code,                  --出货单编号
       get_convert_cur_amount(a.n_plan_amount,  t.c_currency ,
          a.dt_veri_date,'CNY')
        as rmb_veri_plan_amount,           --计划金额(RMB)
       get_convert_cur_amount(a.n_plan_amount,  t.c_currency ,
          a.dt_veri_date,'USD')
        as usd_veri_plan_amount,           --计划金额(USD)
       get_convert_cur_amount(a.n_veri_amount,  t.c_currency ,
          a.dt_veri_date,'CNY')
        as rmb_veri_v_amount,              --核销金额(RMB)
       get_convert_cur_amount(a.n_veri_amount,  t.c_currency ,
          a.dt_veri_date,'USD')
        as usd_veri_v_amount,              --核销金额(USD)
       a.c_biz_dept,                       --业务部门
       a.c_salesman_name,                  --销售人员
       a.dt_veri_date,                     --核销日期
       a.c_contr_rece_detail_id            --关联回款计划查询ID
   from  crm_t_receipts t,
         crm_t_verification_detail a
   where t.c_pid = a.c_receipts_id
/
