CREATE VIEW KSTART_ORDER_DELIVERY_REPORT_V AS select   rownum as id,
            a.c_pid,
            a.c_order_code,
            a.c_salesman_id,
            a.c_salesman_position,
            a.c_customer_name,
            a.c_erp_order_code,
            b.c_line_no,
            b.c_materiel_code,
            b.c_pro_desc,
            b.c_pro_model,
            b.c_ship_org,
            b.dt_request_date,
            b.n_product_quantity,
            b.c_unit,
            b.n_erp_settlement_price,
            get_convert_cur_amount(b.n_amount,  a.c_currency ,c.dt_print_time,'CNY') as rmb_order_amount,
            b.dt_promise_date,
            b.c_confirm_delivery_date,
            b.c_is_pending,
            b.c_is_advance_billing,
            b.n_delivery_quantity as order_line_del_qty,
            b.n_billing_quantity,
            b.c_status,
            b.c_erp_plan_status,
            b.c_is_erp_delivery,
            a.c_salesman_name,
            get_convert_cur_amount(b.n_amount,  a.c_currency ,c.dt_print_time,'USD') as usd_order_amount,
            b.c_special_price_code,
            c.dt_print_time,
            get_convert_cur_amount(c.n_delivery_amount,  a.c_currency ,c.dt_print_time,'CNY') as rmb_del_amont,
            get_convert_cur_amount(c.n_delivery_amount,  a.c_currency ,c.dt_print_time,'USD') as usd_del_amont,
            c.n_delivery_quantity as del_qty,
            get_convert_cur_amount(c.n_price,  a.c_currency ,c.dt_print_time,'CNY') as rmb_del_price,
            get_convert_cur_amount(c.n_price,  a.c_currency ,c.dt_print_time,'USD') as usd_del_price,
            a.dt_order_date as order_date,
            to_char(a.dt_order_date,'yyyy') as order_year,
            to_char(a.dt_order_date,'mm') as order_month,
            b.c_erp_status
      from crm_t_order_header a,
           CRM_T_ORDER_LINES b,
           CRM_T_DELIVERY_LINES c
     where 1 = 1
       and a.c_pid = b.c_order_id
        --and sysdate > b.dt_promise_date
        --and b.c_is_erp_delivery = 'No'
        and b.c_status != 'CANCELLED'
        and b.c_status != 'ENTERED'
        and b.c_pid = c.c_order_id(+)
        and c.c_delete_flag = 0
        --and c.dt_print_time is null
        --and b.c_special_price_code is null
/
