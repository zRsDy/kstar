CREATE VIEW TMP AS select p.c_pid,a.pline_id from

crm_t_product_basic p left join

CRM_INT_MATERIAL_INFOR_LINE  a on a.segment = p.c_Mater_Code where a.segment is not null
/
