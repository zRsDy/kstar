CREATE VIEW CRM_INT_MATERIAL_INFOR_LINE AS (

select x.SEGMENT,x.pline_id from (

select m."SEGMENT",l.c_pid as pline_id
from CRM_T_PRODUCT_LINE_bak l
left join CRM_INT_MATERIAL_INFOR m on


     l.C_PRO_CATEGORY = m.Crm_Prod_Category
    and l.C_PRO_TYPE =  m.Prod_Type
    and l.C_PRO_SERIES =  m.Prod_Series
    and l.C_PRO_POWCAP =  m.Power_Cap
    and l.C_PRO_MANAG_DEPART =  m.Prod_Mrg_Dept
    and l.C_PRO_GROUP =  m.Prod_Group
    and l.C_PRO_LINE =  m.Prod_line  where m.segment is not null
) x group by x.SEGMENT,x.pline_id

)
/
