CREATE function get_convert_cur_amount(p_fm_amount    in number,
                                                  p_fm_currency  in varchar2,
                                                  p_convert_date in date,
                                                  p_to_currency  in varchar2)
  return number is
  l_to_amount       number;
  l_conversion_rate number;
  l_max_date        date;
  l_count           number;

  l_fm_conversion_rate number;
  l_to_conversion_rate number;
begin
  if p_fm_currency = p_to_currency then
    l_to_amount := p_fm_amount;
  else
    begin
      select conversion_rate
        into l_conversion_rate
        from CUX_GL_DAILY_RATES /*GL.GL_DAILY_RATES@CRM_ERP*/
       where conversion_type = 'Corporate'
         and from_currency = p_fm_currency
         AND TO_CURRENCY = p_to_currency
         and trunc(conversion_date) = trunc(p_convert_date)
         and rownum <= 1;
    exception
      when others then
        l_conversion_rate := NULL;
    end;
  
    if l_conversion_rate is null then
      BEGIN
        SELECT CONVERSION_DATE
          INTO l_max_date
          FROM (select max(t.CONVERSION_DATE) CONVERSION_DATE
                  from CUX_GL_DAILY_RATES /*GL.GL_DAILY_RATES@CRM_ERP*/ t
                 where conversion_type = 'Corporate'
                   and from_currency = p_fm_currency
                   AND TO_CURRENCY = p_to_currency
                 group by t.FROM_CURRENCY, t.TO_CURRENCY) T;
      EXCEPTION
        WHEN OTHERS THEN
          l_max_date := NULL;
      END;
    
      IF l_max_date IS NOT NULL THEN
        begin
          select conversion_rate
            into l_conversion_rate
            from CUX_GL_DAILY_RATES /*GL.GL_DAILY_RATES@CRM_ERP*/
           where conversion_type = 'Corporate'
             and from_currency = p_fm_currency
             AND TO_CURRENCY = p_to_currency
             and trunc(conversion_date) = trunc(l_max_date)
             and rownum <= 1;
        exception
          when others then
            l_conversion_rate := NULL;
        end;
      END IF;
    
    end if;
  
    if l_conversion_rate is null then
      begin
        select conversion_rate
          into l_fm_conversion_rate
          from CUX_GL_DAILY_RATES /*GL.GL_DAILY_RATES@CRM_ERP*/
         where conversion_type = 'Corporate'
           and from_currency = p_fm_currency
           AND TO_CURRENCY = 'CNY'
           and trunc(conversion_date) = trunc(p_convert_date)
           and rownum <= 1;
      exception
        when others then
          l_fm_conversion_rate := NULL;
      end;
    
      begin
        select conversion_rate
          into l_to_conversion_rate
          from CUX_GL_DAILY_RATES /*GL.GL_DAILY_RATES@CRM_ERP*/
         where conversion_type = 'Corporate'
           and from_currency = p_to_currency
           AND TO_CURRENCY = 'CNY'
           and trunc(conversion_date) = trunc(p_convert_date)
           and rownum <= 1;
      exception
        when others then
          l_to_conversion_rate := NULL;
      end;
      l_conversion_rate := round(l_fm_conversion_rate /
                                 l_to_conversion_rate,
                                 6);
    end if;
  
    l_to_amount := round(p_fm_amount * l_conversion_rate, 4);
  
  end if;

  return l_to_amount;
end get_convert_cur_amount;
/
