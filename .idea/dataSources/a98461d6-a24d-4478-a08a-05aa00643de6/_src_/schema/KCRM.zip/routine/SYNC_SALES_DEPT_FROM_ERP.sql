CREATE function sync_sales_dept_from_erp(str in varchar2) return  number is
  restr  number;
 cursor cur is select * from CRM_V_CUX_SALES_DEPT;
 lov_id  varchar2(40);
 cnt number;
 group_id varchar2(40);
begin

         restr :=0;
        for obj in cur loop --temp为临时变量名,自己任意起
         lov_id := sys_guid();

         --DBMS_OUTPUT.PUT_LINE(obj.org_code);
         select a.row_id into group_id from sys_t_lov_group a where 1=1 and a.group_code = 'SalesDept';

      select count(1) into cnt from sys_t_lov_member a where 1=1 and a.group_code = 'SalesDept' and a.lov_name = obj.org_name and a.lov_code = obj.org_code;
        if cnt <1 then
        insert into sys_t_lov_member
          (ROW_ID,
           LOV_CODE,
           CREATION_BY,
           CREATION_DATE,
           GROUP_ID,
           LAST_UPDATED_BY,
           LAST_UPDATED_DATE,
           LEAF_FLAG,
           LOV_LEVEL,
           MEMO,
           LOV_NAME,
           OPT_TXT1,
           OPT_TXT2,
           OPT_TXT3,
           OPT_TXT4,
           OPT_TXT5,
           PARENT_ID,
           LOV_PATH,
           DELETE_FLAG,
           NAME_PATH,
           CODE_PATH,
           GROUP_CODE,
           START_DATE,
           END_DATE,
           NO,
           OPT_TXT6,
           OPT_TXT7,
           OPT_TXT8)
        values
          (lov_id,
          obj.org_code,
           null,
          sysdate,
          group_id,
           null,
          sysdate,
           'Y',
           1,
           null,
          obj.org_name,
           null,
           null,
           null,
           null,
           null,
           'ROOT',
           '/'||lov_id,
           'N',
           '/'||obj.org_name,
           '/'||obj.org_code,
           'SalesDept',
           null,
           null,
           1,
           null,
           null,
           null);
           commit;
           restr := restr+1;
           end if;
       end loop;
  return(restr);
end sync_sales_dept_from_erp;
/
