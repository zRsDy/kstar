CREATE function get_imp_seq(perfix in varchar2) return varchar2 is
  FunctionResult varchar2(200);
  seq            varchar2(100);
begin
  seq := to_char(imp_sequtil.nextval);

  if length(seq) + 10 + LENGTH(perfix) > 32 then
    raise_application_error(-20001, '??????32????');
  end if;

  FunctionResult := 'IMP_' || perfix || '_' || to_char(sysdate, 'mmdd') || '_' || seq;

  return(FunctionResult);
end get_imp_seq;
/
