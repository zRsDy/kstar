CREATE function get_lov_id(group_code in varchar2,
                                      lov_name   in varchar2)
  return varchar2 is
  FunctionResult varchar2(200);
begin
  select m.row_id
    into FunctionResult
    from sys_t_lov_member m
   where m.lov_name = lov_name
     and m.group_code = group_code;
  return(FunctionResult);
end get_lov_id;
/
