CREATE package CRM_P_CONTRACT_PUB is

  /*===========================================================
  Procedure Name :
     gen_contract_num
  Description:
     ??????
     ?????
        KSTAR-XS????YYYYMM????XXXX(?????)????0)
  History:
    1.00 2009-09-23  XXXX  Creation
  ===========================================================*/
  FUNCTION gen_contract_num(p_user_id IN NUMBER ) RETURN VARCHAR2;
  
  /*===========================================================
  Procedure Name :
     gen_contract_num
  Description:
     ??????????
     ?????
        ??????+(??????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
  FUNCTION gen_receive_plan_num(p_user_id IN NUMBER,p_contr_num in varchar2) RETURN VARCHAR2 ;
  
  /*===========================================================
  Procedure Name :
     gen_contract_change_num
  Description:
     ?????????
     ?????
        KSTAR-BG????YYYYMM????XXXX(?????)????0)
History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
  FUNCTION gen_contract_change_num(p_user_id IN NUMBER) RETURN VARCHAR2;
  
   /*===========================================================
  Procedure Name :
     gen_contract_pi_num
  Description:
     ??PI????
     ?????
        INS YYYYMM????X(??????) XXXX(?????)????0)
  History:
    1.00  2017-02-02  ibm.joe  Creation
  ===========================================================*/
  FUNCTION gen_contract_pi_num(dept IN varchar2) RETURN VARCHAR2;  
  
 /*===========================================================
  Procedure Name :
     gen_contract_num
  Description:
     ????????
     ?????
        KSTAR-JH????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2017-02-02  ibm.joe  Creation
  ===========================================================*/
  FUNCTION gen_contract_loan_num(p_user_id IN NUMBER) RETURN VARCHAR2;

/*===========================================================
  Procedure Name :
     gen_bizoppsupport_change_num
  Description:
     ?????????
     ?????
        KSTAR-SP????YYYYMM????XXXX(?????)????0)
History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/

FUNCTION gen_bizoppsupport_change_num(p_user_id IN NUMBER) RETURN VARCHAR2;

/*===========================================================
  Procedure Name :
     gen_bizoppsupport_change_num
  Description:
     ?????????
     ?????
        KSTAR-SP????YYYYMM????XXXX(?????)????0)
History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/

FUNCTION gen_bizopp_change_num(p_user_id IN NUMBER) RETURN VARCHAR2;

/*===========================================================
  Procedure Name :
     gen_bizoppproto_change_num
  Description:
     ?????????
     ?????
        KSTAR-SP????YYYYMM????XXXX(?????)????0)
History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/

FUNCTION gen_bizoppproto_change_num(p_user_id IN NUMBER) RETURN VARCHAR2;

/*===========================================================
  Procedure Name :
     gen_bizoppproto_change_num
  Description:
     ?????????
     ?????
        KSTAR-SP????YYYYMM????XXXX(?????)????0)
History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/

FUNCTION gen_bizoppbid_change_num(p_user_id IN NUMBER) RETURN VARCHAR2;

/*===========================================================
  Procedure Name :
     gen_bizoppbid_num
  Description:
     ????????
     ?????
        KSTAR-SQ??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_specialPrice_apply_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_lf_num
  Description:
     ????????
     ?????
        KSTAR-LF??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_lf_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_jj_num
  Description:
     ????????
     ?????
        KSTAR-JJ??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_jj_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_gx_num
  Description:
     ????????
     ?????
        KSTAR-GX??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_gx_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_pg_num
  Description:
     ????????
     ?????
        KSTAR-PG??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_pg_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_jz_num
  Description:
     ????????
     ?????
        KSTAR-JZ??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_jz_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_hb_num
  Description:
     ????????
     ?????
        KSTAR-HB??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_hb_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_bb_num
  Description:
     ????????
     ?????
        KSTAR-BB??????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_bb_num(p_user_id IN NUMBER) return varchar2;

/*===========================================================
  Procedure Name :
     gen_si_num
  Description:
     ???????????
     ?????
        KSTAR-SI???????YYYYMM????XXXX(?????)????0)
  History:
    1.00  2009-09-23  XXXX  Creation
  ===========================================================*/
FUNCTION gen_si_num(p_user_id IN NUMBER) return varchar2;

end CRM_P_CONTRACT_PUB;
/
