CREATE package body CRM_P_ORDER_PUB is

   /*===========================================================
    Procedure Name :
       gen_contract_num
    Description:
       ??????
       ?????
          KSTAR-XS????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_order_num(doc_type IN VARCHAR2 DEFAULT NULL, prefix IN VARCHAR2  DEFAULT NULL) RETURN VARCHAR2 IS
    l_receipt_number VARCHAR2 (30 );
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => doc_type ,
                                                              p_doc_prefix => prefix || l_yearmm,
                                                              p_seq_length => 4 );
    RETURN l_receipt_number;
  END gen_order_num;

  end CRM_P_ORDER_PUB;
/
