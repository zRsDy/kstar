CREATE package body CRM_P_PRODUCT_PUB is


       FUNCTION gen_maintenance_code(p_user_id IN NUMBER) RETURN VARCHAR2 IS
                  l_number VARCHAR2 (30 );
                   l_yearmm           VARCHAR2(40);
                 BEGIN
                 SELECT to_char(SYSDATE, 'YYYYMMDD') INTO l_yearmm FROM dual;
                  l_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'PROD_MAINTENANCE_CODE' ,
                                                                           p_doc_prefix => 'KSTAR_PM' || l_yearmm,
                                                                            p_seq_length => 4 );
                  RETURN l_number;
    END gen_maintenance_code;


end CRM_P_PRODUCT_PUB;
/
