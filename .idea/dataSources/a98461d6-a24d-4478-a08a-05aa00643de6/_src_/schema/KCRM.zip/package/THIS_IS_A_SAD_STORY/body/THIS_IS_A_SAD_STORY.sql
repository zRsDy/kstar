CREATE package body This_is_a_sad_story is

  procedure date_test is
    cursor datas is
      select * from re_order_lines;
    data_row datas%rowtype;
    vard     date;
  begin
    open datas;
    loop
      fetch datas
        into data_row;
      exit when datas%notfound;
    
      begin
        select to_date(data_row.n, 'yyyy/mm/dd') into vard from dual;
      exception
        when others then
          dbms_output.put_line(data_row.a || '---' || data_row.e);
      end;
    end loop;
  end;

  /**
    ????
  **/
  procedure re_contract_happy is
  
    --t_sys_guid    varchar2(100);
    t_employee_id varchar2(100);
    t_position_id varchar2(100);
    t_org_id      varchar2(100);
  
  begin
  
    DELETE FROM crm_t_contr_basic S WHERE S.C_ID LIKE 'IMP_CONTRACT%';
  
    DELETE FROM CRM_T_TEAM T WHERE T.BUSINESS_ID LIKE 'IMP_CONTRACT%';
  
    DELETE FROM crm_t_orgs O WHERE O.BUSINESS_ID LIKE 'IMP_CONTRACT%';
  
    DELETE FROM CRM_T_PRJ_LST CL WHERE CL.C_PID LIKE 'IMP_CONTRACT_LINE%';
  
    update re_contract_happy c set c.a = get_imp_seq('CONTRACT');
  
    insert into crm_t_contr_basic
      (C_ID,
       C_CONTR_NO, --????
       C_CONTR_NAME, --????
       C_CONTR_TYPE, --????
       C_CUST_CODE,
       C_CUST_name, --????
       N_TOTAL_AMT, --?????
       C_CUST_CONTR_NO, --?????
       C_FRAME_NO, --??????
       c_orderer, --??????
       c_creator, --??????
       c_org, --????
       c_market_dept, --????
       c_contr_stat, --        = 'ff8080815afaa793015afde1bc440043',????
       c_trial_stat, --        = '8a828dee5a11fc73015a12a86421000d',
       c_review_stat, --,       = '8a828dee5a11fc73015a12a86421000d',
       c_final_review_stat, -- = '8a828dee5a11fc73015a12a86421000d',
       c_buss_enity, --????
       DT_DELIV_DATE, --     ??????
       --????
       c_erp_order_cust_id, --ERP????
       c_erp_order_cust_name,
       dt_create_time, --????
       --??????
       DT_SYS_SIGN_DATE, --??????
       C_IS_ARCHIVE, --??????
       C_ARCHIVE_REMARK, --????
       DT_VALID_DATE --?????????????
       )
      select s.a,
             s.b,
             s.c,
             -- get_lov_id('CONTRACTTYPE', s.d),
             (select m.row_id
              -- into FunctionResult
                from sys_t_lov_member m
               where m.lov_name = s.d
                 and m.group_code = 'CONTRACTTYPE'
                 and rownum = 1),
             (select cin.c_pid
                from crm_t_custom_info cin
               where cin.c_custom_full_name = s.e
                 and rownum = 1),
             s.e,
             s.f,
             s.g,
             s.h,
             (select pe.row_id
                from sys_t_permission_employee pe
               where pe.no = s.i
                 and rownum = 1),
             (select pe.row_id
                from sys_t_permission_employee pe
               where pe.no = s.j
                 and rownum = 1),
             (select par.row_id --????, par.lov_name
                from sys_t_permission_employee e,
                     sys_t_lov_member          p,
                     sys_t_permission_user_rel r,
                     sys_t_lov_member          o,
                     sys_t_lov_member          par
               where e.row_id = (select pe.row_id
                                   from sys_t_permission_employee pe
                                  where pe.no = s.i)
                 and r.member_id = p.row_id
                 and r.user_id = e.row_id
                 and p.opt_txt1 = o.row_id
                 and o.parent_id = par.row_id
                 and rownum = 1),
             (select sa.row_id
                from sys_t_lov_member sa
               where sa.group_code = 'ORG'
                 and sa.opt_txt3 = 'A'
               start with sa.row_id =
                          (select par.row_id --????, par.lov_name
                             from sys_t_permission_employee e,
                                  sys_t_lov_member          p,
                                  sys_t_permission_user_rel r,
                                  sys_t_lov_member          o,
                                  sys_t_lov_member          par
                            where e.row_id = (select pe.row_id
                                                from sys_t_permission_employee pe
                                               where pe.no = s.i)
                              and r.member_id = p.row_id
                              and r.user_id = e.row_id
                              and p.opt_txt1 = o.row_id
                              and o.parent_id = par.row_id
                              and rownum = 1)
              connect by prior sa.parent_id = sa.row_id), -- s.m
             
             'ff8080815afaa793015afde1bc440043',
             '8a828dee5a11fc73015a12a86421000d',
             '8a828dee5a11fc73015a12a86421000d',
             '8a828dee5a11fc73015a12a86421000d',
             --  get_lov_id('CONTRACEBUSINESSOBJECT', s.o),
             (select m.row_id
              -- into FunctionResult
                from sys_t_lov_member m
               where m.lov_name = s.o
                 and m.group_code = 'CONTRACEBUSINESSOBJECT'),
             to_date(s.p, 'yyyy/mm/dd'), --date
             (select cin.c_pid
                from crm_t_custom_info cin
               where cin.c_custom_full_name = s.r
                 and rownum = 1),
             s.r,
             to_date(s.s, 'yyyy/mm/dd'), --date
             to_date(s.t, 'yyyy/mm/dd'), --date
             decode(s.u, '?', '1', '0'),
             s.v,
             to_date(s.w, 'yyyy/mm/dd') --date
        from re_contract_happy s;
  
    update CRM_T_CONTR_BASIC c
       set c.created_by_id  = c.c_creator, --admin
           c.created_pos_id =
           (select pos.row_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = c.c_creator
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1), --admin
           c.created_org_id =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = c.c_creator
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           c.updated_by_id  = c.c_creator,
           C.DT_CREATE_TIME = SYSDATE,
           c.created_at     = sysdate,
           c.updated_at     = sysdate;
  
    update crm_t_contr_basic c
       set c.c_pric_table =
           (select re.x
              from RE_CONTRACT_HAPPY re, crm_t_price_head h
             where re.a = c.c_id
               and re.x = h.c_price_head_name),
           c.c_pric_no   =
           (select h.c_pid
              from RE_CONTRACT_HAPPY re, crm_t_price_head h
             where re.a = c.c_id
               and re.x = h.c_price_head_name),
           c.c_currency  =
           (select m.row_id
              from RE_CONTRACT_HAPPY re, sys_t_lov_member m
             where re.a = c.c_id
               and re.y = m.lov_code
               and m.group_code = 'CURRENCY'
               and rownum = 1);
    /*    select pos.row_id, posorg.parent_id
     into t_position_id, t_org_id
     from SYS_T_PERMISSION_USER_REL rel,
          sys_t_lov_member          pos,
          sys_t_lov_member          posorg
    where rel.user_id = t_employee_id
      and rel.type = 'P'
      and rel.member_id = pos.row_id
      and pos.group_id = 'POSITION'
      and pos.opt_txt1 = posorg.row_id
      and posorg.group_id = 'ORG'
      and rownum = 1;*/
  
    /*    --??admin??
    t_employee_id := '297edff859ac766b0159af3825020003'; --admin
    
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
    
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             t_position_id,
             t_employee_id,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
    
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(), f.c_id, 'CONTR_STAND', t_org_id, t_org_id, null
        from CRM_T_CONTR_BASIC f;*/
  
    --??????
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             f.c_creator,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_id,
             'CONTR_STAND',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from CRM_T_CONTR_BASIC f;
  
    -- ??????
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             f.c_orderer,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_id,
             'CONTR_STAND',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from CRM_T_CONTR_BASIC f;
  
    -------------???-----------------------------------------------------------------------------------------
    /*  
    insert into sys_t_lov_member
      (row_id,
       lov_code,
       group_id,
       leaf_flag,
       lov_level,
       memo,
       lov_name,
       parent_id,
       lov_path,
       delete_flag,
       name_path,
       code_path,
       group_code)
      select c.c_id,
             c.c_id,
             'PRJLSTPRDCAT',
             'N',
             '1',
             c.c_id,
             '???',
             'ROOT',
             '/' || c.c_id,
             'N',
             '/???',
             '/' || c.c_id,
             'PRJLSTPRDCAT'
        from CRM_T_CONTR_BASIC c;
    
    insert into CRM_T_PRJ_LST
      (C_QID, --
       C_TYPE, --
       C_PRD_NAME, --
       C_LVID, --
       C_PID, --
       C_BUSINEES_CODE --
       )
      select c.c_id,
             c.c_contr_type,
             '???',
             c.c_id,
             get_imp_seq('CONTRACT_LINE'),
             c.c_contr_no
        from CRM_T_CONTR_BASIC c;*/
  
    ------insert into product line;------------------------------------------------
    update re_contract_happy_line l set l.a = get_imp_seq('CONTRACT_LINE');
  
    /* insert into sys_t_lov_member
    (row_id,
     lov_code,
     group_id,
     leaf_flag,
     lov_level,
     memo,
     lov_name,
     parent_id,
     lov_path,
     delete_flag,
     name_path,
     code_path,
     group_code)
    select p.a,
           p.a,
           'PRJLSTPRDCAT',
           'N',
           '2',
           c.c_id,
           p.d,
           c.c_id,
           '/' || p.a,
           'N',
           '/' || p.d,
           '/' || p.a,
           'PRJLSTPRDCAT'
      from CRM_T_CONTR_BASIC c, re_contract_happy_line p
     where c.c_contr_no = p.b;*/
  
    insert into CRM_T_PRJ_LST
      (C_QID,
       C_TYPE,
       C_PRD_NAME,
       C_PRD_CTG,
       C_PRD_TYP,
       C_PRD_UNT,
       N_PRD_PRC,
       N_TTL_UNT,
       N_AMOUNT,
       C_LVID,
       C_PID,
       C_MATER_CODE,
       C_PRO_DESC,
       C_ORD_NO,
       C_PRD_CD,
       C_PRO_ID,
       C_BUSINEES_CODE,
       C_PRD_CTGID,
       C_LINE_NUM)
      select b.c_id,
             b.c_contr_type,
             pb.c_pro_name,
             (select m.lov_name
                from sys_t_lov_member m
               where m.lov_code = pb.c_pro_crm_category
                 and m.group_code = 'crmCategory'),
             pb.c_pro_model,
             (select m.lov_name
                from sys_t_lov_member m
               where m.row_id = pb.c_unit),
             p.h,
             p.g * p.h,
             p.g,
             p.a,
             p.a,
             p.f,
             pb.c_pro_desc,
             p.i,
             pb.c_pro_code,
             pb.c_pid,
             b.c_contr_no,
             pb.C_PRO_CRM_CATEGORY,
             p.c
        from CRM_T_CONTR_BASIC      b,
             re_contract_happy_line p,
             crm_t_product_basic    pb
       where b.c_contr_no = p.b
         and pb.c_pro_code(+) = p.f;
  end;

  /**
    ??????
  **/
  procedure re_contract_rule is
  
  begin
    insert into CRM_T_CONTR_PAY
      (C_ID,
       C_PAY_NO,
       C_CONTR_ID,
       C_PAY_SEQ,
       C_PAY_SEQ_ID,
       C_PAY_PLAN,
       C_PLAN_RATIO,
       C_PLAN_AMT,
       C_ORIG_CLAUSE,
       C_SALER,
       DT_MEET_TIME,
       N_TOTAL_AMT,
       N_CANCEL_AMT,
       N_NCAN_AMT,
       C_REMARK,
       C_PAY_TERM)
      select get_imp_seq('CRM_T_CONTR_PAY'),
             null,
             (select c.c_id
                from crm_t_contr_basic c
               where c.c_contr_no = r.b),
             r.e,
             --  get_lov_id('crm_t_contr_basic', r.e),
             (select m.row_id
              -- into FunctionResult
                from sys_t_lov_member m
               where m.lov_name = r.e
                 and m.group_code = 'crm_t_contr_basic'),
             -- get_lov_id('CONTRACTPAYMENTPLAN', r.f),
             (select m.row_id
              -- into FunctionResult
                from sys_t_lov_member m
               where m.lov_name = r.f
                 and m.group_code = 'CONTRACTPAYMENTPLAN'),
             r.g,
             r.h,
             r.i,
             null,
             null,
             null,
             null,
             null,
             r.k,
             r.j
        from re_contract_happy_rule r;
  end;

  procedure re_contract_happy2 is
  
    --t_sys_guid    varchar2(100);
    t_employee_id varchar2(100);
    t_position_id varchar2(100);
    t_org_id      varchar2(100);
  
  begin
  
    DELETE FROM crm_t_contr_basic S WHERE S.C_ID LIKE 'IMP_CONTRACT2%';
  
    DELETE FROM CRM_T_TEAM T WHERE T.BUSINESS_ID LIKE 'IMP_CONTRACT2%';
  
    DELETE FROM crm_t_orgs O WHERE O.BUSINESS_ID LIKE 'IMP_CONTRACT2%';
  
    DELETE FROM CRM_T_PRJ_LST CL WHERE CL.C_PID LIKE 'IMP_CONTRACT_LINE2%';
  
    update re_contract_happy2 c set c.a = get_imp_seq('CONTRACT2');
  
    insert into crm_t_contr_basic
      (C_ID,
       C_CONTR_NO, --????
       DT_SUBMIT_TIME, --ji
       C_CONTR_NAME, --????
       C_CONTR_TYPE, --????
       C_CUST_CODE,
       C_CUST_name, --????
       --   N_TOTAL_AMT, --?????
       --   C_CUST_CONTR_NO, --?????
       --   C_FRAME_NO, --??????
       c_orderer, --??????
       c_creator, --?????
       c_org, --????
       c_market_dept, --????
       c_contr_stat, --        = 'ff8080815afaa793015afde1bc440043',????
       c_trial_stat, --        = '8a828dee5a11fc73015a12a86421000d',
       c_review_stat, --,       = '8a828dee5a11fc73015a12a86421000d',
       c_final_review_stat, -- = '8a828dee5a11fc73015a12a86421000d',
       c_buss_enity, --????
       --DT_DELIV_DATE, --     ??????
       DT_EXPECT_SIGN_DATE,
       --????
       c_erp_order_cust_id, --ERP????
       c_erp_order_cust_name,
       dt_create_time --????
       --??????
       )
      select s.a,
             s.b,
             to_date(s.c, 'yyyy/mm/dd'),
             s.b || '-????',
             --  get_lov_id('CONTRACTTYPE', '????'),
             'ff8080815b1d1242015b1d344bbd0012',
             (select cin.c_pid
                from crm_t_custom_info cin
               where cin.c_custom_full_name = s.d
                 and rownum = 1),
             s.d,
             --  s.f,
             --  s.g,
             --  s.h,
             (select pe.row_id
                from sys_t_permission_employee pe
               where pe.no = s.k
                 and rownum = 1),
             (select pe.row_id
                from sys_t_permission_employee pe
               where pe.no = s.e
                 and rownum = 1),
             (select par.row_id --????, par.lov_name
                from sys_t_permission_employee e,
                     sys_t_lov_member          p,
                     sys_t_permission_user_rel r,
                     sys_t_lov_member          o,
                     sys_t_lov_member          par
               where e.row_id = (select pe.row_id
                                   from sys_t_permission_employee pe
                                  where pe.no = s.e)
                 and r.member_id = p.row_id
                 and r.user_id = e.row_id
                 and p.opt_txt1 = o.row_id
                 and o.parent_id = par.row_id
                 and rownum = 1),
             (select sa.row_id
                from sys_t_lov_member sa
               where sa.group_code = 'ORG'
                 and sa.opt_txt3 = 'A'
               start with sa.row_id =
                          (select par.row_id --????, par.lov_name
                             from sys_t_permission_employee e,
                                  sys_t_lov_member          p,
                                  sys_t_permission_user_rel r,
                                  sys_t_lov_member          o,
                                  sys_t_lov_member          par
                            where e.row_id = (select pe.row_id
                                                from sys_t_permission_employee pe
                                               where pe.no = s.e)
                              and r.member_id = p.row_id
                              and r.user_id = e.row_id
                              and p.opt_txt1 = o.row_id
                              and o.parent_id = par.row_id
                              and rownum = 1)
              connect by prior sa.parent_id = sa.row_id), -- s.m
             
             'ff8080815afaa793015afde1bc440043',
             '8a828dee5a11fc73015a12a86421000d',
             '8a828dee5a11fc73015a12a86421000d',
             '8a828dee5a11fc73015a12a86421000d',
             -- get_lov_id('CONTRACEBUSINESSOBJECT', s.i),
             (select m.row_id
              -- into FunctionResult
                from sys_t_lov_member m
               where m.lov_name = s.i
                 and m.group_code = 'CONTRACEBUSINESSOBJECT'
                 and rownum = 1),
             to_date(s.h, 'yyyy/mm/dd'), --date
             (select cin.c_pid
                from crm_t_custom_info cin
               where cin.c_custom_full_name = s.l
                 and rownum = 1),
             s.l,
             to_date(s.c, 'yyyy/mm/dd') --date
      
        from re_contract_happy2 s;
  
    update CRM_T_CONTR_BASIC c
       set c.created_by_id  = c.c_creator, --admin
           c.created_pos_id =
           (select pos.row_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = c.c_creator
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'), --admin
           c.created_org_id =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = c.c_creator
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'),
           c.updated_by_id  = c.c_creator,
           c.created_at     = sysdate,
           c.updated_at     = sysdate
     where c.c_contr_type = 'ff8080815b1d1242015b1d344bbd0012';
  
    /*    select pos.row_id, posorg.parent_id
     into t_position_id, t_org_id
     from SYS_T_PERMISSION_USER_REL rel,
          sys_t_lov_member          pos,
          sys_t_lov_member          posorg
    where rel.user_id = t_employee_id
      and rel.type = 'P'
      and rel.member_id = pos.row_id
      and pos.group_id = 'POSITION'
      and pos.opt_txt1 = posorg.row_id
      and posorg.group_id = 'ORG';*/
  
    /*    --??admin??
    t_employee_id := '297edff859ac766b0159af3825020003'; --admin
    
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
    
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             t_position_id,
             t_employee_id,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
    
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(), f.c_id, 'CONTR_STAND', t_org_id, t_org_id, null
        from CRM_T_CONTR_BASIC f;*/
  
    --??????
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             f.c_creator,
             'CONTR_LOAN',
             f.c_id
        from CRM_T_CONTR_BASIC f
       where f.c_contr_type = 'ff8080815b1d1242015b1d344bbd0012';
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_id,
             'CONTR_LOAN',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from CRM_T_CONTR_BASIC f
       where f.c_contr_type = 'ff8080815b1d1242015b1d344bbd0012';
  
    -- ??????
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             f.c_orderer,
             'CONTR_LOAN',
             f.c_id
        from CRM_T_CONTR_BASIC f
       where f.c_contr_type = 'ff8080815b1d1242015b1d344bbd0012';
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_id,
             'CONTR_LOAN',
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from CRM_T_CONTR_BASIC f
       where f.c_contr_type = 'ff8080815b1d1242015b1d344bbd0012';
  
    -------------???-----------------------------------------------------------------------------------------
    /*
      insert into sys_t_lov_member
        (row_id,
         lov_code,
         group_id,
         leaf_flag,
         lov_level,
         memo,
         lov_name,
         parent_id,
         lov_path,
         delete_flag,
         name_path,
         code_path,
         group_code)
        select c.c_id,
               c.c_id,
               'PRJLSTPRDCAT',
               'N',
               '1',
               c.c_id,
               '???',
               'ROOT',
               '/' || c.c_id,
               'N',
               '/???',
               '/' || c.c_id,
               'PRJLSTPRDCAT'
          from CRM_T_CONTR_BASIC c
         where c.c_contr_type = 'CONTR_LOAN-01';
    
      insert into CRM_T_PRJ_LST
        (C_QID, --
         C_TYPE, --
         C_PRD_NAME, --
         C_LVID, --
         C_PID, --
         C_BUSINEES_CODE --
         )
        select c.c_id,
               c.c_contr_type,
               '???',
               c.c_id,
               get_imp_seq('CONTRACT_LINE'),
               c.c_contr_no
          from CRM_T_CONTR_BASIC c
         where c.c_contr_type = 'CONTR_LOAN-01';
    */
    ------insert into product line;------------------------------------------------
    update re_contract_happy_line2 l
       set l.a = get_imp_seq('CONTRACT_LINE2');
  
    /*  insert into sys_t_lov_member
        (row_id,
         lov_code,
         group_id,
         leaf_flag,
         lov_level,
         memo,
         lov_name,
         parent_id,
         lov_path,
         delete_flag,
         name_path,
         code_path,
         group_code)
        select p.a,
               p.a,
               'PRJLSTPRDCAT',
               'N',
               '2',
               c.c_id,
               p.e,
               c.c_id,
               '/' || p.a,
               'N',
               '/' || p.e,
               '/' || p.a,
               'PRJLSTPRDCAT'
          from CRM_T_CONTR_BASIC c, re_contract_happy_line2 p
         where c.c_contr_no = p.b
           and c.c_contr_type = 'CONTR_LOAN-01';
    */
    insert into CRM_T_PRJ_LST
      (C_QID,
       C_TYPE,
       C_PRD_NAME,
       C_PRD_CTG,
       C_PRD_TYP,
       C_PRD_UNT,
       N_PRD_PRC,
       N_TTL_UNT,
       N_AMOUNT,
       C_LVID,
       C_PID,
       C_MATER_CODE,
       C_PRO_DESC,
       C_ORD_NO,
       C_PRD_CD,
       C_PRO_ID,
       C_BUSINEES_CODE,
       C_PRD_CTGID,
       C_LINE_NUM,
       N_NOT_VERI_NUM)
      select b.c_id,
             b.c_contr_type,
             pb.c_pro_name,
             (select m.lov_name
                from sys_t_lov_member m
               where m.lov_code = pb.c_pro_crm_category
                 and m.group_code = 'crmCategory'),
             pb.c_pro_model,
             (select m.lov_name
                from sys_t_lov_member m
               where m.row_id = pb.c_unit),
             p.h,
             p.f * p.h,
             p.f,
             p.a,
             p.a,
             p.d,
             pb.c_pro_desc,
             null,
             pb.c_pro_code,
             pb.c_pid,
             b.c_contr_no,
             pb.C_PRO_CRM_CATEGORY,
             null,
             p.g
        from CRM_T_CONTR_BASIC       b,
             re_contract_happy_line2 p,
             crm_t_product_basic     pb
       where b.c_contr_no = p.b
         and pb.c_pro_code(+) = p.d
         and b.c_contr_type = 'ff8080815b1d1242015b1d344bbd0012';
  end;

  procedure re_customer_happy is
    --  t_position_id varchar2(200);
    --  t_employee_id varchar2(200);
    --  t_org_id      varchar2(200);
  begin
  
    --???? imp_customer_business_entity,imp_crm_t_custom_info_back???
  
    DELETE FROM crm_t_custom_info;
  
    DELETE FROM CRM_T_TEAM C
     WHERE C.BUSINESS_ID LIKE 'IMP%'
       AND C.BUSINESS_TYPE = 'CUSTOM_REPORT_PROC';
  
    DELETE FROM CRM_T_ORGS C
     WHERE C.BUSINESS_ID LIKE 'IMP%'
       AND C.BUSINESS_TYPE = 'CUSTOM_REPORT_PROC';
  
    DELETE FROM crm_t_custom_address_info C;
  
    DELETE FROM crm_t_custom_erp_info C;
  
    insert into crm_t_custom_info
      select * from imp_crm_t_custom_info_back;
  
    update imp_customer_business_entity en
       set (en.e, en.f) =
           (select m.lov_name, m.row_id
              from sys_t_lov_member m
             where m.group_code = 'OPERATION_UNIT'
               and substr(m.lov_name, 5, 200) = en.a);
  
    -- crm_t_custom_info.c_custom_class
    update crm_t_custom_info c
       set c.c_custom_class =
           (select nvl(m.row_id, c_custom_class)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCLASS'
               and m.lov_name = c.c_custom_class);
  
    update crm_t_custom_info c
       set c.c_custom_grade =
           (select m.row_id
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCLASS'
               and m.parent_id = c.c_custom_class
               and m.lov_level = 2
               and m.lov_name = c.c_custom_grade);
  
    -- crm_t_custom_info.c_custom_source           
    update crm_t_custom_info c
       set c.c_custom_source =
           (select nvl(m.row_id, c_custom_source)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMSOURCE'
               and m.lov_name = c.c_custom_source);
  
    -- crm_t_custom_info.c_custom_status
    update crm_t_custom_info c
       set c.c_custom_status =
           (select nvl(m.row_id, c_custom_status)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMSTATUS'
               and m.lov_name = c.c_custom_status);
  
    -- crm_t_custom_info.c_custom_AREA
    update crm_t_custom_info c
       set c.c_custom_area =
           (select nvl(m.row_id, c_custom_area)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_name = c.c_custom_area
               and m.lov_level = '1');
  
    -- crm_t_custom_info.c_custom_grade
    update crm_t_custom_info c
       set c.c_custom_grade =
           (select nvl(m.row_id, c_custom_grade)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMGRADE'
               and m.lov_name = c.c_custom_grade);
  
    -- crm_t_custom_info.c_custom_reported_flg
    update crm_t_custom_info c
       set c.c_custom_reported_flg = 'CUSTOM_NORMAL_STATUS_10';
    /*(select nvl(m.row_id, c_custom_reported_flg)
     from sys_t_lov_member m
    where m.group_code = 'CUSTOM_NORMAL_STATUS'
      and m.lov_name = c.c_custom_reported_flg);*/
  
    -- crm_t_custom_info.c_custom_category
    update crm_t_custom_info c
       set c.c_custom_category =
           (select nvl(m.row_id, c_custom_category)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCATEGORY'
               and m.lov_level = '1'
               and m.lov_name = c.c_custom_category);
  
    -- crm_t_custom_info.c_custom_category_sub
    update crm_t_custom_info c
       set c.c_custom_category_sub =
           (select nvl(m.row_id, c_custom_category_sub)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCATEGORY'
               and m.lov_level = '2'
               AND C.C_CUSTOM_CATEGORY = M.PARENT_ID
               and m.lov_name = c.c_custom_category_sub);
  
    -- crm_t_custom_info.c_custom_area_sub1
    update crm_t_custom_info c
       set c.c_custom_area_sub1 =
           (select nvl(m.row_id, c_custom_area_sub1)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '2'
               and (m.lov_name = c.c_custom_area_sub1 or
                   m.lov_name = c.c_custom_area_sub1 || '?'));
  
    -- crm_t_custom_info.c_custom_area_sub2
    update crm_t_custom_info c
       set c.c_custom_area_sub2 =
           (select nvl(m.row_id, c_custom_area_sub2)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '3'
               and m.lov_name like c.c_custom_area_sub2 || '%'
               and rownum = 1);
  
    -- crm_t_custom_info.c_custom_area_sub3
    update crm_t_custom_info c
       set c.c_custom_area_sub3 =
           (select nvl(m.row_id, c_custom_area_sub3 || '%')
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '4'
               and m.lov_name like c.c_custom_area_sub3 || '%'
               and rownum = 1);
  
    -- ????????
    update crm_t_custom_info c set c.c_custom_type = '1';
  
    --???
    /*  ??????????????????????
    1????????
    2????????******
    3??????????
    4????????
    
    5?????(?????????????)?
    ??????????
    ???????
    ??:????
    ??????*/
    update crm_t_custom_info c
       set c.c_custom_category = 'ff8080815bb44f6b015bb4ba93cf0032'
     where c.c_custom_category is null;
  
    update crm_t_custom_info c
       set c.c_custom_category_sub = 'ff8080815bb44f6b015bb4bb6a390035'
     where c.c_custom_category_sub is null;
  
    update crm_t_custom_info c
       set c.c_custom_status = 'CUSTOMSTATUS_10'
     where c.c_custom_status is null;
  
    update crm_t_custom_info c
       set c.c_custom_control_status = 'CONTROLSTATUS_01'
     where c.c_custom_control_status is null;
  
    update crm_t_custom_info c
       set c.c_custom_reported_flg = 'CUSTOM_NORMAL_STATUS_10'
     where c.c_custom_reported_flg is null;
  
    --????
    update crm_t_custom_info c
       set c.c_created_by_id =
           (select e.row_id
              from sys_t_permission_employee e
             where e.no = c.c_pipe_rank
               and rownum = 1),
           c.c_created_pos_id =
           (select pos.row_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_pipe_rank
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           c.c_created_org_id =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_pipe_rank
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           c.c_updated_by_id =
           (select e.row_id
              from sys_t_permission_employee e
             where e.no = c.c_pipe_rank
               and rownum = 1),
           c.dt_created_at    = sysdate,
           c.dt_updated_at    = sysdate;
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.ROW_ID
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = (select e.row_id
                                      from sys_t_permission_employee e
                                     where e.no = f.c_pipe_rank
                                       and rownum = 1)
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select e.row_id
                from sys_t_permission_employee e
               where e.no = f.c_pipe_rank
                 and rownum = 1),
             'CUSTOM_REPORT_PROC',
             f.c_pid
        from crm_t_custom_info f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_pid,
             'CUSTOM_REPORT_PROC',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = (select e.row_id
                                      from sys_t_permission_employee e
                                     where e.no = f.c_pipe_rank
                                       and rownum = 1)
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = (select e.row_id
                                      from sys_t_permission_employee e
                                     where e.no = f.c_pipe_rank
                                       and rownum = 1)
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from crm_t_custom_info f;
  
    --??????\??
    insert into crm_t_custom_address_info
      (c_pid,
       c_custom_pid,
       c_area_lov1,
       c_area_lov2,
       c_area_lov3,
       c_area_lov4,
       c_area_lov5,
       c_custom_address,
       c_custom_zip,
       c_custom_address_type,
       c_custom_address_phone,
       c_custom_address_fax,
       c_custom_address_use,
       c_custom_address_valid,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at)
      select c.c_pid,
             c.c_pid,
             c.c_custom_area,
             c.c_custom_area_sub1,
             c.c_custom_area_sub2,
             c.c_custom_area_sub3,
             null,
             c.c_corp_reg_address,
             null,
             '8a828d115a5f97da015a5f9c50760002',
             null,
             null,
             'ff8080815af52889015af539bb80000e  ',
             'COMMONYN_Y',
             c.c_created_by_id,
             c.dt_created_at,
             c.c_created_pos_id,
             c.c_created_org_id,
             c.c_updated_by_id,
             c.dt_updated_at
        from crm_t_custom_info c;
  
    insert into crm_t_custom_erp_info
      (c_pid,
       c_custom_pid,
       c_corp_erp_unit,
       c_corp_leaded_address,
       c_corp_leaded_comment,
       c_corp_erp_status,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at)
      select sys_guid(),
             c.c_pid,
             en.f,
             c.c_pid,
             null,
             'CUSTOM_NORMAL_STATUS_40',
             c.c_created_by_id,
             c.dt_created_at,
             c.c_created_pos_id,
             c.c_created_org_id,
             c.c_updated_by_id,
             c.dt_updated_at
        from crm_t_custom_info c, imp_customer_business_entity en
       where en.b = c.c_custom_erp_code
         and c.c_custom_erp_code is not null;
  
  end;

  PROCEDURE re_order_head is
  
  begin
  
    delete from imp_crm_t_order_header;
  
    delete from crm_t_team t where t.business_id like 'IMP_ORDER_%';
  
    delete from crm_t_orgs o where o.business_id like 'IMP_ORDER_%';
  
    delete from crm_t_order_header o where o.c_pid like 'IMP_ORDER_%';
  
    update re_order_head ro set ro.ab = get_imp_seq('ORDER');
  
    insert into imp_crm_t_order_header
      (c_pid,
       c_order_code,
       c_customer_code,
       c_customer_name,
       c_cust_attn_code,
       c_cust_attn_name,
       c_customer_po,
       c_delivery_address,
       c_bill_address,
       c_business_entity,
       c_ship_org,
       c_source_type,
       c_source_code,
       c_order_type,
       dt_order_date,
       dt_request_date,
       c_currency,
       c_convert_type,
       dt_convert_date,
       c_price_table_id,
       n_amount,
       c_remark,
       c_salesman_id,
       c_salesman_center,
       c_salesman_dep,
       c_sales_territory,
       c_execute_status,
       c_control_status,
       n_is_abnormal_price,
       n_is_abnormal_credit,
       c_term_payment,
       c_term_payment_detail,
       c_payment_customer_id,
       c_final_cust_id,
       c_final_cust_trade_b,
       c_final_cust_trade_s,
       c_is_install,
       c_is_am,
       c_inspection_cycle,
       c_warranty_period,
       c_ship_type,
       c_is_home_delivery,
       c_is_destination_delivery,
       c_service_clause,
       n_collection_freight,
       n_die_cost,
       n_development_costs,
       c_cust_brand_class,
       c_is_free_spare,
       c_is_random_spare,
       n_spare_amount,
       n_spare_balance,
       c_spare_amount_situation,
       c_spare_order_no,
       c_customer_id,
       c_source_name,
       c_salesman_name,
       c_payment_customer_name,
       c_final_cust_name,
       c_delivery_address_id,
       c_bill_address_id,
       c_erp_order_code,
       c_price_table_name,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at,
       c_source_id,
       c_salesman_code,
       c_customer_erp_code,
       c_cust_attn_tel,
       c_zip_code,
       C_BUSINESS_MANAGER_ID,
       C_BUSINESS_MANAGER_CODE,
       C_BUSINESS_MANAGER_NAME)
      select o.ab,
             o.s,
             o.b,
             o.a,
             null,
             null,
             null,
             null,
             null,
             o.f,
             null,
             o.d,
             o.e,
             o.g,
             to_date(o.h, 'yyyy/mm/dd'),
             to_date(o.i, 'yyyy/mm/dd'),
             o.P,
             null,
             null,
             null,
             null,
             'CRM??',
             o.k, --??
             o.k,
             o.k,
             null,
             null,
             o.r,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             o.u,
             o.t,
             null,
             null,
             o.w,
             o.v,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             null,
             o.b, --turn
             null,
             o.k, --turn
             null,
             null,
             null,
             null,
             o.s,
             o.o,
             o.n,
             to_date(o.h, 'yyyy/mm/dd'),
             o.K, --turn
             o.K, --turn
             o.K, --turn
             to_date(o.h, 'yyyy/mm/dd'),
             o.e, --turn
             o.k,
             o.b,
             null,
             null,
             O.N,
             O.N,
             O.N
        from re_order_head o;
  
    update imp_crm_t_order_header c
       set c.c_pid             = get_imp_seq('ORDER'),
           c.c_customer_code  =
           (select cm.c_custom_code
              from crm_t_custom_info cm
             where cm.c_custom_erp_code = c.c_customer_erp_code
               and rownum = 1),
           C.C_CUSTOMER_ID    =
           (select cm.c_pid
              from crm_t_custom_info cm
             where cm.c_custom_erp_code = c.c_customer_erp_code
               AND ROWNUM = 1),
           c.c_business_entity =
           (select m.row_id
              from sys_t_lov_member m
             where m.group_code = 'OPERATION_UNIT'
               and c.c_business_entity = m.lov_name
               AND ROWNUM = 1),
           c.c_source_type     = '10',
           C.C_ORDER_TYPE     =
           (select M.LOV_CODE
              from SYS_T_LOV_MEMBER M
             WHERE M.GROUP_CODE = 'OPERATION_UNIT'
               AND M.PARENT_ID =
                   (select m.row_id
                      from sys_t_lov_member m
                     where m.group_code = 'OPERATION_UNIT'
                       and c.c_business_entity = m.lov_name)
               AND M.LOV_NAME = C.C_ORDER_TYPE
               AND M.LOV_LEVEL = 2
               AND ROWNUM = 1),
           C.C_PRICE_TABLE_ID =
           (select CH.C_PID
              from CRM_T_PRICE_HEAD CH
             WHERE CH.C_PRICE_HEAD_NAME = C.C_PRICE_TABLE_NAME
               AND ROWNUM = 1),
           C.C_SALESMAN_ID    =
           (select E.ROW_ID
              from SYS_T_PERMISSION_EMPLOYEE E
             WHERE E.NO = C.C_SALESMAN_CODE
               AND ROWNUM = 1),
           -- C.C_SALESMAN_CODE=(select E.ROW_ID from SYS_T_PERMISSION_EMPLOYEE E WHERE E.NO = C.C_SALESMAN_CODE)
           C.C_SALESMAN_NAME        =
           (select E.NAME
              from SYS_T_PERMISSION_EMPLOYEE E
             WHERE E.NO = C.C_SALESMAN_CODE
               AND ROWNUM = 1),
           C.C_SALESMAN_CENTER      =
           (select s.ROW_ID as code
              from sys_t_lov_member s
             where s.group_code = 'ORG'
               and s.opt_txt3 = 'A'
             start with s.row_id = (select posorg.parent_id
                                      from SYS_T_PERMISSION_USER_REL rel,
                                           sys_t_lov_member          pos,
                                           sys_t_lov_member          posorg
                                     where rel.user_id =
                                           (select e.row_id
                                              from sys_t_permission_employee e
                                             where e.no = c.c_Salesman_Code
                                               and rownum = 1)
                                       and rel.type = 'P'
                                       and rel.member_id = pos.row_id
                                       and pos.group_id = 'POSITION'
                                       and pos.opt_txt1 = posorg.row_id
                                       and posorg.group_id = 'ORG'
                                       and rownum = 1)
            connect by prior s.parent_id = s.row_id
                   AND ROWNUM = 1),
           C.C_SALESMAN_DEP         =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_Salesman_Code
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           C.C_CONTROL_STATUS       =
           (select M.LOV_CODE
              from SYS_T_LOV_MEMBER M
             WHERE M.GROUP_CODE = 'ORDER_CONTROL_STATUS'
               AND M.LOV_NAME = C.C_CONTROL_STATUS),
           C.C_CREATED_BY_ID        =
           (select PE.ROW_ID
              from SYS_T_PERMISSION_EMPLOYEE PE
             WHERE PE.NO = C.c_Salesman_Code
               AND ROWNUM = 1),
           C.C_CREATED_POS_ID       =
           (select pos.row_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_Salesman_Code
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           C.C_CREATED_ORG_ID       =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_Salesman_Code
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           C.C_UPDATED_BY_ID        =
           (select e.row_id
              from sys_t_permission_employee e
             where e.no = c.c_Salesman_Code
               and rownum = 1),
           C.C_SOURCE_ID            =
           (select B.C_ID
              from CRM_T_CONTR_BASIC B
             WHERE B.C_CONTR_NO = C.C_SOURCE_CODE
               AND ROWNUM = 1),
           C.C_BUSINESS_MANAGER_ID  =
           (select PE.ROW_ID
              from SYS_T_PERMISSION_EMPLOYEE PE
             WHERE PE.NO = C.C_BUSINESS_MANAGER_CODE
               AND ROWNUM = 1),
           C.C_BUSINESS_MANAGER_NAME =
           (select PE.NAME
              from SYS_T_PERMISSION_EMPLOYEE PE
             WHERE PE.NO = C.C_BUSINESS_MANAGER_CODE
               AND ROWNUM = 1);
  
    insert into crm_t_order_header
      select * from imp_crm_t_order_header;
  
    --????xs
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.ROW_ID
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = f.c_salesman_id
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             f.c_salesman_id,
             'ORDER',
             f.c_pid
        from crm_t_order_header f
       where f.c_pid like 'IMP_ORDER%';
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_pid,
             'ORDER',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = f.c_salesman_id
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = f.c_salesman_id
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from crm_t_order_header f;
    --????
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.ROW_ID
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = f.c_business_manager_id
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             f.c_created_by_id,
             'ORDER',
             f.c_pid
        from crm_t_order_header f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_pid,
             'ORDER',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = f.c_business_manager_id
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = f.c_created_by_id
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from crm_t_order_header f;
  
  end;

  procedure re_order_line is
  
  begin
  
    update re_order_lines l set l.aa = get_imp_seq('ORDER_LINE');
    delete from imp_crm_t_order_lines;
    delete from crm_t_order_lines il where il.c_pid like 'IMP_ORDER_LINE%';
    --
    insert into imp_crm_t_order_lines
      (c_pid,
       c_order_code,
       c_pro_model,
       c_materiel_code,
       c_item_description,
       n_product_quantity,
       c_unit,
       n_price,
       n_amount,
       dt_request_date,
       dt_promise_date,
       c_status,
       c_confirm_delivery_date,
       c_ship_org,
       c_is_advance_billing,
       c_return_reason,
       c_return_reference,
       c_is_pending,
       n_delivery_quantity,
       n_billing_quantity,
       c_receiving_customer,
       c_consignee,
       c_line_no,
       c_order_id,
       c_pro_id,
       c_create_time,
       c_creator,
       c_materiel_name,
       n_cancel_quantity,
       c_updated_by_id,
       dt_updated_at,
       c_original_line_id,
       c_source_id,
       c_remark,
       c_erp_plan_status,
       c_is_erp_delivery,
       n_erp_settlement_price,
       c_erp_status,
       c_special_price_code,
       c_is_special_price,
       c_pro_brand,
       c_source_code,
       c_special_price_line_id)
      select l.aa,
             l.a,
             l.f,
             l.e,
             l.z,
             l.h,
             l.i,
             l.j,
             l.l, --return
             l.m,
             l.n,
             l.w, --
             l.p, --
             l.q, --
             l.s, --
             null,
             null,
             l.r, --
             l.u,
             l.v,
             null,
             null,
             l.c,
             l.a,
             l.e, --teturn orderid
             sysdate,
             '0',
             l.d,
             nvl(l.t, 0),
             '0',
             sysdate,
             null,
             null,
             l.z,
             l.x, --
             l.y, --
             l.k,
             l.o, --
             null,
             'No',
             null,
             null,
             null
        from re_order_lines l;
  
    update imp_crm_t_order_lines l
       set l.c_status    =
           (select m.lov_code
              from sys_t_lov_member m
             where m.group_code = 'ORDER_LINE_STATUS'
               and m.lov_name = l.c_status),
           l.c_erp_status =
           (select m.lov_code
              from sys_t_lov_member m
             where m.group_code = 'ORDER_ERP_STATUS'
               and m.lov_name = l.c_erp_status),
           l.c_ship_org  =
           (select m.row_id
              from sys_t_lov_member m
             where m.group_code = 'INVENTORY'
               and m.lov_name = l.c_ship_org),
           l.c_order_id  =
           (select h.c_pid
              from crm_t_order_header h
             where h.c_order_code = l.c_order_code
               and rownum = 1),
           l.c_pro_id    =
           (select b.c_pid
              from crm_t_product_basic b
             where b.c_pro_code = l.c_materiel_code);
  
    insert into crm_t_order_lines
      select * from imp_crm_t_order_lines;
  
  end;

  procedure re_customer_sad is
  
  begin
    --???? imp_customer_business_entity,imp_crm_t_custom_info_back???
  
    insert into crm_t_custom_info2
      select * from imp_crm_t_custom_info_back2;
  
      update imp_customer_business_entity2 en
       set (en.e, en.f) =
           (select m.lov_name, m.row_id
              from sys_t_lov_member m
             where m.group_code = 'OPERATION_UNIT'
               and substr(m.lov_name, 5, 200) = en.a);
  
    -- crm_t_custom_info.c_custom_class
    update crm_t_custom_info2 c
       set c.c_custom_class =
           (select nvl(m.row_id, c_custom_class)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCLASS'
               and m.lov_name = c.c_custom_class);
  
    update crm_t_custom_info2 c
       set c.c_custom_grade =
           (select m.row_id
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCLASS'
               and m.parent_id = c.c_custom_class
               and m.lov_level = 2
               and m.lov_name = c.c_custom_grade);
  
    -- crm_t_custom_info.c_custom_source           
    update crm_t_custom_info2 c
       set c.c_custom_source =
           (select nvl(m.row_id, c_custom_source)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMSOURCE'
               and m.lov_name = c.c_custom_source);
  
    -- crm_t_custom_info.c_custom_status
    update crm_t_custom_info2 c
       set c.c_custom_status =
           (select nvl(m.row_id, c_custom_status)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMSTATUS'
               and m.lov_name = c.c_custom_status);
  
    -- crm_t_custom_info.c_custom_AREA
    update crm_t_custom_info c
       set c.c_custom_area =
           (select nvl(m.row_id, c_custom_area)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_name = c.c_custom_area
               and m.lov_level = '1');
  
    -- crm_t_custom_info.c_custom_grade
    update crm_t_custom_info2 c
       set c.c_custom_grade =
           (select nvl(m.row_id, c_custom_grade)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMGRADE'
               and m.lov_name = c.c_custom_grade);
  
    -- crm_t_custom_info.c_custom_reported_flg
    update crm_t_custom_info2 c
       set c.c_custom_reported_flg = 'CUSTOM_NORMAL_STATUS_10';
       
     update crm_t_custom_info2 c
       set c.c_custom_erp_status = 'CUSTOM_NORMAL_STATUS_40';
    /*(select nvl(m.row_id, c_custom_reported_flg)
     from sys_t_lov_member m
    where m.group_code = 'CUSTOM_NORMAL_STATUS'
      and m.lov_name = c.c_custom_reported_flg);*/
  
    -- crm_t_custom_info.c_custom_category
    update crm_t_custom_info2 c
       set c.c_custom_category =
           (select nvl(m.row_id, c_custom_category)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCATEGORY'
               and m.lov_level = '1'
               and m.lov_name = c.c_custom_category);
  
    -- crm_t_custom_info.c_custom_category_sub
    update crm_t_custom_info2 c
       set c.c_custom_category_sub =
           (select nvl(m.row_id, c_custom_category_sub)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCATEGORY'
               and m.lov_level = '2'
               AND C.C_CUSTOM_CATEGORY = M.PARENT_ID
               and m.lov_name = c.c_custom_category_sub);
  
    -- crm_t_custom_info.c_custom_area_sub1
    update crm_t_custom_info2 c
       set c.c_custom_area_sub1 =
           (select nvl(m.row_id, c_custom_area_sub1)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '2'
               and (m.lov_name = c.c_custom_area_sub1 or
                   m.lov_name = c.c_custom_area_sub1 || '?'));
  
    -- crm_t_custom_info.c_custom_area_sub2
    update crm_t_custom_info2 c
       set c.c_custom_area_sub2 =
           (select nvl(m.row_id, c_custom_area_sub2)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '3'
               and m.lov_name like c.c_custom_area_sub2 || '%'
               and rownum = 1);
  
    -- crm_t_custom_info.c_custom_area_sub3
    update crm_t_custom_info2 c
       set c.c_custom_area_sub3 =
           (select nvl(m.row_id, c_custom_area_sub3 || '%')
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '4'
               and m.lov_name like c.c_custom_area_sub3 || '%'
               and rownum = 1);
  
    -- ????????
    update crm_t_custom_info2 c set c.c_custom_type = '1';
  
    --???
    /*  ??????????????????????
    1????????
    2????????******
    3??????????
    4????????
    
    5?????(?????????????)?
    ??????????
    ???????
    ??:????
    ??????*/
    update crm_t_custom_info2 c
       set c.c_custom_category = 'ff8080815bb44f6b015bb4ba93cf0032'
     where c.c_custom_category is null;
  
    update crm_t_custom_info2 c
       set c.c_custom_category_sub = 'ff8080815bb44f6b015bb4bb6a390035'
     where c.c_custom_category_sub is null;
  
    update crm_t_custom_info2 c
       set c.c_custom_status = 'CUSTOMSTATUS_10'
     where c.c_custom_status is null;
  
    update crm_t_custom_info2 c
       set c.c_custom_control_status = 'CONTROLSTATUS_01'
     where c.c_custom_control_status is null;
  
    update crm_t_custom_info2 c
       set c.c_custom_reported_flg = 'CUSTOM_NORMAL_STATUS_10'
     where c.c_custom_reported_flg is null;
  
    --????
    update crm_t_custom_info2 c
       set c.c_created_by_id =
           (select e.row_id
              from sys_t_permission_employee e
             where e.no = c.c_pipe_rank
               and rownum = 1),
           c.c_created_pos_id =
           (select pos.row_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_pipe_rank
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           c.c_created_org_id =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = (select e.row_id
                                    from sys_t_permission_employee e
                                   where e.no = c.c_pipe_rank
                                     and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           c.c_updated_by_id =
           (select e.row_id
              from sys_t_permission_employee e
             where e.no = c.c_pipe_rank
               and rownum = 1),
           c.dt_created_at    = sysdate,
           c.dt_updated_at    = sysdate;
  
    insert into CRM_T_TEAM2
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.ROW_ID
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = (select e.row_id
                                      from sys_t_permission_employee e
                                     where e.no = f.c_pipe_rank
                                       and rownum = 1)
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select e.row_id
                from sys_t_permission_employee e
               where e.no = f.c_pipe_rank
                 and rownum = 1),
             'CUSTOM_REPORT_PROC',
             f.c_pid
        from crm_t_custom_info2 f;
  
    insert into crm_t_orgs2
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_pid,
             'CUSTOM_REPORT_PROC',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = (select e.row_id
                                      from sys_t_permission_employee e
                                     where e.no = f.c_pipe_rank
                                       and rownum = 1)
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = (select e.row_id
                                      from sys_t_permission_employee e
                                     where e.no = f.c_pipe_rank
                                       and rownum = 1)
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and rownum = 1),
             null
        from crm_t_custom_info2 f;
  
    --??????\??
    insert into crm_t_custom_address_info2
      (c_pid,
       c_custom_pid,
       c_area_lov1,
       c_area_lov2,
       c_area_lov3,
       c_area_lov4,
       c_area_lov5,
       c_custom_address,
       c_custom_zip,
       c_custom_address_type,
       c_custom_address_phone,
       c_custom_address_fax,
       c_custom_address_use,
       c_custom_address_valid,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at)
      select c.c_pid,
             c.c_pid,
             c.c_custom_area,
             c.c_custom_area_sub1,
             c.c_custom_area_sub2,
             c.c_custom_area_sub3,
             null,
             c.c_corp_reg_address,
             null,
             '8a828d115a5f97da015a5f9c50760002',
             null,
             null,
             'ff8080815af52889015af539bb80000e  ',
             'COMMONYN_Y',
             c.c_created_by_id,
             c.dt_created_at,
             c.c_created_pos_id,
             c.c_created_org_id,
             c.c_updated_by_id,
             c.dt_updated_at
        from crm_t_custom_info2 c;
  
    insert into crm_t_custom_erp_info2
      (c_pid,
       c_custom_pid,
       c_corp_erp_unit,
       c_corp_leaded_address,
       c_corp_leaded_comment,
       c_corp_erp_status,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at)
      select sys_guid(),
             c.c_pid,
             en.f,
             c.c_pid,
             null,
             'CUSTOM_NORMAL_STATUS_40',
             c.c_created_by_id,
             c.dt_created_at,
             c.c_created_pos_id,
             c.c_created_org_id,
             c.c_updated_by_id,
             c.dt_updated_at
        from crm_t_custom_info2 c, imp_customer_business_entity2 en
       where en.b = c.c_custom_erp_code
         and c.c_custom_erp_code is not null;
  
  end;
end This_is_a_sad_story;
/
