CREATE package body pkg_data_imp is

  procedure imp_product_category is
  
    cursor src_data is
      select * from TMP_PRODUCT_CATEGORY603;
    -- where row_id in ('UAT_IMP_426_212');
  
    src_row src_data%rowtype;
  
    hasLv1                  number;
    hasLv2                  number;
    hasLv3                  number;
    hasLv4                  number;
    hasLv5                  number;
    hasLv6                  number;
    countor                 number;
    t_parent_id             varchar2(1000);
    t_parent_lov_path       varchar2(1000);
    t_parent_name_path      varchar2(1000);
    t_parent_code_path      varchar2(1000);
    t_sys_t_lov_member_hook sys_t_lov_member%rowtype;
  begin
  
    imp_product_category_delete;
  
    update TMP_PRODUCT_CATEGORY603 set row_id = sys_guid();
  
    UPDATE TMP_PRODUCT_CATEGORY603 S
       SET S.REMARK =
           (select B.C_PRO_NAME
              from CRM_T_PRODUCT_BASIC B
             WHERE B.C_PRO_CODE = S.PRODUCT_CODE);
  
    countor := 0;
    open src_data;
    loop
      fetch src_data
        into src_row;
      exit when src_data%notfound;
      -------------level1-----------------------------------------------------    
    
      select count(1)
        into hasLv1
        from sys_t_lov_member
       where group_code = 'procatalog'
         and lov_name = src_row.level1
         and lov_level = '1';
    
      if hasLv1 = 0 then
        --lv1??????,????
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('lv1_' || src_row.row_id,
           'lv1_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'N',
           '1',
           src_row.level1,
           src_row.level1,
           '??',
           null,
           null,
           null,
           null,
           'ROOT',
           '/' || 'lv1_' || src_row.row_id,
           'N',
           '/' || src_row.level1,
           '/' || 'lv1_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
      
        t_sys_t_lov_member_hook.parent_id := 'lv1_' || src_row.row_id;
      else
      
        select *
          into t_sys_t_lov_member_hook
          from sys_t_lov_member
         where group_code = 'procatalog'
           and lov_name = src_row.level1
           and lov_level = '1';
      
      end if;
    
      if src_row.level2 is null then
        --??????????????
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('prod_' || src_row.row_id,
           'prod_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'Y',
           '2',
           null,
           src_row.remark,
           '??',
           null,
           null,
           null,
           src_row.product_code,
           t_sys_t_lov_member_hook.row_id,
           t_sys_t_lov_member_hook.lov_path || '/prod_' || src_row.row_id,
           'N',
           t_sys_t_lov_member_hook.name_path || '/' || src_row.remark,
           t_sys_t_lov_member_hook.code_path || '/prod_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        continue; --??????????
      end if;
    
      --------------------level2----------------------------------------------------
    
      select count(1)
        into hasLv2
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2
         and lov_level = '2';
    
      select row_id, lov_path, name_path, code_path
        into t_parent_id,
             t_parent_lov_path,
             t_parent_name_path,
             t_parent_code_path
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1
         and lov_level = '1';
    
      if hasLv2 = 0 then
        --??????,????
      
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('lv2_' || src_row.row_id,
           'lv2_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'N',
           '2',
           src_row.level2,
           src_row.level2,
           '??',
           null,
           null,
           null,
           null,
           t_parent_id,
           t_parent_lov_path || '/lv2_' || src_row.row_id,
           'N',
           t_parent_name_path || '/' || src_row.level2,
           t_parent_code_path || '/lv2_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
      
        t_sys_t_lov_member_hook.parent_id := 'lv2_' || src_row.row_id;
      else
        select *
          into t_sys_t_lov_member_hook
          from sys_t_lov_member
         where group_code = 'procatalog'
           and name_path = '/' || src_row.level1 || '/' || src_row.level2
           and lov_level = '2';
      
      end if;
    
      if src_row.level3 is null then
        --??????????????
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('prod_' || src_row.row_id,
           'prod_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'Y',
           '3',
           null,
           src_row.remark,
           '??',
           null,
           null,
           null,
           src_row.product_code,
           t_sys_t_lov_member_hook.row_id,
           t_sys_t_lov_member_hook.lov_path || '/prod_' || src_row.row_id,
           'N',
           t_sys_t_lov_member_hook.name_path || '/' || src_row.remark,
           t_sys_t_lov_member_hook.code_path || '/prod_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        continue; --??????????
      end if;
    
      --------------------level3----------------------------------------------------
    
      select count(1)
        into hasLv3
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3
         and lov_level = '3';
    
      select row_id, lov_path, name_path, code_path
        into t_parent_id,
             t_parent_lov_path,
             t_parent_name_path,
             t_parent_code_path
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2
         and lov_level = '2';
    
      if hasLv3 = 0 then
        --??????,????
      
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('lv3_' || src_row.row_id,
           'lv3_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'N',
           '3',
           src_row.level3,
           src_row.level3,
           '??',
           null,
           null,
           null,
           null,
           t_parent_id,
           t_parent_lov_path || '/lv3_' || src_row.row_id,
           'N',
           t_parent_name_path || '/' || src_row.level3,
           t_parent_code_path || '/lv3_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        t_sys_t_lov_member_hook.parent_id := 'lv3_' || src_row.row_id;
      else
        select *
          into t_sys_t_lov_member_hook
          from sys_t_lov_member
         where group_code = 'procatalog'
           and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
               src_row.level3
           and lov_level = '3';
      end if;
      if src_row.level4 is null then
        --??????????????
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('prod_' || src_row.row_id,
           'prod_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'Y',
           '4',
           null,
           src_row.remark,
           '??',
           null,
           null,
           null,
           src_row.product_code,
           t_sys_t_lov_member_hook.row_id,
           t_sys_t_lov_member_hook.lov_path || '/prod_' || src_row.row_id,
           'N',
           t_sys_t_lov_member_hook.name_path || '/' || src_row.remark,
           t_sys_t_lov_member_hook.code_path || '/prod_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        continue; --??????????
      end if;
    
      --------------------level4----------------------------------------------------
    
      select count(1)
        into hasLv4
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3 || '/' || src_row.level4
         and lov_level = '4';
    
      select row_id, lov_path, name_path, code_path
        into t_parent_id,
             t_parent_lov_path,
             t_parent_name_path,
             t_parent_code_path
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3
         and lov_level = '3';
    
      if hasLv4 = 0 then
        --??????,????
      
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('lv4_' || src_row.row_id,
           'lv4_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'N',
           '4',
           src_row.level4,
           src_row.level4,
           '??',
           null,
           null,
           null,
           null,
           t_parent_id,
           t_parent_lov_path || '/lv4_' || src_row.row_id,
           'N',
           t_parent_name_path || '/' || src_row.level4,
           t_parent_lov_path || '/lv4_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        t_sys_t_lov_member_hook.parent_id := 'lv4_' || src_row.row_id;
      else
      
        select *
          into t_sys_t_lov_member_hook
          from sys_t_lov_member
         where group_code = 'procatalog'
           and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
               src_row.level3 || '/' || src_row.level4
           and lov_level = '4';
      end if;
      if src_row.level5 is null then
        --??????????????
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('prod_' || src_row.row_id,
           'prod_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'Y',
           '5',
           null,
           src_row.remark,
           '??',
           null,
           null,
           null,
           src_row.product_code,
           t_sys_t_lov_member_hook.row_id,
           t_sys_t_lov_member_hook.lov_path || '/prod_' || src_row.row_id,
           'N',
           t_sys_t_lov_member_hook.name_path || '/' || src_row.remark,
           t_sys_t_lov_member_hook.code_path || '/prod_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        continue; --??????????
      end if;
    
      --------------------level5----------------------------------------------------
    
      select count(1)
        into hasLv5
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3 || '/' || src_row.level4 || '/' ||
             src_row.level5
         and lov_level = '5';
    
      select row_id, lov_path, name_path, code_path
        into t_parent_id,
             t_parent_lov_path,
             t_parent_name_path,
             t_parent_code_path
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3 || '/' || src_row.level4
         and lov_level = '4';
    
      if hasLv5 = 0 then
        --??????,????
      
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('lv5_' || src_row.row_id,
           'lv5_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'N',
           '5',
           src_row.level5,
           src_row.level5,
           '??',
           null,
           null,
           null,
           null,
           t_parent_id,
           t_parent_lov_path || '/lv5_' || src_row.row_id,
           'N',
           t_parent_name_path || '/' || src_row.level5,
           t_parent_code_path || '/lv5_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
      
        t_sys_t_lov_member_hook.parent_id := 'lv5_' || src_row.row_id;
      else
        select *
          into t_sys_t_lov_member_hook
          from sys_t_lov_member
         where group_code = 'procatalog'
           and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
               src_row.level3 || '/' || src_row.level4 || '/' ||
               src_row.level5
           and lov_level = '5';
      end if;
      if src_row.level6 is null then
        --??????????????
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('prod_' || src_row.row_id,
           'prod_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'Y',
           '6',
           null,
           src_row.remark,
           '??',
           null,
           null,
           null,
           src_row.product_code,
           t_sys_t_lov_member_hook.row_id,
           t_sys_t_lov_member_hook.lov_path || '/prod_' || src_row.row_id,
           'N',
           t_sys_t_lov_member_hook.name_path || '/' || src_row.remark,
           t_sys_t_lov_member_hook.code_path || '/prod_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
        continue; --??????????
      end if;
    
      --------------------level6----------------------------------------------------
    
      select count(1)
        into hasLv6
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3 || '/' || src_row.level4 || '/' ||
             src_row.level5 || '/' || src_row.level6
         and lov_level = '6';
    
      select row_id, lov_path, name_path, code_path
        into t_parent_id,
             t_parent_lov_path,
             t_parent_name_path,
             t_parent_code_path
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3 || '/' || src_row.level4 || '/' ||
             src_row.level5
         and lov_level = '5';
    
      if hasLv6 = 0 then
        --??????,????
      
        insert into sys_t_lov_member
          (row_id,
           lov_code,
           creation_by,
           creation_date,
           group_id,
           last_updated_by,
           last_updated_date,
           leaf_flag,
           lov_level,
           memo,
           lov_name,
           opt_txt1,
           opt_txt2,
           opt_txt3,
           opt_txt4,
           opt_txt5,
           parent_id,
           lov_path,
           delete_flag,
           name_path,
           code_path,
           group_code,
           start_date,
           end_date,
           no)
        values
          ('lv6_' || src_row.row_id,
           'lv6_' || src_row.row_id,
           '0',
           sysdate,
           'procatalog',
           '0',
           sysdate,
           'N',
           '6',
           src_row.level6,
           src_row.level6,
           '??',
           null,
           null,
           null,
           null,
           t_parent_id,
           t_parent_lov_path || '/lv6_' || src_row.row_id,
           'N',
           t_parent_name_path || '/' || src_row.level6,
           t_parent_code_path || '/lv6_' || src_row.row_id,
           'procatalog',
           sysdate - 1,
           null,
           null);
      
        t_sys_t_lov_member_hook.parent_id := 'lv6_' || src_row.row_id;
      
      else
      
        select *
          into t_sys_t_lov_member_hook
          from sys_t_lov_member
         where group_code = 'procatalog'
           and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
               src_row.level3 || '/' || src_row.level4 || '/' ||
               src_row.level5 || '/' || src_row.level6
           and lov_level = '6';
      
      end if;
      --       level6?????,??????
      --??????????????
    
      select row_id, lov_path, name_path, code_path
        into t_parent_id,
             t_parent_lov_path,
             t_parent_name_path,
             t_parent_code_path
        from sys_t_lov_member
       where group_code = 'procatalog'
         and name_path = '/' || src_row.level1 || '/' || src_row.level2 || '/' ||
             src_row.level3 || '/' || src_row.level4 || '/' ||
             src_row.level5 || '/' || src_row.level6
         and lov_level = '6';
    
      insert into sys_t_lov_member
        (row_id,
         lov_code,
         creation_by,
         creation_date,
         group_id,
         last_updated_by,
         last_updated_date,
         leaf_flag,
         lov_level,
         memo,
         lov_name,
         opt_txt1,
         opt_txt2,
         opt_txt3,
         opt_txt4,
         opt_txt5,
         parent_id,
         lov_path,
         delete_flag,
         name_path,
         code_path,
         group_code,
         start_date,
         end_date,
         no)
      values
        ('prod_' || src_row.row_id,
         'prod_' || src_row.row_id,
         '0',
         sysdate,
         'procatalog',
         '0',
         sysdate,
         'Y',
         '7',
         null,
         src_row.remark,
         '??',
         null,
         null,
         null,
         src_row.product_code,
         t_sys_t_lov_member_hook.Parent_Id,
         t_parent_lov_path || '/prod_' || src_row.row_id,
         'N',
         t_parent_name_path || '/' || src_row.remark,
         t_parent_code_path || '/prod_' || src_row.row_id,
         'procatalog',
         sysdate - 1,
         null,
         null);
      countor := countor + 1;
      if mod(countor, 100) = 0 then
        commit;
      end if;
    end loop;
    commit;
    update sys_t_lov_member s
       set s.opt_txt5 =
           (select NVL(b.c_pid, S.OPT_TXT5)
              from crm_t_product_basic b
             where b.c_pro_code = s.opt_txt5)
     where s.group_code = 'procatalog'
       and s.opt_txt5 is not null;
  
    commit;
  end;

  procedure imp_product_category_delete is
    cursor src_data is
      select * from SYS_T_LOV_MEMBER WHERE GROUP_CODE = 'procatalog';
    countor number;
    src_row src_data%rowtype;
  begin
    countor := 0;
    open src_data;
    loop
      fetch src_data
        into src_row;
      exit when src_data%notfound;
    
      delete from SYS_T_LOV_MEMBER where row_id = src_row.row_id;
    
      countor := countor + 1;
    
      if mod(countor, 1000) = 0 then
        commit;
      end if;
    end loop;
    commit;
  end;

  procedure imp_area is
    cursor src_data is
      select * from imp_area order by citylevel;
    src_row     src_data%rowtype;
    countor     number;
    t_lov_path  varchar2(500);
    t_code_path varchar2(500);
    t_name_path varchar2(500);
  begin
  
    t_lov_path  := '';
    t_code_path := '';
    t_name_path := '';
  
    open src_data;
    loop
      fetch src_data
        into src_row;
      exit when src_data%notfound;
    
      if src_row.citylevel = '2' then
        insert into SYS_T_LOV_MEMBER
          (ROW_ID,
           LOV_CODE,
           CREATION_BY,
           CREATION_DATE,
           GROUP_ID,
           LAST_UPDATED_BY,
           LAST_UPDATED_DATE,
           LEAF_FLAG,
           LOV_LEVEL,
           MEMO,
           LOV_NAME,
           OPT_TXT1,
           OPT_TXT2,
           OPT_TXT3,
           OPT_TXT4,
           OPT_TXT5,
           PARENT_ID,
           LOV_PATH,
           DELETE_FLAG,
           NAME_PATH,
           CODE_PATH,
           GROUP_CODE,
           START_DATE,
           END_DATE,
           NO)
        values
          ('ADDRESSREGION_' || src_row.citycode,
           src_row.citycode,
           '0',
           sysdate - 1,
           'ff8080815afa48fd015afa551a8e000b',
           '0',
           sysdate - 1,
           'N',
           src_row.citylevel,
           src_row.simplename || '-' || src_row.phonearea || '-' ||
           src_row.mailcode || '-' || src_row.pinyin,
           src_row.cityname,
           null,
           null,
           null,
           null,
           null,
           'ADDRESSREGION_100000',
           '/ADDRESSREGION_100000/' || 'ADDRESSREGION_' || src_row.citycode,
           'N',
           '/??/' || src_row.cityname,
           '/100000/' || src_row.citycode,
           'ADDRESSREGION',
           sysdate - 1,
           null,
           null);
      end if;
      if src_row.citylevel = '3' then
      
        select l.lov_path, l.code_path, l.name_path
          into t_lov_path, t_code_path, t_name_path
          from SYS_T_LOV_MEMBER l
         where l.group_code = 'ADDRESSREGION'
           and row_id = 'ADDRESSREGION_' || src_row.parentcode;
      
        insert into SYS_T_LOV_MEMBER
          (ROW_ID,
           LOV_CODE,
           CREATION_BY,
           CREATION_DATE,
           GROUP_ID,
           LAST_UPDATED_BY,
           LAST_UPDATED_DATE,
           LEAF_FLAG,
           LOV_LEVEL,
           MEMO,
           LOV_NAME,
           OPT_TXT1,
           OPT_TXT2,
           OPT_TXT3,
           OPT_TXT4,
           OPT_TXT5,
           PARENT_ID,
           LOV_PATH,
           DELETE_FLAG,
           NAME_PATH,
           CODE_PATH,
           GROUP_CODE,
           START_DATE,
           END_DATE,
           NO)
        values
          ('ADDRESSREGION_' || src_row.citycode,
           src_row.citycode,
           '0',
           sysdate - 1,
           'ff8080815afa48fd015afa551a8e000b',
           '0',
           sysdate - 1,
           'N',
           src_row.citylevel,
           src_row.simplename || '-' || src_row.phonearea || '-' ||
           src_row.mailcode || '-' || src_row.pinyin,
           src_row.cityname,
           null,
           null,
           null,
           null,
           null,
           'ADDRESSREGION_' || src_row.parentcode,
           t_lov_path || '/' || 'ADDRESSREGION_' || src_row.citycode,
           'N',
           t_name_path || '/' || src_row.cityname,
           t_code_path || '/' || src_row.citycode,
           'ADDRESSREGION',
           sysdate - 1,
           null,
           null);
      end if;
    
      if src_row.citylevel = '4' then
        insert into SYS_T_LOV_MEMBER
          (ROW_ID,
           LOV_CODE,
           CREATION_BY,
           CREATION_DATE,
           GROUP_ID,
           LAST_UPDATED_BY,
           LAST_UPDATED_DATE,
           LEAF_FLAG,
           LOV_LEVEL,
           MEMO,
           LOV_NAME,
           OPT_TXT1,
           OPT_TXT2,
           OPT_TXT3,
           OPT_TXT4,
           OPT_TXT5,
           PARENT_ID,
           LOV_PATH,
           DELETE_FLAG,
           NAME_PATH,
           CODE_PATH,
           GROUP_CODE,
           START_DATE,
           END_DATE,
           NO)
        values
          ('ADDRESSREGION_' || src_row.citycode,
           src_row.citycode,
           '0',
           sysdate - 1,
           'ff8080815afa48fd015afa551a8e000b',
           '0',
           sysdate - 1,
           'N',
           src_row.citylevel,
           src_row.simplename || '-' || src_row.phonearea || '-' ||
           src_row.mailcode || '-' || src_row.pinyin,
           src_row.cityname,
           null,
           null,
           null,
           null,
           null,
           'ADDRESSREGION_' || src_row.parentcode,
           t_lov_path || '/' || 'ADDRESSREGION_' || src_row.citycode,
           'N',
           t_name_path || '/' || src_row.cityname,
           t_code_path || '/' || src_row.citycode,
           'ADDRESSREGION',
           sysdate - 1,
           null,
           null);
      end if;
    
      if mod(countor, 1000) = 0 then
        commit;
      end if;
    end loop;
    commit;
  end;

  procedure imp_customer_info is
    t_position_id varchar2(200);
    t_employee_id varchar2(200);
    t_org_id      varchar2(200);
  begin
  
    DELETE FROM crm_t_custom_info;
  
    DELETE FROM CRM_T_TEAM C
     WHERE C.BUSINESS_ID LIKE 'IMP%'
       AND C.BUSINESS_TYPE = 'CUSTOM_REPORT_PROC';
  
    DELETE FROM CRM_T_ORGS C
     WHERE C.BUSINESS_ID LIKE 'IMP%'
       AND C.BUSINESS_TYPE = 'CUSTOM_REPORT_PROC';
  
    DELETE FROM crm_t_custom_address_info C;
  
    DELETE FROM crm_t_custom_erp_info C;
  
    insert into crm_t_custom_info
      select * from imp_crm_t_custom_info_back;
  
    -- crm_t_custom_info.c_custom_class
    update crm_t_custom_info c
       set c.c_custom_class =
           (select nvl(m.row_id, c_custom_class)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCLASS'
               and m.lov_name = c.c_custom_class);
  
    -- crm_t_custom_info.c_custom_source           
    update crm_t_custom_info c
       set c.c_custom_source =
           (select nvl(m.row_id, c_custom_source)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMSOURCE'
               and m.lov_name = c.c_custom_source);
  
    -- crm_t_custom_info.c_custom_status
    update crm_t_custom_info c
       set c.c_custom_status =
           (select nvl(m.row_id, c_custom_status)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMSTATUS'
               and m.lov_name = c.c_custom_status);
  
    -- crm_t_custom_info.c_custom_AREA
    update crm_t_custom_info c
       set c.c_custom_area =
           (select nvl(m.row_id, c_custom_area)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_name = c.c_custom_area
               and m.lov_level = '1');
  
    -- crm_t_custom_info.c_custom_grade
    update crm_t_custom_info c
       set c.c_custom_grade =
           (select nvl(m.row_id, c_custom_grade)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMGRADE'
               and m.lov_name = c.c_custom_grade);
  
    -- crm_t_custom_info.c_custom_reported_flg
    update crm_t_custom_info c
       set c.c_custom_reported_flg = 'CUSTOM_NORMAL_STATUS_10';
    /*(select nvl(m.row_id, c_custom_reported_flg)
     from sys_t_lov_member m
    where m.group_code = 'CUSTOM_NORMAL_STATUS'
      and m.lov_name = c.c_custom_reported_flg);*/
  
    -- crm_t_custom_info.c_custom_category
    update crm_t_custom_info c
       set c.c_custom_category =
           (select nvl(m.row_id, c_custom_category)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCATEGORY'
               and m.lov_level = '1'
               and m.lov_name = c.c_custom_category);
  
    -- crm_t_custom_info.c_custom_category_sub
    update crm_t_custom_info c
       set c.c_custom_category_sub =
           (select nvl(m.row_id, c_custom_category_sub)
              from sys_t_lov_member m
             where m.group_code = 'CUSTOMCATEGORY'
               and m.lov_level = '2'
               AND C.C_CUSTOM_CATEGORY = M.PARENT_ID
               and m.lov_name = c.c_custom_category_sub);
  
    -- crm_t_custom_info.c_custom_area_sub1
    update crm_t_custom_info c
       set c.c_custom_area_sub1 =
           (select nvl(m.row_id, c_custom_area_sub1)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '2'
               and (m.lov_name = c.c_custom_area_sub1 or
                   m.lov_name = c.c_custom_area_sub1 || '?'));
  
    -- crm_t_custom_info.c_custom_area_sub2
    update crm_t_custom_info c
       set c.c_custom_area_sub2 =
           (select nvl(m.row_id, c_custom_area_sub2)
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '3'
               and m.lov_name = c.c_custom_area_sub2 || '%');
  
    -- crm_t_custom_info.c_custom_area_sub3
    update crm_t_custom_info c
       set c.c_custom_area_sub3 =
           (select nvl(m.row_id, c_custom_area_sub3 || '%')
              from sys_t_lov_member m
             where m.group_code = 'ADDRESSREGION'
               and m.lov_level = '4'
               and m.lov_name = c.c_custom_area_sub3 || '%');
  
    -- ????????
    update crm_t_custom_info c set c.c_custom_type = '1';
  
    --???
    /*  ??????????????????????
    1????????
    2????????******
    3??????????
    4????????
    
    5?????(?????????????)?
    ??????????
    ???????
    ??:????
    ??????*/
    update crm_t_custom_info c
       set c.c_custom_category = 'ff8080815bb44f6b015bb4ba93cf0032'
     where c.c_custom_category is null;
  
    update crm_t_custom_info c
       set c.c_custom_category_sub = 'ff8080815bb44f6b015bb4bb6a390035'
     where c.c_custom_category_sub is null;
  
    update crm_t_custom_info c
       set c.c_custom_status = 'CUSTOMSTATUS_10'
     where c.c_custom_status is null;
  
    update crm_t_custom_info c
       set c.c_custom_control_status = 'CONTROLSTATUS_01'
     where c.c_custom_control_status is null;
  
    update crm_t_custom_info c
       set c.c_custom_reported_flg = 'CUSTOM_NORMAL_STATUS_10'
     where c.c_custom_reported_flg is null;
  
    --????
    t_employee_id := '297edff859ac766b0159af3825020003'; --admin
  
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
  
    update crm_t_custom_info c
       set c.c_created_by_id  = t_employee_id, --admin
           c.c_created_pos_id = t_position_id, --admin
           c.c_created_org_id = t_org_id,
           c.c_updated_by_id  = t_employee_id,
           c.dt_created_at    = sysdate,
           c.dt_updated_at    = sysdate;
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             t_position_id,
             t_employee_id,
             'CUSTOM_REPORT_PROC',
             f.c_pid
        from crm_t_custom_info f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_pid,
             'CUSTOM_REPORT_PROC',
             t_org_id,
             t_org_id,
             null
        from crm_t_custom_info f;
  
    --??????\??
    insert into crm_t_custom_address_info
      (c_pid,
       c_custom_pid,
       c_area_lov1,
       c_area_lov2,
       c_area_lov3,
       c_area_lov4,
       c_area_lov5,
       c_custom_address,
       c_custom_zip,
       c_custom_address_type,
       c_custom_address_phone,
       c_custom_address_fax,
       c_custom_address_use,
       c_custom_address_valid,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at)
      select c.c_pid,
             c.c_pid,
             c.c_custom_area,
             c.c_custom_area_sub1,
             c.c_custom_area_sub2,
             c.c_custom_area_sub3,
             null,
             c.c_corp_reg_address,
             null,
             '8a828d115a5f97da015a5f9c50760002',
             null,
             null,
             'ff8080815af52889015af539bb80000e  ',
             'COMMONYN_Y',
             c.c_created_by_id,
             c.dt_created_at,
             c.c_created_pos_id,
             c.c_created_org_id,
             c.c_updated_by_id,
             c.dt_updated_at
        from crm_t_custom_info c;
  
    insert into crm_t_custom_erp_info
      (c_pid,
       c_custom_pid,
       c_corp_erp_unit,
       c_corp_leaded_address,
       c_corp_leaded_comment,
       c_corp_erp_status,
       c_created_by_id,
       dt_created_at,
       c_created_pos_id,
       c_created_org_id,
       c_updated_by_id,
       dt_updated_at)
      select sys_guid(),
             c.c_pid,
             en.f,
             c.c_pid,
             null,
             'CUSTOM_NORMAL_STATUS_40',
             c.c_created_by_id,
             c.dt_created_at,
             c.c_created_pos_id,
             c.c_created_org_id,
             c.c_updated_by_id,
             c.dt_updated_at
        from crm_t_custom_info c, imp_customer_business_entity en
       where en.b = c.c_custom_erp_code
         and c.c_custom_erp_code is not null;
  
    --????????      
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.name = imp.ac
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and emp.no not in ('02666', --????
                                    '02666',
                                    '06655',
                                    '07720',
                                    '10940',
                                    '12058',
                                    '12147',
                                    '13287',
                                    '13568',
                                    '13868')
                 and rownum = 1),
             (select ce.row_id
                from sys_t_permission_employee ce
               where ce.name = imp.ac
                 and ce.no not in ('02666', --????
                                   '02666',
                                   '06655',
                                   '07720',
                                   '10940',
                                   '12058',
                                   '12147',
                                   '13287',
                                   '13568',
                                   '13868')
                 and rownum = 1),
             'CUSTOM_REPORT_PROC',
             f.c_pid
        from crm_t_custom_info f, IMP_CUSTOM_INFO_ALLROWS imp
       where f.c_pid = imp.a;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_pid,
             'CUSTOM_REPORT_PROC',
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.name = imp.ac
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and emp.no not in ('02666', --????
                                    '02666',
                                    '06655',
                                    '07720',
                                    '10940',
                                    '12058',
                                    '12147',
                                    '13287',
                                    '13568',
                                    '13868')
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.name = imp.ac
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and emp.no not in ('02666', --????
                                    '02666',
                                    '06655',
                                    '07720',
                                    '10940',
                                    '12058',
                                    '12147',
                                    '13287',
                                    '13568',
                                    '13868')
                 and rownum = 1),
             null
        from crm_t_custom_info f, IMP_CUSTOM_INFO_ALLROWS imp
       where f.c_pid = imp.a;
  
    /*    select pos.row_id, posorg.parent_id
        into t_position_id, t_org_id
        from SYS_T_PERMISSION_USER_REL rel,
             sys_t_lov_member          pos,
             sys_t_lov_member          posorg
       where rel.user_id = '297edff859ac766b0159af3825020003'
         and rel.type = 'P'
         and rel.member_id = pos.row_id
         and pos.group_id = 'POSITION'
         and pos.opt_txt1 = posorg.row_id
         and posorg.group_id = 'ORG';
    
    --?????admin??
      insert_permission(t_position_id,
                        t_org_id,
                        '297edff859ac766b0159af3825020003');
    */
  end;

  procedure imp_contract is
    t_sys_guid    varchar2(100);
    t_employee_id varchar2(100);
    t_position_id varchar2(100);
    t_org_id      varchar2(100);
  begin
  
    /*  
      select * from CRM_T_CONTR_BASIC;
      select * from sys_t_lov_member where group_code = 'PRJLSTPRDCAT';
      select * from CRM_T_PRJ_LST s where s.c_type = 'CONTR_STAND';
      select * from CRM_T_TEAM t where t.business_id like 'IMP_CONTRACT%';
      select * from crm_t_orgs g where g.business_id like 'IMP_CONTRACT%';
    */
  
    delete from CRM_T_CONTR_BASIC;
    delete from sys_t_lov_member where group_code = 'PRJLSTPRDCAT';
    delete from CRM_T_PRJ_LST s where s.c_type = 'CONTR_STAND';
    delete from CRM_T_TEAM t where t.business_id like 'IMP_CONTRACT%';
    delete from crm_t_orgs g where g.business_id like 'IMP_CONTRACT%';
  
    insert into CRM_T_CONTR_BASIC
      (C_ID,
       C_CONTR_NO,
       C_CONTR_NAME,
       C_CONTR_TYPE,
       C_CUST_CODE,
       C_CUST_name,
       N_TOTAL_AMT,
       c_Org,
       c_Buss_Enity,
       c_creator,
       C_ORDERER,
       ORDER_POS_ID,
       ORDER_ORG_ID,
       c_contr_stat)
      select 'IMP_CONTRACT_430_' || imp_sequtil.nextval,
             b,
             c,
             d,
             e,
             e,
             f,
             j,
             'ff8080815b4645ec015b46f8035d0092',
             v,
             'P_GNQCEMP_B1_0014',
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = 'P_GNQCEMP_B1_0014'
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.user_id = 'P_GNQCEMP_B1_0014'
                 and rel.type = 'P'
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'),
             'ff8080815afaa793015afde1bc440043'
        from (select distinct s.b, s.c, s.d, s.e, s.f, s.j, s.k, s.v
                from imp_contract_allrows s);
  
    update CRM_T_CONTR_BASIC c
       set c.c_contr_type        = 'ff8080815b1d1242015b1d2dfaee0007',
           c.c_cust_code        =
           (select nvl(mf.c_pid, c.c_cust_code)
              from crm_t_custom_info mf
             where mf.c_custom_full_name = c.c_cust_code),
           c.c_org              =
           (select m.row_id
              from sys_t_lov_member m
             where m.lov_name = c.c_org
               and group_id = 'ORG'),
           c.c_contr_stat        = 'ff8080815afaa793015afde1bc440043',
           c.c_trial_stat        = '8a828dee5a11fc73015a12a86421000d',
           c.c_review_stat       = '8a828dee5a11fc73015a12a86421000d',
           c.c_final_review_stat = '8a828dee5a11fc73015a12a86421000d',
           c.c_creator          =
           (select e.row_id
              from sys_t_permission_employee e
             where e.name = c.c_creator
               and e.no not in ('02666', --????
                                '02666',
                                '06655',
                                '07720',
                                '10940',
                                '12058',
                                '12147',
                                '13287',
                                '13568',
                                '13868')
               and rownum = 1);
  
    update CRM_T_CONTR_BASIC c
       set c.created_by_id  = t_employee_id, --admin
           c.created_pos_id = t_position_id, --admin
           c.created_org_id = t_org_id,
           c.updated_by_id  = t_employee_id,
           C.DT_CREATE_TIME = SYSDATE,
           c.created_at     = sysdate,
           c.updated_at     = sysdate;
  
    UPDATE CRM_T_CONTR_BASIC C
       SET C.C_ORG =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id = C.C_CREATOR
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               AND ROWNUM = 1)
     WHERE C.C_CREATOR IS NOT NULL;
  
    UPDATE CRM_T_CONTR_BASIC C
       SET C.C_MARKET_DEPT =
           (select s.lov_code as code
              from sys_t_lov_member s
             where s.group_code = 'ORG'
               and s.opt_txt3 = 'A'
             start with s.row_id = C.C_ORG
            connect by prior s.parent_id = s.row_id)
     WHERE C.C_ORG IS NOT NULL;
  
    --??admin??
    t_employee_id := '297edff859ac766b0159af3825020003'; --admin
  
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             t_position_id,
             t_employee_id,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(), f.c_id, 'CONTR_STAND', t_org_id, t_org_id, null
        from CRM_T_CONTR_BASIC f;
  
    --??????
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             (select pos.row_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_creator
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and emp.no not in ('02666', --????
                                    '02666',
                                    '06655',
                                    '07720',
                                    '10940',
                                    '12058',
                                    '12147',
                                    '13287',
                                    '13568',
                                    '13868')
                 and rownum = 1),
             f.c_creator,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(),
             f.c_id,
             'CONTR_STAND',
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and emp.no not in ('02666', --????
                                    '02666',
                                    '06655',
                                    '07720',
                                    '10940',
                                    '12058',
                                    '12147',
                                    '13287',
                                    '13568',
                                    '13868')
                 and rownum = 1),
             (select posorg.parent_id
                from SYS_T_PERMISSION_USER_REL rel,
                     sys_t_permission_employee emp,
                     sys_t_lov_member          pos,
                     sys_t_lov_member          posorg
               where rel.type = 'P'
                 and emp.row_id = f.c_orderer
                 and emp.row_id = rel.user_id
                 and rel.member_id = pos.row_id
                 and pos.group_id = 'POSITION'
                 and pos.opt_txt1 = posorg.row_id
                 and posorg.group_id = 'ORG'
                 and emp.no not in ('02666', --????
                                    '02666',
                                    '06655',
                                    '07720',
                                    '10940',
                                    '12058',
                                    '12147',
                                    '13287',
                                    '13568',
                                    '13868')
                 and rownum = 1),
             null
        from CRM_T_CONTR_BASIC f;
  
    -- ??????
  
    t_employee_id := 'P_GNQCEMP_B1_0014'; --admin
  
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
  
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             t_position_id,
             t_employee_id,
             'CONTR_STAND',
             f.c_id
        from CRM_T_CONTR_BASIC f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(), f.c_id, 'CONTR_STAND', t_org_id, t_org_id, null
        from CRM_T_CONTR_BASIC f;
  
    t_sys_guid := sys_guid();
    ------------------------------------------------------------------------------------------------------
    insert into sys_t_lov_member
      (row_id,
       lov_code,
       group_id,
       leaf_flag,
       lov_level,
       memo,
       lov_name,
       parent_id,
       lov_path,
       delete_flag,
       name_path,
       code_path,
       group_code)
      select c.c_id,
             t_sys_guid,
             'PRJLSTPRDCAT',
             'N',
             '1',
             c.c_id,
             '???',
             'ROOT',
             '/' || c.c_id,
             'N',
             '/???',
             '/' || t_sys_guid,
             'PRJLSTPRDCAT'
        from CRM_T_CONTR_BASIC c;
  
    --insert into product line;
  
    insert into CRM_T_PRJ_LST
      (C_QID,
       C_TYPE,
       C_PRD_NAME,
       C_PRD_CTG,
       C_PRD_TYP,
       C_PRD_UNT,
       N_PRD_PRC,
       N_TTL_UNT,
       N_AMOUNT,
       C_LVID,
       C_PID,
       C_MATER_CODE,
       C_PRO_DESC,
       C_ORD_NO,
       C_PRD_CD,
       C_PRO_ID,
       C_BUSINEES_CODE,
       C_PRD_CTGID,
       C_LINE_NUM)
      select b.c_id,
             'CONTR_STAND',
             pb.c_pro_name,
             (select m.lov_name
                from sys_t_lov_member m
               where m.lov_code = pb.c_pro_crm_category
                 and m.group_code = 'crmCategory'),
             pb.c_pro_model,
             (select m.lov_name
                from sys_t_lov_member m
               where m.row_id = pb.c_unit),
             p.s,
             p.r * p.s,
             p.r,
             b.c_id,
             'IMP_CONTRACT_430_' || imp_sequtil.nextval,
             p.q,
             pb.c_pro_desc,
             p.t,
             pb.c_pro_code,
             pb.c_pid,
             b.c_contr_no,
             pb.C_PRO_CRM_CATEGORY,
             null
        from CRM_T_CONTR_BASIC    b,
             imp_contract_allrows p,
             crm_t_product_basic  pb
       where b.c_contr_no = p.b
         and pb.c_pro_code(+) = p.q;
  
  end;

  procedure imp_order is
    t_employee_id varchar2(100);
    t_position_id varchar2(100);
    t_org_id      varchar2(100);
  begin
  
    /*select * from crm_t_order_header;
    select * from crm_t_order_lines;
    select * from crm_t_order_forecast;
    select * from crm_t_order_forecast_detail;
    select * from tmp_order_header;*/
  
    delete from crm_t_order_header;
    delete from crm_t_order_lines;
    /*    delete from crm_t_order_forecast;
    delete from crm_t_order_forecast_detail;*/
    delete from tmp_order_header;
  
    insert into tmp_order_header
      select distinct b,
                      c,
                      d,
                      null,
                      f,
                      g,
                      h,
                      i,
                      j,
                      k,
                      l,
                      m,
                      n,
                      o,
                      p,
                      q,
                      r,
                      s,
                      t,
                      u,
                      v,
                      w,
                      x,
                      y,
                      z,
                      aa,
                      ab,
                      ac,
                      ad,
                      ae,
                      af
        from IMP_ORDER501;
  
    insert into crm_t_order_header
      (c_pid, c_order_code, c_customer_code)
      select 'IMP_501_ORDER_' || imp_sequtil.nextval, f.b, f.h
        from tmp_order_header f;
  
    update crm_t_order_header h
       set h.c_customer_erp_code = h.c_customer_code;
    update crm_t_order_header h
       set h.c_customer_code =
           (select nvl(m.c_custom_code, 'none')
              from crm_t_custom_info m
             where m.c_custom_erp_code = h.c_customer_erp_code),
           h.c_customer_name =
           (select nvl(m.c_custom_full_name, 'none')
              from crm_t_custom_info m
             where m.c_custom_erp_code = h.c_customer_erp_code),
           h.c_customer_id  =
           (select nvl(m.c_pid, 'none')
              from crm_t_custom_info m
             where m.c_custom_erp_code = h.c_customer_erp_code)
    
     where h.c_customer_erp_code in
           (select m.c_custom_erp_code from crm_t_custom_info m);
  
    --insert into order header
    update crm_t_order_header h
       set h.c_order_type         = --????
           (select c.lov_code
              from sys_t_lov_member c, tmp_order_header t
             where c.group_code = 'OPERATION_UNIT'
               and c.lov_name = t.c
               and t.b = h.c_order_code),
           h.dt_order_date        =
           (select to_date(t.e, 'yyyy/mm/dd')
              from tmp_order_header t
             where t.b = h.c_order_code),
           h.c_currency           =
           (select t.v from tmp_order_header t where t.b = h.c_order_code),
           h.c_salesman_id        =
           (select e.row_id
              from sys_t_permission_employee e, tmp_order_header t
             where e.name = t.u
               and t.b = h.c_order_code
               and rownum = 1),
           h.c_salesman_name      =
           (select e.name
              from sys_t_permission_employee e, tmp_order_header t
             where e.name = t.u
               and t.b = h.c_order_code
               and rownum = 1),
           h.c_salesman_code      =
           (select e.no
              from sys_t_permission_employee e, tmp_order_header t
             where e.name = t.u
               and t.b = h.c_order_code
               and rownum = 1),
           h.c_execute_status     =
           (select l.lov_code
              from sys_t_lov_member l, tmp_order_header t
             where l.lov_name = t.d
               and t.b = h.c_order_code
               and l.group_code = 'ORDERSTATUS'),
           h.c_term_payment        = 'IMMEDIATE',
           h.c_term_payment_detail =
           (select t.x from tmp_order_header t where t.b = h.c_order_code),
           h.c_source_name        =
           (select cb.c_contr_name
              from crm_t_contr_basic cb, tmp_order_header t
             where cb.c_contr_no = t.f
               and t.b = h.c_order_code),
           h.c_source_code        =
           (select cb.c_contr_no
              from crm_t_contr_basic cb, tmp_order_header t
             where cb.c_contr_no = t.f
               and t.b = h.c_order_code),
           h.c_source_id          =
           (select cb.c_id
              from crm_t_contr_basic cb, tmp_order_header t
             where cb.c_contr_no = t.f
               and t.b = h.c_order_code),
           h.c_source_type         = '10',
           h.c_erp_order_code      = h.c_order_code,
           h.c_created_by_id      =
           (select e.row_id
              from sys_t_permission_employee e, tmp_order_header t
             where e.name = t.u
               and t.b = h.c_order_code
               and rownum = 1),
           h.dt_created_at        =
           (select to_date(t.e, 'yyyy/mm/dd')
              from tmp_order_header t
             where t.b = h.c_order_code),
           h.c_created_pos_id     =
           (select pos.row_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id =
                   (select e.row_id
                      from sys_t_permission_employee e, tmp_order_header t
                     where e.name = t.u
                       and t.b = h.c_order_code
                       and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           h.c_created_org_id     =
           (select posorg.parent_id
              from SYS_T_PERMISSION_USER_REL rel,
                   sys_t_lov_member          pos,
                   sys_t_lov_member          posorg
             where rel.user_id =
                   (select e.row_id
                      from sys_t_permission_employee e, tmp_order_header t
                     where e.name = t.u
                       and t.b = h.c_order_code
                       and rownum = 1)
               and rel.type = 'P'
               and rel.member_id = pos.row_id
               and pos.group_id = 'POSITION'
               and pos.opt_txt1 = posorg.row_id
               and posorg.group_id = 'ORG'
               and rownum = 1),
           h.c_updated_by_id      =
           (select e.row_id
              from sys_t_permission_employee e, tmp_order_header t
             where e.name = t.u
               and t.b = h.c_order_code
               and rownum = 1),
           h.dt_updated_at         = sysdate;
  
    --insert into permission
  
    t_employee_id := '297edff859ac766b0159af3825020003'; --admin
  
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
  
    insert into CRM_T_TEAM
      (ROW_ID, POSITION_ID, MASTER_EMPLOYEE_ID, BUSINESS_TYPE, BUSINESS_ID)
      select sys_guid(),
             t_position_id,
             t_employee_id,
             'CONTR_STAND',
             f.c_pid
        from crm_t_order_header f;
  
    insert into crm_t_orgs
      (row_id,
       business_id,
       business_type,
       org_id,
       primary_org_id,
       primary_org_flag)
      select sys_guid(), f.c_pid, 'CONTR_STAND', t_org_id, t_org_id, null
        from crm_t_order_header f;
  
    --insert into order line
  
    insert into crm_t_order_lines
      (c_pid,
       c_order_code,
       c_pro_model,
       c_materiel_code,
       n_product_quantity,
       c_unit,
       n_price,
       n_amount,
       dt_request_date,
       dt_promise_date,
       c_confirm_delivery_date,
       c_ship_org,
       c_is_advance_billing,
       n_billing_quantity,
       c_line_no,
       c_order_id,
       c_pro_id,
       c_create_time,
       c_creator,
       c_materiel_name,
       n_cancel_quantity,
       c_updated_by_id,
       dt_updated_at,
       c_erp_plan_status,
       -- c_is_erp_delivery,
       --n_erp_settlement_price
       --c_return_reason,
       --c_return_reference,
       --c_is_pending,
       n_delivery_quantity
       --c_receiving_customer,
       --c_consignee,
       --  c_status,
       -- c_original_line_id,
       --c_source_id,
       --c_remark,
       )
      select t.a,
             h.c_order_code,
             cp.c_pro_model,
             t.ai,
             t.ar,
             t.b1,
             t.c1,
             t.d1,
             to_date(t.f1, 'yyyy/mm/dd'),
             to_date(t.g1, 'yyyy/mm/dd'),
             t.h1,
             t.e1,
             t.i1,
             nvl(t.ar, 0),
             t.ah,
             h.c_pid,
             cp.c_pid,
             to_date(t.e, 'yyyy/mm/dd'),
             h.c_created_by_id,
             cp.c_pro_name,
             nvl(t.a1, 0),
             h.c_created_by_id,
             sysdate,
             t.r1,
             0
        from IMP_ORDER501 t, crm_t_order_header h, crm_t_product_basic cp
       where t.b = h.c_order_code
         and cp.c_pro_code(+) = t.ai;
  
  end;

  procedure imp_delivery is
  
    cursor src_data is
      select * from imp_delivery;
  
    src_row             src_data%rowtype;
    customer_row        crm_t_custom_info%rowtype;
    address_row         crm_t_custom_address_info%rowtype;
    order_row           crm_t_order_header%rowtype;
    order_line_row      crm_t_order_lines%rowtype;
    delivery_header_row crm_t_delivery_header%rowtype;
  
    DELIVERY_HEADER_row_id varchar2(100);
  
    t_employee_id varchar2(200);
    t_position_id varchar2(200);
    t_org_id      varchar2(200);
  begin
  
    delete from CRM_T_DELIVERY_HEADER;
  
    delete from CRM_T_DELIVERY_LINES;
  
    delete from crm_t_delivery_receipt;
  
    --update product name to imp_delivery.u
  
    update imp_delivery d
       set d.u =
           (select p.c_pro_name
              from crm_t_product_basic p
             where p.c_pro_code = d.e);
  
    t_employee_id := '297edff859ac766b0159af3825020003'; --admin
  
    select pos.row_id, posorg.parent_id
      into t_position_id, t_org_id
      from SYS_T_PERMISSION_USER_REL rel,
           sys_t_lov_member          pos,
           sys_t_lov_member          posorg
     where rel.user_id = t_employee_id
       and rel.type = 'P'
       and rel.member_id = pos.row_id
       and pos.group_id = 'POSITION'
       and pos.opt_txt1 = posorg.row_id
       and posorg.group_id = 'ORG';
  
    open src_data;
    loop
      fetch src_data
        into src_row;
      exit when src_data%notfound;
    
      --check header
      begin
        select *
          into delivery_header_row
          from CRM_T_DELIVERY_HEADER h
         where h.out_delivery_code = src_row.m;
      exception
        when others then
          delivery_header_row := null;
      end;
    
      if delivery_header_row.c_pid is null then
      
        begin
          select *
            into customer_row
            from crm_t_custom_info c
           where c.c_custom_erp_code = src_row.b;
        exception
          when others then
            customer_row := null;
        end;
      
        begin
          select *
            into address_row
            from crm_t_custom_address_info ad
           where ad.c_custom_pid = customer_row.c_pid;
        exception
          when others then
            address_row := null;
        end;
      
        --insert header
        insert into CRM_T_DELIVERY_HEADER
          (C_PID,
           C_DELIVERY_CODE,
           DT_APPLY_DATE,
           C_STATUS,
           C_BUSINESS_ENTITY,
           C_PROPOSER_ID,
           C_RECE_CUSTOMER_ID,
           C_DELIVERY_ADDRESS,
           C_CONSIGNEE,
           C_CONSIGNEE_TEL,
           C_BILL_CUSTOMER_ID,
           C_REMARKS,
           C_RECE_CUSTOMER_NAME,
           C_BILL_CUSTOMER_NAME,
           C_PROPOSER_NAME,
           C_DELIVERY_ADDRESS_ID,
           C_CREATED_BY_ID,
           DT_CREATED_AT,
           C_CREATED_POS_ID,
           C_CREATED_ORG_ID,
           C_UPDATED_BY_ID,
           DT_UPDATED_AT,
           C_RECE_CUSTOMER_CODE,
           C_PROPOSER_CODE,
           OUT_DELIVERY_CODE)
        values
          (src_row.a || '_HEADER',
           src_row.m,
           to_date('2017-05-01', 'yyyy-mm-dd'),
           '30',
           'ff8080815b4645ec015b46f8035d0092', --101
           t_employee_id, --admin
           customer_row.c_pid,
           src_row.r,
           src_row.s,
           src_row.t,
           address_row.c_pid,
           '?????',
           CUSTOMER_ROW.C_CUSTOM_FULL_NAME,
           CUSTOMER_ROW.C_CUSTOM_FULL_NAME,
           'admin',
           address_row.c_pid,
           t_employee_id,
           sysdate,
           t_position_id,
           t_org_id,
           t_employee_id,
           sysdate,
           CUSTOMER_ROW.c_Custom_Code,
           'admin',
           src_row.m);
      
        DELIVERY_HEADER_row_id := src_row.a || '_HEADER';
      else
        DELIVERY_HEADER_row_id := delivery_header_row.c_pid;
      end if;
    
      select *
        into order_row
        from crm_t_order_header h
       where h.c_order_code = substr(src_row.m, 0, 9);
    
      dbms_output.put_line(src_row.l || '---' || src_row.m);
    
      select *
        into order_line_row
        from crm_t_order_lines l
       where l.c_order_code = substr(src_row.m, 0, 9)
         and l.c_line_no = src_row.l;
    
      --insert delivery line
      insert into CRM_T_DELIVERY_LINES
        (C_PID,
         C_DELIVERY_CODE,
         C_ORDER_CODE,
         C_ORDER_TYPE,
         C_SINGLE_CUST_CODE,
         C_SINGLE_CUST_NAME,
         N_PRICE,
         C_PRODUCT_MODEL,
         C_MATERIEL_CODE,
         C_MATERIEL_NAME,
         C_UNIT,
         N_RECEIPT_QUANTITY,
         N_DELIVERY_QUANTITY,
         N_RESIDUAL_QUANTITY,
         DT_ORDER_DATE,
         DT_ARRIVAL_DATE,
         DT_PROMISE_DATE,
         C_PLAN_STATUS,
         C_LINE_NUM,
         C_EXTERNAL_NO,
         DT_PRINT_TIME,
         C_REMARKS,
         C_ORDER_ID,
         C_CREATE_TIME,
         C_CREATOR,
         C_SINGLE_CUST_PO,
         N_DELIVERY_AMOUNT,
         C_ORDER_LINE_NO,
         C_DELIVERY_ID,
         C_DELIVERY_DATE,
         C_SINGLE_CUST_ID,
         N_INVOICE_QUANTITY,
         C_UPDATED_BY_ID,
         DT_UPDATED_AT,
         C_RECE_CUSTOMER,
         C_IS_POST_ACCOUNT)
      values
        (src_row.a || '_LINE',
         src_row.m,
         substr(src_row.m, 0, 9),
         '10',
         customer_row.c_custom_code,
         customer_row.c_custom_full_name,
         src_row.f,
         src_row.d,
         src_row.e,
         src_row.u,
         src_row.g,
         src_row.h,
         src_row.h,
         0,
         order_row.dt_order_date,
         order_row.dt_request_date,
         order_line_row.dt_promise_date,
         order_line_row.c_erp_plan_status,
         src_row.l,
         src_row.m,
         null,
         '?????',
         order_row.c_pid,
         sysdate,
         t_employee_id,
         order_row.c_customer_po,
         src_row.f * src_row.h,
         order_line_row.c_line_no,
         DELIVERY_HEADER_row_id,
         to_date('2017-05-01', 'yyyy-mm-dd'),
         customer_row.c_pid,
         src_row.h,
         t_employee_id,
         sysdate,
         null,
         null);
    
      --innsert receive line
      insert into crm_t_delivery_receipt
        (c_pid,
         c_receipt_code,
         c_delivery_code,
         c_order_code,
         c_materiel_code,
         c_receiving_address,
         c_consignee,
         c_consignee_tel,
         c_unit,
         n_delivery_quantity,
         c_remarks,
         c_materiel_name,
         c_external_no,
         dt_invoice_print_time,
         n_receipt_quantity,
         c_logistics_company,
         dt_create_time,
         c_creator,
         c_delivery_lines_num,
         c_logistics_no,
         dt_estimate_arrival_time,
         dt_actual_arrival_time,
         n_estimate_time,
         n_actual_time,
         c_order_line_no,
         n_delivery_amount,
         c_updated_by_id,
         dt_updated_at,
         c_created_by_id,
         dt_created_at,
         c_created_pos_id,
         c_created_org_id,
         c_control_status,
         c_status,
         c_is_main,
         c_order_id)
      values
        (src_row.a || '_RECEIVE',
         src_row.m,
         src_row.p,
         substr(src_row.m, 0, 9),
         src_row.e,
         src_row.r,
         src_row.s,
         src_row.t,
         src_row.g,
         src_row.h,
         '?????',
         src_row.u,
         src_row.m,
         null,
         src_row.h,
         null,
         sysdate,
         t_employee_id,
         src_row.l,
         null,
         null,
         null,
         null,
         null,
         order_line_row.c_line_no,
         src_row.h * src_row.f,
         t_employee_id,
         sysdate,
         t_employee_id,
         sysdate,
         t_position_id,
         t_org_id,
         null,
         '20',
         null,
         order_row.c_pid);
    
    end loop;
  
  end;

end pkg_data_imp;
/
