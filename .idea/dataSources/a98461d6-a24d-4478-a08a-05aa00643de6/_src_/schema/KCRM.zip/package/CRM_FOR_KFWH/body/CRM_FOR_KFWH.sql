CREATE package body CRM_FOR_KFWH is

procedure sync_saleman_order_to_contract is
   cursor src_data is
     select a.c_id,
         a.c_creator,
         a.c_org,
         a.c_market_dept,
         b.c_salesman_id,
         b.c_salesman_center,
         b.c_salesman_dep
    from crm_t_contr_basic a, crm_t_order_header b
   where a.c_creator is null 
     and b.c_source_code = a.c_contr_no;
    src_row     src_data%rowtype;
    old_c_creator varchar2(500);
    old_c_org varchar2(500);
    old_c_market_dept varchar2(500);
    
      begin
     
      
         open src_data;
         loop fetch src_data into src_row;
         exit when src_data%notfound;
          old_c_creator  := '';
      old_c_org := '';
      old_c_market_dept := '';  
         
         select a.c_org, a.c_creator, a.c_market_dept
           into old_c_creator, old_c_org, old_c_market_dept
           from crm_t_contr_basic a
           where a.c_id = src_row.c_id;
         
         /*update crm_t_contr_basic a
            set a.c_org     = src_row.c_salesman_center,
                a.c_creator = src_row.c_salesman_id,
                a.c_market_dept = src_row.c_salesman_dep
          where a.c_id = src_row.c_id;
          
          insert  into CRM_T_UPDATE_LOG(TABLE_NAME,BUSINESS_KEY,COL_NAME,OLD_VALUE,NEW_VALUE,UPDATE_DATE)
          values('crm_t_contr_basic',src_row.c_id,'c_creator',old_c_creator,src_row.c_salesman_id,sysdate);
          
            insert  into CRM_T_UPDATE_LOG(TABLE_NAME,BUSINESS_KEY,COL_NAME,OLD_VALUE,NEW_VALUE,UPDATE_DATE)
          values('crm_t_contr_basic',src_row.c_id,'c_org',old_c_org,src_row.c_salesman_center,sysdate);
          
            insert into CRM_T_UPDATE_LOG(TABLE_NAME,BUSINESS_KEY,COL_NAME,OLD_VALUE,NEW_VALUE,UPDATE_DATE)
          values('crm_t_contr_basic',src_row.c_id,'c_market_dept',old_c_market_dept,src_row.c_salesman_dep,sysdate);*/
        
        end loop;
        commit;
      end;
    
end CRM_FOR_KFWH;
/
