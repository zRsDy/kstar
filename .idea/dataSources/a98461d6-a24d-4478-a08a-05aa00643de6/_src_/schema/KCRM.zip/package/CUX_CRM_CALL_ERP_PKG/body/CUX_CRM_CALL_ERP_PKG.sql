CREATE package body CUX_CRM_CALL_ERP_PKG is
  --g_list_line_rec line_tab;
  --crm???????ERP???????
  --P_CRM_ORDER  crm????
  --X_RETURN_STATUS??'S'?CRM???????????
  PROCEDURE VALIDATE_ORDER(P_CRM_ORDER      IN VARCHAR2,
                           X_RETURN_STATUS  OUT VARCHAR2,
                           X_RETURN_MESSAGE OUT VARCHAR2) IS
  
  BEGIN
    X_RETURN_STATUS  := 'S';
    X_RETURN_MESSAGE := NULL;
  
    apps.CUX_CRM_OE_ORDER_IMP_PKG.VALIDATE_ORDER@CRM_ERP(P_CRM_ORDER,
                                                         X_RETURN_STATUS,
                                                         X_RETURN_MESSAGE);
  
    COMMIT;
  
    BEGIN
      SYS.DBMS_SESSION.CLOSE_DATABASE_LINK@CRM_ERP('LINK_TO_NEWCRM.KSTAR.COM.CN');
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      X_RETURN_STATUS  := 'E';
      X_RETURN_MESSAGE := SUBSTR(SQLERRM, 1, 500);
  END VALIDATE_ORDER;

  --??CRM???????
  --P_CRM_ORDER crm???
  --P_CRM_LINE  crm????
  --P_ORDER_QTY crm?????  
  --X_RETURN_STATUS ??'S'???
  PROCEDURE GET_SPLIT_LINE_STATUS(P_CRM_ORDER      IN VARCHAR2,
                                  P_CRM_LINE       IN VARCHAR2,
                                  P_ORDER_QTY      IN NUMBER,
                                  X_RETURN_STATUS  OUT VARCHAR2,
                                  X_RETURN_MESSAGE OUT VARCHAR2) IS
  BEGIN
    X_RETURN_STATUS  := 'S';
    X_RETURN_MESSAGE := NULL;
    apps.CUX_CRM_OE_ORDER_IMP_PKG.GET_SPLIT_LINE_STATUS@CRM_ERP(P_CRM_ORDER,
                                                                P_CRM_LINE,
                                                                P_ORDER_QTY,
                                                                X_RETURN_STATUS,
                                                                X_RETURN_MESSAGE);
    COMMIT;
    BEGIN
      SYS.DBMS_SESSION.CLOSE_DATABASE_LINK@CRM_ERP('LINK_TO_NEWCRM.KSTAR.COM.CN');
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      X_RETURN_STATUS  := 'E';
      X_RETURN_MESSAGE := SUBSTR(SQLERRM, 1, 500);
  END GET_SPLIT_LINE_STATUS;

  --??ERP??????(????CRM???????)
  ----P_CRM_ORDER crm???
  --P_CRM_LINE  crm????
  --X_RETURN_STATUS ??????
  PROCEDURE SPLIT_LINE(P_CRM_ORDER       IN VARCHAR2,
                       P_CRM_SOURCE_LINE IN VARCHAR2,
                       P_CRM_NEW_LINE    IN VARCHAR2,
                       P_LINE_NEW_QTY    IN NUMBER,
                       X_RETURN_STATUS   OUT VARCHAR2,
                       X_RETURN_MESSAGE  OUT VARCHAR2) IS
  
  BEGIN
    X_RETURN_STATUS  := 'S';
    X_RETURN_MESSAGE := NULL;
  
    apps.CUX_CRM_OE_ORDER_IMP_PKG.SPLIT_LINE@CRM_ERP(P_CRM_ORDER,
                                                     P_CRM_SOURCE_LINE,
                                                     P_CRM_NEW_LINE,
                                                     P_LINE_NEW_QTY,
                                                     X_RETURN_STATUS,
                                                     X_RETURN_MESSAGE);
  
    --COMMIT;
    BEGIN
      SYS.DBMS_SESSION.CLOSE_DATABASE_LINK@CRM_ERP('LINK_TO_NEWCRM.KSTAR.COM.CN');
      --COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      X_RETURN_STATUS  := 'E';
      X_RETURN_MESSAGE := SUBSTR(SQLERRM, 1, 500);
  END SPLIT_LINE;

  /*PROCEDURE SPLIT_LINE(P_LINE_TAB       IN APPS.CUX_CRM_OE_ORDER_IMP_PKG.line_tab1@CRM_ERP,
                       X_RETURN_STATUS  OUT VARCHAR2,
                       X_RETURN_MESSAGE OUT VARCHAR2) IS
  
    i number;
  BEGIN
    X_RETURN_STATUS  := 'S';
    X_RETURN_MESSAGE := NULL;
     i                := 0;
    
    for i in 1 .. P_LINE_TAB.count loop
      X_RETURN_MESSAGE:=X_RETURN_MESSAGE||'/'||
        P_LINE_TAB(i).c_order_code||' ' ||P_LINE_TAB(i).c_line_num||' '||P_LINE_TAB(i).ordered_quantity;
    end loop;
    X_RETURN_STATUS  := 'E';
      RETURN;
  
    apps.CUX_CRM_OE_ORDER_IMP_PKG.SPLIT_LINE@CRM_ERP(P_LINE_TAB,
                                                     X_RETURN_STATUS,
                                                     X_RETURN_MESSAGE);
  
    COMMIT;
    BEGIN
      SYS.DBMS_SESSION.CLOSE_DATABASE_LINK@CRM_ERP('LINK_TO_NEWCRM.KSTAR.COM.CN');
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      X_RETURN_STATUS  := 'E';
      X_RETURN_MESSAGE := SUBSTR(SQLERRM, 1, 500);
  END SPLIT_LINE;*/

  --CRM????????
  --P_CRM_ORDER  crm??????(c_delivery_code)
  --X_RETURN_STATUS ??'S'???????
  PROCEDURE MAIN_PROCESS(P_CRM_ORDER      IN VARCHAR2,
                         P_TYPE           IN VARCHAR2,
                         X_RETURN_STATUS  OUT VARCHAR2,
                         X_RETURN_MESSAGE OUT VARCHAR2) IS
  BEGIN
    X_RETURN_STATUS  := 'S';
    X_RETURN_MESSAGE := NULL;
  
    apps.CUX_CRM_SHIPDATA_ERP_PKG.MAIN_PROCESS@CRM_ERP(P_CRM_ORDER,
                                                       P_TYPE,
                                                       X_RETURN_STATUS,
                                                       X_RETURN_MESSAGE);
  
    COMMIT;
    BEGIN
      SYS.DBMS_SESSION.CLOSE_DATABASE_LINK@CRM_ERP('LINK_TO_NEWCRM.KSTAR.COM.CN');
      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
  EXCEPTION
    WHEN OTHERS THEN
      X_RETURN_STATUS  := 'E';
      X_RETURN_MESSAGE := SUBSTR(SQLERRM, 1, 500);
  END MAIN_PROCESS;

end CUX_CRM_CALL_ERP_PKG;
/
