CREATE PACKAGE BODY sys_p_doc_sequence_utl AS
  /*==================================================
  Copyright (C) AIR.CHINA-IBM Co.,Ltd.
             AllRights Reserved
  ==================================================*/
  /*==================================================
  Program Name:
      sys_p_doc_sequence_utl
  Description:
      ??????????????????API
  History:
      1.00  2007-05-23  hand  Creation
  ==================================================*/
  FUNCTION next_seq_number(p_doc_type    IN VARCHAR2,
                           p_pk1_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk2_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk3_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk4_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk5_value   IN VARCHAR2 DEFAULT NULL,
                           p_init_number IN NUMBER DEFAULT 1) RETURN NUMBER IS
    PRAGMA AUTONOMOUS_TRANSACTION;

    CURSOR c_seq IS
      SELECT ds.rowid row_id,
             ds.next_seq_number
        FROM SYS_T_DOC_SEQUENCES ds
       WHERE ds.doc_type = p_doc_type
         AND ds.pk1_value = nvl(p_pk1_value,
                                '-1')
         AND ds.pk2_value = nvl(p_pk2_value,
                                '-1')
         AND ds.pk3_value = nvl(p_pk3_value,
                                '-1')
         AND ds.pk4_value = nvl(p_pk4_value,
                                '-1')
         AND ds.pk5_value = nvl(p_pk5_value,
                                '-1')
         FOR UPDATE; -- NOWAIT;

    l_row_id          VARCHAR2(18);
    l_next_seq_number NUMBER;
  BEGIN
    OPEN c_seq;
    FETCH c_seq
      INTO l_row_id,
           l_next_seq_number;
    IF c_seq%NOTFOUND THEN
      l_next_seq_number := nvl(p_init_number,
                               1);
      INSERT INTO SYS_T_DOC_SEQUENCES
        (doc_type,
         pk1_value,
         pk2_value,
         pk3_value,
         pk4_value,
         pk5_value,
         next_seq_number,
         creation_date,
         created_by,
         last_update_date,
         last_updated_by,
         last_update_login)
      VALUES
        (p_doc_type,
         nvl(p_pk1_value,
             '-1'),
         nvl(p_pk2_value,
             '-1'),
         nvl(p_pk3_value,
             '-1'),
         nvl(p_pk4_value,
             '-1'),
         nvl(p_pk5_value,
             '-1'),
         l_next_seq_number,
         SYSDATE,
         -1,
         SYSDATE,
         -1,
         -1);
    ELSE
      l_next_seq_number := l_next_seq_number + 1;
      UPDATE SYS_T_DOC_SEQUENCES
         SET next_seq_number   = l_next_seq_number,
             last_update_date  = SYSDATE,
             last_updated_by   = -1,
             last_update_login = -1
       WHERE ROWID = l_row_id;
    END IF;
    CLOSE c_seq;
    COMMIT;

    RETURN l_next_seq_number;
  END next_seq_number;

  FUNCTION next_seq_number(p_doc_type    IN VARCHAR2,
                           p_doc_prefix  IN VARCHAR2,
                           p_seq_length  IN NUMBER DEFAULT 0,
                           p_pk1_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk2_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk3_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk4_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk5_value   IN VARCHAR2 DEFAULT NULL,
                           p_init_number IN NUMBER DEFAULT 1) RETURN VARCHAR2 IS
    l_next_seq_number NUMBER;
    l_doc_number      VARCHAR2(150);
  BEGIN
    l_next_seq_number := next_seq_number(p_doc_type    => p_doc_type,
                                         p_pk1_value   => p_pk1_value,
                                         p_pk2_value   => p_pk2_value,
                                         p_pk3_value   => p_pk3_value,
                                         p_pk4_value   => p_pk4_value,
                                         p_pk5_value   => p_pk5_value,
                                         p_init_number => p_init_number);
    IF p_seq_length IS NULL
       OR p_seq_length = 0 THEN
      l_doc_number := p_doc_prefix || l_next_seq_number;
    ELSE
      IF length(l_next_seq_number) >= p_seq_length THEN
        l_doc_number := p_doc_prefix || l_next_seq_number;
      ELSE
        l_doc_number := p_doc_prefix || lpad(l_next_seq_number,
                                             p_seq_length,
                                             '0');
      END IF;
    END IF;
    RETURN l_doc_number;
  END next_seq_number;

  FUNCTION curr_seq_number(p_doc_type    IN VARCHAR2,
                           p_doc_prefix  IN VARCHAR2,
                           p_seq_length  IN NUMBER DEFAULT 0,
                           p_pk1_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk2_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk3_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk4_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk5_value   IN VARCHAR2 DEFAULT NULL,
                           p_init_number IN NUMBER DEFAULT 1) RETURN VARCHAR2 IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    CURSOR c_seq IS
      SELECT ds.rowid row_id,
             ds.next_seq_number
        FROM SYS_T_DOC_SEQUENCES ds
       WHERE ds.doc_type = p_doc_type
         AND ds.pk1_value = nvl(p_pk1_value,
                                '-1')
         AND ds.pk2_value = nvl(p_pk2_value,
                                '-1')
         AND ds.pk3_value = nvl(p_pk3_value,
                                '-1')
         AND ds.pk4_value = nvl(p_pk4_value,
                                '-1')
         AND ds.pk5_value = nvl(p_pk5_value,
                                '-1')
         FOR UPDATE; -- NOWAIT;

    l_row_id          VARCHAR2(18);
    l_next_seq_number NUMBER;
  BEGIN
    OPEN c_seq;
    FETCH c_seq
      INTO l_row_id,
           l_next_seq_number;
    IF c_seq%NOTFOUND THEN
      l_next_seq_number := next_seq_number(p_doc_type    => p_doc_type,
                                           p_doc_prefix  => NULL,
                                           p_seq_length  => p_seq_length,
                                           p_pk1_value   => p_pk1_value,
                                           p_pk2_value   => NULL,
                                           p_pk3_value   => NULL,
                                           p_pk4_value   => NULL,
                                           p_pk5_value   => NULL,
                                           p_init_number => 1);

      INSERT INTO SYS_T_DOC_SEQUENCES
        (doc_type,
         pk1_value,
         pk2_value,
         pk3_value,
         pk4_value,
         pk5_value,
         next_seq_number,
         creation_date,
         created_by,
         last_update_date,
         last_updated_by,
         last_update_login)
      VALUES
        (p_doc_type,
         nvl(p_pk1_value,
             '-1'),
         nvl(p_pk2_value,
             '-1'),
         nvl(p_pk3_value,
             '-1'),
         nvl(p_pk4_value,
             '-1'),
         nvl(p_pk5_value,
             '-1'),
         l_next_seq_number,
         SYSDATE,
         -1,
         SYSDATE,
         -1,
         -1);
    END IF;
      IF p_seq_length IS NULL
         OR p_seq_length = 0 THEN
        l_next_seq_number := p_doc_prefix || l_next_seq_number;
      ELSE
        IF length(l_next_seq_number) >= p_seq_length THEN
          l_next_seq_number := p_doc_prefix || l_next_seq_number;
        ELSE
          l_next_seq_number := p_doc_prefix || lpad(l_next_seq_number,
                                                    p_seq_length,
                                                    '0');
        END IF;
      END IF;

    CLOSE c_seq;
    COMMIT;

    RETURN l_next_seq_number;
  END curr_seq_number;
END sys_p_doc_sequence_utl;
/
