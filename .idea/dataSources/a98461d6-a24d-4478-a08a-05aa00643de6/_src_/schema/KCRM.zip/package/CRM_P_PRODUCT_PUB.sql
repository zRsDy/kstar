CREATE package CRM_P_PRODUCT_PUB is


 FUNCTION gen_maintenance_code(p_user_id IN NUMBER) RETURN VARCHAR2;


end CRM_P_PRODUCT_PUB;
/
