CREATE PACKAGE sys_p_doc_sequence_utl AS
  /*==================================================
  Copyright (C) AIR.CHINA-IBM Co.,Ltd.
             AllRights Reserved
  ==================================================*/
  /*==================================================
  Program Name:
      sys_p_doc_sequence_utl
  Description:
      ??????????????????API
  History:
      1.00  2007-05-23  hand  Creation
  ==================================================*/
  /*==================================================
  Function Name :
      next_seq_number
  Description:
      ????????
  Argument:
      p_doc_type    : ????
      p_pk1_value   : ????1
      p_pk2_value   : ????2
      p_pk3_value   : ????3
      p_pk4_value   : ????4
      p_pk5_value   : ????5
      p_init_number : ?????
  Return:
      NUMBER          : ???????
  History:
      1.00  2008-01-23  hand  Creation
  ==================================================*/
  FUNCTION next_seq_number(p_doc_type    IN VARCHAR2,
                           p_pk1_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk2_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk3_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk4_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk5_value   IN VARCHAR2 DEFAULT NULL,
                           p_init_number IN NUMBER DEFAULT 1) RETURN NUMBER;

  /*==================================================
  Function Name :
      next_seq_number
  Description:
      ????????
  Argument:
      p_doc_type    : ????
      p_doc_prefix  ???
      p_seq_length  : ??
      p_pk1_value   : ????1
      p_pk2_value   : ????2
      p_pk3_value   : ????3
      p_pk4_value   : ????4
      p_pk5_value   : ????5
      p_init_number : ?????
  Return:
      VARCHAR2      : ?????
  History:
      1.00  2008-01-23  hand  Creation
  ==================================================*/
  FUNCTION next_seq_number(p_doc_type    IN VARCHAR2,
                           p_doc_prefix  IN VARCHAR2,
                           p_seq_length  IN NUMBER DEFAULT 0,
                           p_pk1_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk2_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk3_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk4_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk5_value   IN VARCHAR2 DEFAULT NULL,
                           p_init_number IN NUMBER DEFAULT 1) RETURN VARCHAR2;

  /*==================================================
  Function Name :
      next_seq_number
  Description:
      ???????
  Argument:
      p_doc_type    : ????
      p_doc_prefix  ???
      p_seq_length  : ??
      p_pk1_value   : ????1
      p_pk2_value   : ????2
      p_pk3_value   : ????3
      p_pk4_value   : ????4
      p_pk5_value   : ????5
      p_init_number : ?????
  Return:
      VARCHAR2      : ?????
  History:
      1.00  2008-01-23  hand  Creation
  ==================================================*/
  FUNCTION curr_seq_number(p_doc_type    IN VARCHAR2,
                           p_doc_prefix  IN VARCHAR2,
                           p_seq_length  IN NUMBER DEFAULT 0,
                           p_pk1_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk2_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk3_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk4_value   IN VARCHAR2 DEFAULT NULL,
                           p_pk5_value   IN VARCHAR2 DEFAULT NULL,
                           p_init_number IN NUMBER DEFAULT 1) RETURN VARCHAR2;
END sys_p_doc_sequence_utl;


/
