CREATE package This_is_a_sad_story is

  -- Author  : JASON
  -- Created : 2017/5/23 10:37:54
  -- Purpose : 

  procedure re_contract_happy;

  procedure re_contract_rule;

  procedure re_contract_happy2;

  procedure re_customer_happy;

  procedure re_customer_sad;

  PROCEDURE re_order_head;

  procedure re_order_line;

  procedure date_test;
end This_is_a_sad_story;
/
