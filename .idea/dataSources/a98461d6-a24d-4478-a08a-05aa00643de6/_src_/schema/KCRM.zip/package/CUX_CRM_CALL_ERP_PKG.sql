CREATE PACKAGE CUX_CRM_CALL_ERP_PKG IS
  /*TYPE list_line IS RECORD(
    c_order_code     varchar2(240),
    c_line_num       varchar2(240),
    ordered_quantity number,
    request_date     date);
  TYPE line_tab IS TABLE OF list_line INDEX BY BINARY_INTEGER;
  g_list_line_rec1 line_tab;*/

  --g_list_line_rec APPS.CUX_CRM_OE_ORDER_IMP_PKG.line_tab1@CRM_ERP;

  PROCEDURE VALIDATE_ORDER(P_CRM_ORDER      IN VARCHAR2,
                           X_RETURN_STATUS  OUT VARCHAR2,
                           X_RETURN_MESSAGE OUT VARCHAR2);

  PROCEDURE GET_SPLIT_LINE_STATUS(P_CRM_ORDER      IN VARCHAR2,
                                  P_CRM_LINE       IN VARCHAR2,
                                  P_ORDER_QTY      IN NUMBER,
                                  X_RETURN_STATUS  OUT VARCHAR2,
                                  X_RETURN_MESSAGE OUT VARCHAR2);

  PROCEDURE SPLIT_LINE(P_CRM_ORDER       IN VARCHAR2,
                       P_CRM_SOURCE_LINE IN VARCHAR2,
                       P_CRM_NEW_LINE    IN VARCHAR2,
                       P_LINE_NEW_QTY    IN NUMBER,
                       X_RETURN_STATUS   OUT VARCHAR2,
                       X_RETURN_MESSAGE  OUT VARCHAR2);

  /*PROCEDURE SPLIT_LINE(P_LINE_TAB       IN APPS.CUX_CRM_OE_ORDER_IMP_PKG.line_tab1@CRM_ERP,
  X_RETURN_STATUS  OUT VARCHAR2,
  X_RETURN_MESSAGE OUT VARCHAR2);*/

  PROCEDURE MAIN_PROCESS(P_CRM_ORDER      IN VARCHAR2,
                         P_TYPE           IN VARCHAR2,
                         X_RETURN_STATUS  OUT VARCHAR2,
                         X_RETURN_MESSAGE OUT VARCHAR2);
END CUX_CRM_CALL_ERP_PKG;
/
