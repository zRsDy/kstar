CREATE package body CRM_P_CONTRACT_PUB is
  
   /*===========================================================
    Procedure Name :
       gen_contract_num
    Description:
       ??????
       ?????
          KSTAR-XS????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
    FUNCTION gen_contract_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS  
    l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'CONTRACT_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-XS' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_contract_num;
  
   /*===========================================================
    Procedure Name :
       gen_contract_num
    Description:
       ??????????
       ?????
          ??????+(??????)????0)
  History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
    FUNCTION gen_receive_plan_num( p_user_id IN NUMBER,p_contr_num in varchar2) RETURN VARCHAR2 IS  
    l_receipt_number VARCHAR2 (30 );   
  BEGIN   
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'CONTRACT_RECEIVE_NUMBER' ,  
                                                              p_doc_prefix => p_contr_num,   
                                                              p_seq_length => 2 );  
    RETURN l_receipt_number;  
  END gen_receive_plan_num;
   /*===========================================================
    Procedure Name :
       gen_contract_num
    Description:
       ?????????
       ?????
          KSTAR-BG????YYYYMM????XXXX(?????)????0)
  History:
      1.00  2017-02-20  ibm.joe  Creation
    ===========================================================*/
    FUNCTION gen_contract_change_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS  
    l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'CONTRACT_CHANGE_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-BG' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_contract_change_num;
  
  
   /*===========================================================
    Procedure Name :
       gen_contract_pi_num
    Description:
       ??PI????
       ?????
          INS YYYYMM????X(??????) XXXX(?????)????0)
    History:
      1.00  2017-02-02  ibm.joe  Creation
    ===========================================================*/
    FUNCTION gen_contract_pi_num(dept IN varchar2) RETURN VARCHAR2 IS  
    l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'CONTRACT_PI_NUMBER' ,  
                                                              p_doc_prefix => 'INS' || l_yearmm||dept,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_contract_pi_num;
  
   /*===========================================================
    Procedure Name :
       gen_contract_num
    Description:
       ????????
       ?????
          KSTAR-JH????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2017-02-02  ibm.joe  Creation
    ===========================================================*/
    FUNCTION gen_contract_loan_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS  
    l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'CONTRACT_LOAN_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-JH' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_contract_loan_num;
  
  /*===========================================================
    Procedure Name :
       gen_bizoppsupport_num
    Description:
       ??????????
       ?????
          KSTAR-SP??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_bizoppsupport_change_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'BIZOPP_SUPPORT_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-SP' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_bizoppsupport_change_num;
  
  /*===========================================================
    Procedure Name :
       gen_bizopp_num
    Description:
       ??????
       ?????
          KSTAR-SJ????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_bizopp_change_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'BIZOP_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-SJ-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_bizopp_change_num;
    
  /*===========================================================
    Procedure Name :
       gen_bizopp_num
    Description:
       ??????
       ?????
          KSTAR-SJ????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_bizoppproto_change_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
    l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'BIZOP_PROTO_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-YJ-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_bizoppproto_change_num;
  
  /*===========================================================
    Procedure Name :
       gen_bizoppbid_num
    Description:
       ????????
       ?????
          KSTAR-SQ??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_bizoppbid_change_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'BIZOP_BID_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-SQ-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_bizoppbid_change_num;
  
  /*===========================================================
    Procedure Name :
       gen_bizoppbid_num
    Description:
       ????????
       ?????
          KSTAR-SQ??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_specialPrice_apply_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'BIZOP_SPA_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-TJ-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_specialPrice_apply_num;
  
  
  /*===========================================================
    Procedure Name :
       gen_lf_num
    Description:
       ????????
       ?????
          KSTAR-LF??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_lf_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_LF_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-LF-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_lf_num;
  
  
  
  /*===========================================================
    Procedure Name :
       gen_jj_num
    Description:
       ????????
       ?????
          KSTAR-JJ??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_jj_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_JJ_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-JJ-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_jj_num;
  
  
  
  /*===========================================================
    Procedure Name :
       gen_gx_num
    Description:
       ????????
       ?????
          KSTAR-GX??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_gx_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_GX_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-GX-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_gx_num;
  
  
  /*===========================================================
    Procedure Name :
       gen_pg_num
    Description:
       ????????
       ?????
          KSTAR-PG??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_pg_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_PG_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-PG-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_pg_num;
  
  
  /*===========================================================
    Procedure Name :
       gen_jz_num
    Description:
       ????????
       ?????
          KSTAR-JZ??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_jz_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_JZ_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-JZ-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_jz_num;
  
  
  
  /*===========================================================
    Procedure Name :
       gen_hb_num
    Description:
       ????????
       ?????
          KSTAR-HB??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_hb_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_HB_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-HB-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_hb_num;

  /*===========================================================
    Procedure Name :
       gen_bb_num
    Description:
       ????????
       ?????
          KSTAR-BB??????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_bb_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_BB_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-BB-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_bb_num;
  
  /*===========================================================
    Procedure Name :
       gen_si_num
    Description:
       ???????????
       ?????
          KSTAR-SI???????YYYYMM????XXXX(?????)????0)
    History:
      1.00  2009-09-23  XXXX  Creation
    ===========================================================*/
  FUNCTION gen_si_num(p_user_id IN NUMBER) RETURN VARCHAR2 IS
     l_receipt_number VARCHAR2 (30 );  
     l_yearmm           VARCHAR2(40);
  BEGIN
    SELECT to_char(SYSDATE, 'YYYYMM') INTO l_yearmm FROM dual;  
    l_receipt_number := sys_p_doc_sequence_utl.next_seq_number(p_doc_type   => 'KSTAR_SI_NUMBER' ,  
                                                              p_doc_prefix => 'KSTAR-SI-' || l_yearmm,  
                                                              p_seq_length => 4 );  
    RETURN l_receipt_number;  
  END gen_si_num;
  
  end CRM_P_CONTRACT_PUB;
/
