CREATE package CRM_P_ORDER_PUB is

  /*===========================================================
  Procedure Name :
     gen_order_num
  Description:
     ??????????
     ?????
       p_doc_prefix? ???YYYYMM????XXXX(?????)????0)
  History:
    1.00 2017-04-11  XXXX  Creation
  ===========================================================*/
 FUNCTION gen_order_num(doc_type IN VARCHAR2 DEFAULT NULL, prefix IN VARCHAR2  DEFAULT NULL) RETURN VARCHAR2;

end CRM_P_ORDER_PUB;
/
